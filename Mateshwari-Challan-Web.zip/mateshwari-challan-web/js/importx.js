// ---------- Bulk import from Excel (challans + payments) ----------
(function () {
  const V = window.Views, esc = U.esc, n = U.num;
  const IM = window.Importx = {};

  IM.cols = () => [
    ['Challan No', 'challanNo'], ['Challan Date', 'challanDate', 'date'], ['Cash/Finance', 'saleType'], ['Customer Name', 'customerName'], ['Father Name', 'fatherName'], ['Mobile', 'mobile'],
    ['Alt Mobile', 'altMobile'], ['Address', 'address'], ['City', 'city'], ['Aadhaar', 'aadhaar'], ['PAN', 'pan'], ['Model', 'model'], ['Variant', 'variant'], ['Colour', 'colour'],
    ['Engine No', 'engineNo'], ['Chassis No', 'chassisNo'], ['Key No', 'keyNo'], ['Battery No', 'batteryNo'], ['Invoice No', 'invoiceNo'], ['Invoice Date', 'invoiceDate', 'date'], ['Invoice Amount', 'invoiceAmount', 'num']]
    .concat(Ch.priceItems().map((it) => [it.l, 'price.' + it.k, 'num']), [['Discount', 'discount', 'num'], ['Down Payment', 'downPayment', 'num'], ['Finance Company', 'financer'], ['Loan App No', 'loanAppNo'],
      ['Loan Amount', 'loanAmount', 'num'], ['Tenure', 'tenure', 'num'], ['EMI', 'emi', 'num'], ['ROI', 'roi', 'num'], ['EMI Start', 'emiStart', 'date'], ['Loan Status', 'loanStatus'], ['Loan File', 'loanFileStatus'],
      ['Exchange Old Vehicle', 'exOldModel'], ['Exchange Reg No', 'exRegNo'], ['Exchange Value', 'exValue', 'num'], ['Insurance Company', 'insCompany'], ['Policy No', 'policyNo'],
      ['Policy From', 'insFrom', 'date'], ['Policy To', 'insTo', 'date'], ['Reg No', 'regNo'], ['RTO Status', 'rtoStatus'], ['Executive', 'executive'], ['Remark', 'remark']]);
  const PCOLS = [['Challan No', 'challanNo'], ['Date', 'date', 'date'], ['Type', 'kind'], ['Mode', 'mode'], ['Amount', 'amount', 'num'], ['Ref', 'ref'], ['Remark', 'remark']];

  IM.date = function (v) {
    if (v === '' || v == null) return '';
    if (typeof v === 'number') { const d = new Date(Math.round((v - 25569) * 86400000)); return d.toISOString().slice(0, 10); }
    if (v instanceof Date) return U.dateKey(v);
    const s = String(v).trim(); const ds = OCR.dates(s); return ds[0] || s;
  };
  function mapRow(r, cols) {
    const o = {};
    cols.forEach(([h, k, typ]) => {
      let v = r[h]; if (v === undefined) return;
      if (typeof v === 'string') v = v.trim();
      if (typ === 'date') v = IM.date(v); else if (typ === 'num') v = v === '' ? '' : n(v);
      if (v === '' || v == null) return;
      if (k.startsWith('price.')) { (o.price = o.price || {})[k.slice(6)] = v; return; }
      o[k] = v;
    });
    return o;
  }

  V.importx = async function (el) {
    if (!Ch.can('import')) { el.innerHTML = U.empty('Import ka right nahi hai'); return; }
    el.innerHTML = '<h2 class="page-title">⬆️ Import from Excel</h2><div class="card"><p>1) Template download karein, 2) data bharein (ek row = ek challan; Payments sheet me baad ke payment/disbursement), 3) file upload karein.</p>' +
      '<div class="row-btns left"><button class="btn ghost" id="tpl">⬇ Template (Excel)</button><button class="btn" id="up">📤 Excel Upload</button></div>' +
      '<p class="muted small">Agar Challan No pehle se hai to wo challan update hoga. Challan No khali ho to apne aap number milega. Single entry ke liye "New Challan" use karein.</p></div><div id="iprev"></div>';
    U.$('#tpl').onclick = async () => {
      const wb = XLSX.utils.book_new();
      const c = IM.cols().map((x) => x[0]);
      const ex = { 'Challan Date': U.dateKey(), 'Cash/Finance': 'Finance', 'Customer Name': 'Ramesh Kumar', 'Father Name': 'Suresh Kumar', Mobile: '9876543210', Model: (S.cs.models[0] || 'Model'), 'Chassis No': 'MBLHAXXXXXXXXXXXX', 'Finance Company': S.cs.financers[0] || '' };
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([c, c.map((h) => ex[h] || '')]), 'Challans');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([PCOLS.map((x) => x[0]), ['DC/0001', U.dateKey(), 'Down Payment', 'Cash', 10000, '', '']]), 'Payments');
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['Type options'], ...Ch.PAY_KINDS.map((x) => [x]), [''], ['Mode options'], ...Ch.PAY_MODES.map((x) => [x]), [''], ['Loan Status'], ...Ch.LOAN_STATUS.map((x) => [x])]), 'Help');
      await U.saveFile('Challan_Import_Template.xlsx', XLSX.write(wb, { bookType: 'xlsx', type: 'base64' }), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    };
    U.$('#up').onclick = async () => {
      const file = await U.pickFile('.xlsx,.xls,.csv'); if (!file) return;
      U.loading(true, 'File padh rahe hain...');
      try {
        const buf = await file.arrayBuffer();
        const wb = XLSX.read(buf, { type: 'array', cellDates: false });
        const sh = (name) => wb.Sheets[name] || null;
        const chSheet = sh('Challans') || wb.Sheets[wb.SheetNames[0]];
        const chRows = XLSX.utils.sheet_to_json(chSheet, { defval: '' }).map((r) => mapRow(r, IM.cols())).filter((o) => o.customerName || o.challanNo);
        const payRows = sh('Payments') ? XLSX.utils.sheet_to_json(sh('Payments'), { defval: '' }).map((r) => mapRow(r, PCOLS)).filter((o) => o.challanNo && n(o.amount) > 0) : [];
        U.loading(false);
        U.$('#iprev').innerHTML = '<div class="card"><h3>Preview</h3><p><b>' + chRows.length + '</b> challans, <b>' + payRows.length + '</b> payments mile.</p><div class="table-wrap"><table class="tbl"><thead><tr><th>Challan</th><th>Date</th><th>Customer</th><th>Mobile</th><th>Model</th><th>Type</th></tr></thead><tbody>' +
          chRows.slice(0, 20).map((o) => '<tr><td>' + esc(o.challanNo || 'Auto') + '</td><td>' + esc(o.challanDate || '') + '</td><td>' + esc(o.customerName || '') + '</td><td>' + esc(o.mobile || '') + '</td><td>' + esc(o.model || '') + '</td><td>' + esc(o.saleType || '') + '</td></tr>').join('') +
          '</tbody></table></div><button class="btn block" id="doImp">✅ Import karein</button></div>';
        U.$('#doImp').onclick = () => IM.run(chRows, payRows);
      } catch (e) { U.loading(false); U.toast('File nahi padh paaye: ' + e.message, 'err'); }
    };
  };

  IM.run = async function (chRows, payRows) {
    U.loading(true, 'Import ho raha hai...');
    try {
      const me = Ch.me();
      const existing = await Ch.challans(); const byNo = {}; existing.forEach((c) => byNo[c.challanNo] = c);
      const touched = new Set(); let created = 0, updated = 0;
      const ops = [];
      for (const o of chRows) {
        o.saleType = /fin/i.test(o.saleType || '') ? 'Finance' : 'Cash';
        if (o.mobile) o.mobile = String(o.mobile).replace(/\D/g, '').slice(-10);
        if (o.exOldModel || o.exValue) o.isExchange = true;
        ['chassisNo', 'engineNo', 'regNo', 'pan'].forEach((k) => { if (o[k]) o[k] = String(o[k]).toUpperCase().replace(/\s+/g, ''); });
        o.customerKey = (o.customerName || '').toLowerCase() + ' ' + (o.mobile || '');
        o.updatedAt = DB.now(); o.updatedBy = me.name;
        const ex = o.challanNo && byNo[o.challanNo];
        if (ex) { if (o.price) o.price = Object.assign({}, ex.price || {}, o.price); ops.push(['update', 'challans', ex.id, o]); touched.add(ex.id); updated++; continue; }
        if (!o.challanNo) { const num = await DB.nextNumber('challan'); o.challanNo = Ch.fmtNo(num); o.seq = num; }
        const id = DB.newId('challans');
        Object.assign(o, { challanDate: o.challanDate || U.dateKey(), price: o.price || {}, cost: {}, schemes: [], loanStatus: o.loanStatus || 'Pending', loanFileStatus: o.loanFileStatus || 'Pending', rtoStatus: o.rtoStatus || 'Pending',
          ownerId: me.id, createdBy: me.id, createdByName: me.name, createdAt: DB.now(), imported: true });
        Object.assign(o, Ch.summaryFields(o, Ch.calc(o)));
        ops.push(['set', 'challans', id, o]); byNo[o.challanNo] = Object.assign({ id }, o); touched.add(id); created++;
      }
      await DB.batch(ops);
      const pops = []; let pc = 0, skipped = 0;
      for (const p of payRows) {
        const c = byNo[p.challanNo]; if (!c) { skipped++; continue; }
        const kind = Ch.PAY_KINDS.find((k) => k.toLowerCase() === String(p.kind || '').toLowerCase()) || (/disb/i.test(p.kind || '') ? 'Disbursement' : 'Payment');
        const mode = Ch.PAY_MODES.find((k) => k.toLowerCase() === String(p.mode || '').toLowerCase()) || 'Cash';
        pops.push(['set', 'cpay', DB.newId('cpay'), { challanId: c.id, challanNo: c.challanNo, customerName: c.customerName, ownerId: c.ownerId, date: p.date || U.dateKey(), kind, mode, amount: n(p.amount),
          ref: p.ref || '', remark: (p.remark || '') + ' (import)', byId: me.id, byName: me.name, at: DB.now() }]);
        touched.add(c.id); pc++;
      }
      await DB.batch(pops);
      let i = 0; for (const id of touched) { i++; U.loading(true, 'Hisaab update ' + i + '/' + touched.size); await Ch.recompute(id); }
      Ch.dirty();
      U.toast('Import done: ' + created + ' naye, ' + updated + ' update, ' + pc + ' payments' + (skipped ? ', ' + skipped + ' payment ka challan nahi mila' : ''), 'ok');
      App.go('list');
    } catch (e) { U.toast('Import error: ' + e.message, 'err'); } finally { U.loading(false); }
  };
})();
