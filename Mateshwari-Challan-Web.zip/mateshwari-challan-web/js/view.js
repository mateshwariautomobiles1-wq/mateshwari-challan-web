// ---------- Challan detail: summary, ledger, finance/EMI, documents, calls, tracking ----------
(function () {
  const V = window.Views, esc = U.esc, n = U.num;
  const kv = (l, v) => (v === '' || v == null ? '' : '<div><span>' + esc(l) + '</span><b>' + v + '</b></div>');
  const t = (v) => esc(v == null ? '' : v);
  const d = (v) => (v ? U.fmtDate(v) : '');
  const days = (x) => (x == null ? '' : x + ' din');

  V.view = async function (el, p) {
    const c = await DB.get('challans', p.id);
    if (!c) { el.innerHTML = U.empty('Challan nahi mila'); return; }
    const [pays, calls, files] = await Promise.all([Ch.payments(c.id), Ch.calls(c.id).catch(() => []), Ch.files(c.id).catch(() => [])]);
    const k = Ch.calc(c, pays);
    const st = Ch.statusOf(Object.assign({}, c, { due: k.due }));
    const tab = p.tab || 'summary';
    const reload = (tb) => App.go('view', { id: c.id, tab: tb || tab });
    const inc = Ch.can('viewIncome');

    const head = '<div class="card cust-head"><div class="row">' + (c.photoThumb ? '<img class="avatar" style="width:58px;height:58px" src="' + esc(c.photoThumb) + '">' :
      '<span class="avatar ph" style="width:58px;height:58px;font-size:22px">' + esc((c.customerName || '?')[0]) + '</span>') +
      '<div class="grow"><b class="big">' + t(c.customerName) + '</b><small class="muted"> S/o ' + t(c.fatherName) + '</small><br><small>' + t(c.challanNo) + ' · ' + d(c.challanDate) + ' · ' +
      t(c.model) + ' ' + t(c.colour) + '</small><br><a href="tel:' + t(c.mobile) + '">📞 ' + t(c.mobile) + '</a> <span class="badge ' + st[1] + '">' + esc(st[0]) + '</span> <span class="badge muted">' + t(c.saleType) + '</span>' +
      (c.saleType === 'Finance' ? ' ' + Ch.loanBadge(c.loanStatus) : '') + '</div></div>' +
      '<div class="stats4">' + '<div><b>' + U.money(k.payable) + '</b><small>Payable</small></div><div><b class="good">' + U.money(k.received) + '</b><small>Received</small></div>' +
      '<div><b class="' + (k.due > 0.5 ? 'low' : 'good') + '">' + U.money(k.due) + '</b><small>Due ' + (k.dueDays ? '(' + k.dueDays + ' din)' : '') + '</small></div>' +
      '<div><b>' + U.money(c.saleType === 'Finance' ? k.finDue : k.dpDue) + '</b><small>' + (c.saleType === 'Finance' ? 'Finance pending' : 'DP due') + '</small></div></div>' +
      '<div class="act-row">' +
      (Ch.can('payment') ? '<button class="btn sm" id="aPay">+ Payment</button>' : '') +
      (Ch.can('disburse') && c.saleType === 'Finance' ? '<button class="btn sm" id="aDisb">+ Disbursement</button>' : '') +
      (Ch.can('calling') ? '<button class="btn ghost sm" id="aCall">📞 Call</button>' : '') +
      (Ch.can('upload') ? '<button class="btn ghost sm" id="aUp">📎 Upload</button>' : '') +
      '<button class="btn ghost sm" id="aPdf">🖨 Challan</button><button class="btn ghost sm" id="aSt">🖨 Statement</button><button class="btn ghost sm" id="aLet">✉️ Letter / WhatsApp</button>' +
      (S.isAdmin ? '<button class="btn ghost sm" id="aCust">👤 Customer Login' + (c.custUid ? ' ✔' : '') + '</button>' : '') +
      (Ch.can('edit') ? '<button class="btn ghost sm" onclick="App.go(\'form\',{id:\'' + c.id + '\'})">✏️ Edit</button>' : '') +
      (Ch.can('delete') ? '<button class="btn danger sm" id="aDel">🗑</button>' : '') + '</div></div>';

    const tabs = [['summary', 'Summary'], ['ledger', 'Ledger'], ['finance', 'Finance / EMI'], ['docs', 'Documents (' + files.length + ')'], ['calls', 'Calls (' + calls.length + ')'], ['track', 'Track']];
    let body = '';
    if (tab === 'summary') {
      const pr = c.price || {};
      body = '<div class="card"><h3>Customer</h3><div class="kv">' + kv('Name', t(c.customerName)) + kv('Father', t(c.fatherName)) + kv('Mobile', t(c.mobile)) + kv('Alt Mobile', t(c.altMobile)) +
        kv('Address', t(c.address)) + kv('City', t(c.city)) + kv('Aadhaar', t(c.aadhaar)) + kv('PAN', t(c.pan)) + kv('DOB', d(c.dob)) + '</div></div>' +
        '<div class="card"><h3>Vehicle & Invoice</h3><div class="kv">' + kv('Model', t(c.model) + ' ' + t(c.variant)) + kv('Colour', t(c.colour)) + kv('Engine No', t(c.engineNo)) + kv('Chassis No', t(c.chassisNo)) +
        kv('Key / Battery', t(c.keyNo) + ' / ' + t(c.batteryNo)) + kv('Invoice No', t(c.invoiceNo)) + kv('Invoice Date', d(c.invoiceDate)) + kv('Invoice Amount', c.invoiceAmount ? U.money(c.invoiceAmount) : '') +
        kv('Delivery Date', d(c.deliveryDate)) + kv('Sales Executive', t(c.executive)) + kv('Entry By', t(c.createdByName)) + '</div></div>' +
        '<div class="card"><h3>On-Road Price</h3><div class="kv">' + Ch.priceItems().map((it) => (pr[it.k] ? kv(it.l, U.money(pr[it.k]) + (inc && c.cost && c.cost[it.k] != null ? ' <small class="muted">(cost ' + U.money(c.cost[it.k]) + ')</small>' : '')) : '')).join('') +
        kv('On-Road Total', U.money(k.gross)) + kv('Discount', k.discount ? '− ' + U.money(k.discount) : '') + kv('Scheme to customer', k.custScheme ? '− ' + U.money(k.custScheme) : '') +
        kv('Customer Payable', '<b>' + U.money(k.payable) + '</b>') + kv('Exchange Value', c.isExchange ? U.money(k.exValue) : '') + kv('Down Payment agreed', c.downPayment ? U.money(c.downPayment) : '') +
        kv('Cash received', U.money(k.cashIn)) + kv('Bank/UPI received', U.money(k.bankIn)) + kv('Finance disbursed', k.disbursed ? U.money(k.disbursed) : '') +
        (inc ? kv('Income (' + (c.incomeManual !== undefined && c.incomeManual !== '' ? 'manual' : 'auto') + ')', U.money(k.income)) + kv('Company claim pending', k.claimPending ? U.money(k.claimPending) : '') : '') + '</div></div>' +
        (c.isExchange ? '<div class="card"><h3>🔁 Exchange</h3><div class="kv">' + kv('Old Vehicle', t(c.exOldModel)) + kv('Reg No', t(c.exRegNo)) + kv('Year', t(c.exYear)) + kv('Owner', t(c.exOwner)) +
          kv('Value', U.money(c.exValue)) + kv('Remark', t(c.exRemark)) + '</div></div>' : '') +
        (c.hasScheme && (c.schemes || []).length ? '<div class="card"><h3>🎁 Schemes</h3>' + c.schemes.map((s) => '<div class="li"><div class="grow"><b>' + t(s.name) + '</b><small>' +
          (s.toCustomer ? 'Customer ko diya · ' : '') + (s.claim ? 'Company claim: ' + (s.claimReceived ? '✅ mila' : '⏳ pending') : '') + '</small></div><b>' + U.money(s.amount) + '</b></div>').join('') + '</div>' : '') +
        '<div class="card"><h3>🛡️ Insurance & 🪪 RTO</h3><div class="kv">' + kv('Company', t(c.insCompany)) + kv('Policy No', t(c.policyNo)) + kv('Period', c.insFrom ? d(c.insFrom) + ' → ' + d(c.insTo) : '') +
        kv('Premium', c.insPremium ? U.money(c.insPremium) : '') + kv('IDV', c.idv ? U.money(c.idv) : '') + kv('Reg No', t(c.regNo)) + kv('RTO Status', t(c.rtoStatus)) + kv('RTO Date', d(c.rtoDate)) +
        kv('Number Plate', t(c.plateStatus)) + '</div></div>' + (c.remark ? '<div class="card"><h3>Remark</h3><p>' + t(c.remark) + '</p></div>' : '');
    } else if (tab === 'ledger') {
      body = '<div class="card"><div class="table-wrap">' + Ledger.html(c, pays, calls, k) + '</div></div>';
    } else if (tab === 'finance') {
      const sch = Ch.emiSchedule(c);
      body = c.saleType !== 'Finance' ? U.empty('Ye Cash sale hai') :
        '<div class="card"><h3>🏦 Loan Details</h3><div class="kv">' + kv('Finance Company', t(c.financer)) + kv('Loan App No', t(c.loanAppNo)) + kv('Loan Amount', U.money(c.loanAmount)) +
        kv('Net Disbursal Expected', U.money(k.finAmt)) + kv('Disbursed', U.money(k.disbursed)) + kv('Pending', U.money(k.finDue)) + kv('Tenure', c.tenure ? c.tenure + ' months' : '') +
        kv('EMI', c.emi ? U.money(c.emi) : '') + kv('ROI', c.roi ? c.roi + '%' : '') + kv('EMI Start', d(c.emiStart)) + kv('Advance EMI', t(c.advanceEmi)) + kv('DO No', t(c.doNo)) +
        kv('Disbursed in', days(k.finDays)) + '</div>' +
        (Ch.can('edit') ? '<div class="grid2 mt">' + U.field('qLoan', 'Loan Status', c.loanStatus || 'Pending', { type: 'select', options: Ch.LOAN_STATUS }) +
          U.field('qFile', 'Loan File', c.loanFileStatus || 'Pending', { type: 'select', options: ['Pending', 'Complete'] }) + '</div>' +
          U.field('qRem', 'File Remark', c.fileRemark || '') + '<button class="btn sm" id="qSave">Update Status</button>' : kv('Loan File', t(c.loanFileStatus)) + kv('Remark', t(c.fileRemark))) + '</div>' +
        '<div class="card"><h3>Disbursements</h3>' + (pays.filter((x) => x.kind === 'Disbursement').map((x) => '<div class="li"><div class="grow"><b>' + U.money(x.amount) + '</b><small>' + d(x.date) + ' · ' + t(x.mode) + ' ' + t(x.ref) + '</small></div></div>').join('') || U.empty('Abhi disbursement nahi aaya')) + '</div>' +
        '<div class="card"><h3>EMI Schedule</h3>' + (sch.length ? '<div class="table-wrap"><table class="tbl"><thead><tr><th>#</th><th>Date</th><th>EMI</th><th>Status</th></tr></thead><tbody>' +
          sch.map((r) => '<tr><td>' + r.no + '</td><td>' + d(r.date) + '</td><td>' + U.money(r.emi) + '</td><td>' + r.status + '</td></tr>').join('') +
          '</tbody><tfoot><tr><td></td><td>Total</td><td>' + U.money(sch.length * n(c.emi)) + '</td><td></td></tr></tfoot></table></div>' : U.empty('EMI, tenure aur EMI start date bharein')) + '</div>';
    } else if (tab === 'docs') {
      files.filter((f) => f.byCustomer && !f.seen).forEach((f) => { DB.update('cfilemeta', f.id, { seen: true }).catch(() => { }); });
      body = '<div class="card">' + (Ch.can('upload') ? '<button class="btn sm" id="aUp2">📎 Upload Document</button>' : '') +
        (files.length ? files.map((f) => '<div class="li doc-li"><span class="doc-ic">' + (/image/.test(f.mime) ? '🖼️' : /pdf/.test(f.mime) ? '📕' : '📄') + '</span><div class="grow"><b>' + t(f.kind) + (f.byCustomer ? ' <span class="badge info">Customer ne bheja</span>' : '') + '</b><small>' +
          t(f.name) + ' · ' + Math.round((f.size || 0) / 1024) + ' KB · ' + t(f.byName) + ' · ' + U.fmtDT(f.at) + '</small></div><button class="btn ghost sm" data-open="' + f.id + '">View</button>' +
          (Ch.can('deleteFile') ? '<button class="icon-btn" data-fdel="' + f.id + '">🗑</button>' : '') + '</div>').join('') : U.empty('Koi document upload nahi hua')) +
        '<p class="muted small">Pending docs: ' + esc(S.cs.docTypes.filter((x) => x !== 'Other' && !files.some((f) => f.kind === x)).join(', ') || 'koi nahi') + '</p></div>';
    } else if (tab === 'calls') {
      body = '<div class="card">' + (Ch.can('calling') ? '<button class="btn sm" id="aCall2">📞 New Call Entry</button>' : '') +
        (calls.length ? calls.map((x) => '<div class="li"><div class="grow"><b>' + t(x.outcome) + '</b> <small class="muted">' + U.fmtDT(x.at) + ' · ' + t(x.byName) + '</small><p>' + t(x.remark) + '</p><small>' +
          (x.promiseDate ? 'Promise: ' + d(x.promiseDate) + ' ' + (x.promiseAmount ? U.money(x.promiseAmount) : '') + ' · ' : '') + (x.nextDate ? 'Next: ' + d(x.nextDate) : '') + ' · Due tab: ' + U.money(x.dueAtCall) + '</small></div></div>').join('') : U.empty('Abhi koi call nahi')) + '</div>';
    } else {
      const ev = [[c.challanDate, 'Sale / Challan', c.challanNo, 0]];
      if (c.invoiceDate) ev.push([c.invoiceDate, 'Billing (Invoice ' + (c.invoiceNo || '') + ')', '', k.billDays]);
      if (c.deliveryDate) ev.push([c.deliveryDate, 'Delivery', '', Ch.daysBetween(c.challanDate, c.deliveryDate)]);
      if (c.insFrom) ev.push([c.insFrom, 'Insurance start', c.policyNo || '', Ch.daysBetween(c.challanDate, c.insFrom)]);
      if (c.rtoDate) ev.push([c.rtoDate, 'RTO applied', c.regNo || '', Ch.daysBetween(c.challanDate, c.rtoDate)]);
      pays.forEach((x) => ev.push([x.date, x.kind + ' ' + U.money(x.amount), x.mode + ' ' + (x.ref || ''), Ch.daysBetween(c.challanDate, x.date)]));
      calls.forEach((x) => ev.push([x.date, '📞 ' + x.outcome, x.remark, Ch.daysBetween(c.challanDate, x.date)]));
      ev.sort((a, b) => String(a[0]).localeCompare(String(b[0])));
      body = '<div class="card"><div class="stats4"><div><b>' + days(k.billDays) + '</b><small>Sale → Billing</small></div><div><b>' + (c.saleType === 'Finance' ? days(k.finDays) || 'Pending' : '-') +
        '</b><small>Sale → Finance</small></div><div><b>' + (k.lastPayDate ? d(k.lastPayDate) : '-') + '</b><small>Last payment</small></div><div><b>' + (k.due > 0.5 ? k.dueDays + ' din' : 'Clear') +
        '</b><small>Due age</small></div></div><div class="timeline">' + ev.map((e) => '<div><b>' + d(e[0]) + '</b> <small class="muted">' + (e[3] != null ? '+' + e[3] + ' din' : '') + '</small><br>' + esc(e[1]) +
        (e[2] ? ' <small class="muted">' + esc(e[2]) + '</small>' : '') + '</div>').join('') + '</div></div>';
    }

    el.innerHTML = '<div class="row-between"><button class="btn ghost sm" onclick="history.length>1&&S.back?App.go(S.back.v,S.back.p):App.go(\'list\')">← Back</button></div>' + head +
      '<div class="tabs">' + tabs.map((x) => '<button data-tab="' + x[0] + '" class="' + (x[0] === tab ? 'on' : '') + '">' + x[1] + '</button>').join('') + '</div>' + body;

    U.$$('[data-tab]').forEach((b) => b.onclick = () => reload(b.dataset.tab));
    const on = (id, fn) => { const b = U.$('#' + id); if (b) b.onclick = fn; };
    on('aPay', () => Pay.dialog(c, 'Payment', null, () => reload('ledger')));
    on('aDisb', () => Pay.dialog(c, 'Disbursement', null, () => reload('finance')));
    on('aCall', () => Calls.dialog(c, () => reload('calls'))); on('aCall2', () => Calls.dialog(c, () => reload('calls')));
    on('aUp', () => Docs.uploadDialog(c, () => reload('docs'))); on('aUp2', () => Docs.uploadDialog(c, () => reload('docs')));
    on('aLet', () => Cust.lettersDialog(c, k)); on('aCust', () => Cust.loginDialog(c, () => reload()));
    on('aPdf', () => Print.challan(c, pays, k)); on('aSt', () => Print.statement(c, pays, calls, k));
    on('aDel', async () => {
      if (!(await U.confirm('Challan ' + c.challanNo + ' aur uski saari entries/documents delete ho jayengi. Pakka?', 'Delete'))) return;
      U.loading(true);
      try {
        for (const f of files) await Files.del('cfiledata', f.id);
        await DB.batch(pays.map((x) => ['delete', 'cpay', x.id]).concat(calls.map((x) => ['delete', 'ccalls', x.id]), files.map((x) => ['delete', 'cfilemeta', x.id]), [['delete', 'challans', c.id]]));
        Ch.dirty(); U.toast(T('deleted'), 'ok'); App.go('list');
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    });
    on('qSave', async () => {
      U.loading(true);
      try { await DB.update('challans', c.id, { loanStatus: U.$('[name=qLoan]').value, loanFileStatus: U.$('[name=qFile]').value, fileRemark: U.$('[name=qRem]').value.trim() }); Ch.dirty(); U.toast(T('saved'), 'ok'); reload('finance'); }
      catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    });
    U.$$('[data-open]').forEach((b) => b.onclick = () => Docs.open(files.find((f) => f.id === b.dataset.open)));
    U.$$('[data-fdel]').forEach((b) => b.onclick = () => Docs.remove(files.find((f) => f.id === b.dataset.fdel), () => reload('docs')));
    U.$$('[data-pedit]').forEach((b) => b.onclick = () => Pay.dialog(c, null, pays.find((x) => x.id === b.dataset.pedit), () => reload('ledger')));
    U.$$('[data-pdel]').forEach((b) => b.onclick = () => Pay.remove(c, pays.find((x) => x.id === b.dataset.pdel), () => reload('ledger')));
  };

  // ===== Ledger rows (also used by PDF statement) =====
  const Ledger = window.Ledger = {};
  Ledger.rows = function (c, pays, calls, k) {
    const rows = [];
    const pr = c.price || {};
    Ch.priceItems().forEach((it) => { if (n(pr[it.k])) rows.push({ date: c.challanDate, part: it.l, dr: n(pr[it.k]), cr: 0 }); });
    if (k.discount) rows.push({ date: c.challanDate, part: 'Discount', dr: 0, cr: k.discount });
    (c.hasScheme ? c.schemes || [] : []).filter((s) => s.toCustomer && n(s.amount)).forEach((s) => rows.push({ date: c.challanDate, part: 'Scheme: ' + s.name, dr: 0, cr: n(s.amount) }));
    if (c.isExchange && n(c.exValue)) rows.push({ date: c.challanDate, part: 'Exchange: ' + (c.exOldModel || '') + ' ' + (c.exRegNo || ''), dr: 0, cr: n(c.exValue) });
    pays.forEach((p) => rows.push({ date: p.date, part: p.kind + ' (' + p.mode + (p.ref ? ' ' + p.ref : '') + ')' + (p.remark ? ' - ' + p.remark : ''), dr: p.kind === 'Refund' ? n(p.amount) : 0,
      cr: p.kind === 'Refund' ? 0 : n(p.amount), pay: p }));
    (calls || []).forEach((x) => rows.push({ date: x.date, part: '📞 ' + x.outcome + ': ' + x.remark + ' (' + (x.byName || '') + ')', dr: 0, cr: 0, call: true }));
    const head = rows.filter((r) => r.date === c.challanDate && !r.pay && !r.call);
    const rest = rows.filter((r) => !head.includes(r)).sort((a, b) => String(a.date).localeCompare(String(b.date)));
    let bal = 0;
    return head.concat(rest).map((r) => { bal = U.round2(bal + r.dr - r.cr); return Object.assign(r, { bal }); });
  };
  Ledger.html = function (c, pays, calls, k) {
    const rows = Ledger.rows(c, pays, calls, k);
    const canE = Ch.can('editPayment');
    const tdr = rows.reduce((s, r) => s + r.dr, 0), tcr = rows.reduce((s, r) => s + r.cr, 0);
    return '<table class="tbl ledger"><thead><tr><th>Date</th><th>Particulars</th><th>Debit</th><th>Credit</th><th>Balance</th>' + (canE ? '<th></th>' : '') + '</tr></thead><tbody>' +
      rows.map((r) => '<tr class="' + (r.call ? 'call-row' : '') + '"><td>' + U.fmtDate(r.date) + '</td><td>' + esc(r.part) + '</td><td>' + (r.dr ? U.money(r.dr) : '') + '</td><td>' + (r.cr ? U.money(r.cr) : '') +
        '</td><td>' + (r.call ? '' : U.money(r.bal)) + '</td>' + (canE ? '<td>' + (r.pay ? '<button class="icon-btn" data-pedit="' + r.pay.id + '">✏️</button><button class="icon-btn" data-pdel="' + r.pay.id + '">🗑</button>' : '') + '</td>' : '') + '</tr>').join('') +
      '</tbody><tfoot><tr><td></td><td>Total / Balance Due</td><td>' + U.money(tdr) + '</td><td>' + U.money(tcr) + '</td><td>' + U.money(tdr - tcr) + '</td>' + (canE ? '<td></td>' : '') + '</tr></tfoot></table>';
  };
})();
