// ---------- Simple labels (Hinglish) ----------
(function () {
  const D = {
    pleaseWait: 'Please wait...', confirm: 'Confirm', cancel: 'Cancel', yes: 'Yes', ok: 'OK', autoFilled: 'auto',
    noData: 'Koi data nahi mila', savedDocuments: 'Documents folder me save ho gaya', saveFailed: 'Save nahi hua',
    gpsDenied: 'Location permission nahi mili', gpsFailed: 'Location nahi mili', error: 'Error', retry: 'Dobara try karein',
    loginNotFound: 'Ye mobile number registered nahi hai', accountInactive: 'Account inactive hai. Admin se baat karein.',
    noAccess: 'Aapko Challan App ka access nahi diya gaya hai. Admin se rights maangein.',
    wrongLogin: 'Mobile/Email ya password galat hai', tooMany: 'Bahut baar try kiya. Thodi der baad try karein.',
    noInternet: 'Internet connection check karein', pwdShort: 'Password kam se kam 6 akshar ka ho', pwdMismatch: 'Dono password same nahi hain',
    saved: 'Save ho gaya', deleted: 'Delete ho gaya', logoutConfirm: 'Logout karna hai?', logout: 'Logout'
  };
  window.I18N = { lang: 'en', init() { }, set() { } };
  window.T = function (k) {
    if (D[k]) return D[k];
    if (/^st_/.test(k)) return k.slice(3).replace(/_/g, ' ');
    return String(k).replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase());
  };
})();
