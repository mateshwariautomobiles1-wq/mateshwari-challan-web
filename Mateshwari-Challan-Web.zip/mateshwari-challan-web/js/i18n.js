// ---------- Labels + Hindi / English switch ----------
(function () {
  const D = {
    pleaseWait: 'Please wait...', confirm: 'Confirm', cancel: 'Cancel', yes: 'Yes', ok: 'OK', autoFilled: 'auto',
    noData: 'Koi data nahi mila', savedDocuments: 'Documents folder me save ho gaya', saveFailed: 'Save nahi hua',
    gpsDenied: 'Location permission nahi mili', gpsFailed: 'Location nahi mili', error: 'Error', retry: 'Dobara try karein',
    loginNotFound: 'Ye mobile number registered nahi hai', accountInactive: 'Account inactive hai. Admin se baat karein.',
    noAccess: 'Aapko Challan App ka access nahi diya gaya hai. Admin se rights maangein.',
    wrongLogin: 'Mobile/Email ya password galat hai', tooMany: 'Bahut baar try kiya. Thodi der baad try karein.',
    noInternet: 'Internet connection check karein', pwdShort: 'Password kam se kam 6 akshar ka ho', pwdMismatch: 'Dono password same nahi hain',
    saved: 'Save ho gaya', deleted: 'Delete ho gaya', logoutConfirm: 'Logout karna hai?', logout: 'Logout'
  };
  window.T = function (k) {
    if (D[k]) return D[k];
    if (/^st_/.test(k)) return k.slice(3).replace(/_/g, ' ');
    return String(k).replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase());
  };

  // English -> Hindi (exact phrase, emoji / * / : ignored while matching)
  const HI = {
    'Dashboard': 'डैशबोर्ड', 'All Challans': 'सभी चालान', 'Challans': 'चालान', 'Challan': 'चालान', 'New Challan': 'नया चालान', 'New': 'नया', 'Menu': 'मेन्यू', 'Search': 'खोज',
    'Calling': 'कॉलिंग', 'Due': 'बकाया', 'Reports': 'रिपोर्ट', 'Stock': 'स्टॉक', 'Logout': 'लॉगआउट', 'Login': 'लॉगिन', 'Password': 'पासवर्ड', 'Save': 'सेव करें',
    'Back': 'वापस', 'Edit': 'बदलें', 'Delete': 'हटाएं', 'View': 'देखें', 'Upload': 'अपलोड', 'Show': 'दिखाएं', 'Cancel': 'रद्द करें', 'Yes': 'हाँ', 'OK': 'ठीक है',
    'Due Payment List': 'बकाया भुगतान सूची', 'Down Payment Due': 'डाउन पेमेंट बकाया', 'Finance Disbursement Pending': 'फाइनेंस राशि बाकी', 'Loan File Status': 'लोन फाइल स्थिति',
    'Scheme / Claim Pending': 'स्कीम / क्लेम बाकी', 'Pendency List': 'पेंडेंसी सूची', 'Customer Ledger': 'ग्राहक खाता', 'Customer Search (Due warning)': 'ग्राहक खोज (बकाया चेतावनी)',
    'Number Plate / RC / Insurance': 'नंबर प्लेट / आरसी / बीमा', 'Insurance Renewal Follow-up': 'बीमा रिन्यूअल फॉलो-अप', 'DPD (Days Past Due)': 'डीपीडी (बकाया दिन)',
    'Delivery Flag Report': 'डिलीवरी फ्लैग रिपोर्ट', 'Masters (Model / Village / Finance / Price)': 'मास्टर (मॉडल / गाँव / फाइनेंस / रेट)', 'Import (Excel)': 'इम्पोर्ट (एक्सेल)',
    'Staff & Rights': 'स्टाफ और अधिकार', 'Settings & Masters': 'सेटिंग और मास्टर', 'Change Password': 'पासवर्ड बदलें',
    'New Delivery Challan': 'नया डिलीवरी चालान', 'Save Challan': 'चालान सेव करें', 'Customer': 'ग्राहक', 'Vehicle': 'वाहन', 'Invoice / Billing': 'इनवॉइस / बिलिंग',
    'On-Road Price': 'ऑन-रोड कीमत', 'Finance': 'फाइनेंस', 'Exchange': 'एक्सचेंज', 'Insurance': 'बीमा', 'RTO / RC': 'आरटीओ / आरसी', 'Remarks': 'टिप्पणी', 'Remark': 'टिप्पणी',
    'Challan No': 'चालान नंबर', 'Challan / Sale Date': 'चालान / बिक्री तारीख', 'Cash / Finance': 'नकद / फाइनेंस', 'Sales Executive': 'सेल्स एग्जीक्यूटिव',
    'Customer Name': 'ग्राहक का नाम', 'Father Name': 'पिता का नाम', 'Mobile No': 'मोबाइल नंबर', 'Alternate Mobile': 'दूसरा मोबाइल', 'City / Village': 'शहर / गाँव',
    'Date of Birth': 'जन्म तिथि', 'Aadhaar No': 'आधार नंबर', 'Address': 'पता', 'Model': 'मॉडल', 'Variant': 'वेरिएंट', 'Colour': 'रंग', 'Engine No': 'इंजन नंबर',
    'Chassis No': 'चेसिस नंबर', 'Key No': 'चाबी नंबर', 'Battery No': 'बैटरी नंबर', 'Delivery Date': 'डिलीवरी तारीख', 'Invoice No': 'इनवॉइस नंबर',
    'Invoice / Billing Date': 'इनवॉइस / बिलिंग तारीख', 'Invoice Amount': 'इनवॉइस राशि', 'Discount (customer)': 'छूट (ग्राहक)', 'Down Payment (agreed)': 'डाउन पेमेंट (तय)',
    'Finance Company': 'फाइनेंस कंपनी', 'Loan Application No': 'लोन आवेदन नंबर', 'Loan Amount': 'लोन राशि', 'Tenure (months)': 'अवधि (महीने)', 'EMI': 'ईएमआई',
    'EMI Start Date': 'ईएमआई शुरू तारीख', 'Loan Status': 'लोन स्थिति', 'Loan File': 'लोन फाइल', 'Insurance Company': 'बीमा कंपनी', 'Policy No': 'पॉलिसी नंबर',
    'Policy From': 'पॉलिसी से', 'Policy To': 'पॉलिसी तक', 'OD Cover Expiry (renewal)': 'OD कवर समाप्ति (रिन्यूअल)', 'Third Party Expiry': 'थर्ड पार्टी समाप्ति',
    'Registration No': 'रजिस्ट्रेशन नंबर', 'Registration Date': 'रजिस्ट्रेशन तारीख', 'RTO Status': 'आरटीओ स्थिति', 'Payable': 'देय', 'Received': 'प्राप्त',
    'Customer Payable': 'ग्राहक देय', 'On-Road Total': 'ऑन-रोड कुल', 'Down Payment banta': 'डाउन पेमेंट बनता', 'Balance Due': 'बकाया राशि', 'Total Due': 'कुल बकाया',
    'Payment': 'भुगतान', 'Payment Entry': 'भुगतान एंट्री', 'Payment Received Date': 'भुगतान प्राप्ति तारीख', 'Amount': 'राशि', 'Mode': 'माध्यम', 'Type': 'प्रकार', 'Date': 'तारीख',
    'Summary': 'सारांश', 'Ledger': 'खाता', 'Documents': 'दस्तावेज़', 'Calls': 'कॉल', 'Track': 'ट्रैक', 'Finance / EMI': 'फाइनेंस / ईएमआई',
    'Particulars': 'विवरण', 'Debit': 'नामे', 'Credit': 'जमा', 'Balance': 'शेष', 'Total / Balance Due': 'कुल / बकाया',
    'Number Plate Showroom par': 'नंबर प्लेट शोरूम पर', 'Number Plate Customer ko': 'नंबर प्लेट ग्राहक को', 'RC Customer ko': 'आरसी ग्राहक को', 'Insurance Customer ko': 'बीमा ग्राहक को',
    'Not Received': 'नहीं आई', 'Not Given': 'नहीं दी', 'Given': 'दे दी', 'Pending': 'बाकी', 'Complete': 'पूरा', 'Done': 'हो गया', 'Clear': 'चुकता', 'Cash': 'नकद', 'Bank': 'बैंक',
    'Report': 'रिपोर्ट', 'From': 'से', 'To': 'तक', 'Excel': 'एक्सेल', 'PDF': 'पीडीएफ', 'Records': 'रिकॉर्ड', 'Total Sale': 'कुल बिक्री', 'Cash Sale': 'नकद बिक्री', 'Finance Sale': 'फाइनेंस बिक्री',
    'Customer Collection': 'ग्राहक वसूली', 'Income': 'आय', 'Settings': 'सेटिंग', 'Developed by': 'विकसित:', 'Stock se gaadi chunein (auto-fill)': 'स्टॉक से गाड़ी चुनें (ऑटो-फिल)',
    'In Stock': 'स्टॉक में', 'Delivered': 'डिलीवर', 'Add Vehicle': 'गाड़ी जोड़ें', 'Customer Photo': 'ग्राहक फोटो', 'Delivery Photo': 'डिलीवरी फोटो', 'Manual Challan Photo': 'हाथ का चालान फोटो'
  };
  const HI_LC = {}; Object.keys(HI).forEach((k) => HI_LC[k.toLowerCase()] = HI[k]);

  let lang = 'en';
  try { lang = localStorage.getItem('chLang') || 'en'; } catch (e) { }
  window.I18N = {
    get lang() { return lang; },
    init() { if (lang === 'hi') startObserver(); },
    set(l) { try { localStorage.setItem('chLang', l); } catch (e) { } location.reload(); }
  };

  const SPLIT = /^([^A-Za-z]*)(.*?)([\s\*:]*)$/;
  function tr(str) {
    if (!str || !/[A-Za-z]/.test(str)) return null;
    const m = SPLIT.exec(str); if (!m) return null;
    const core = m[2].trim(); if (!core) return null;
    const h = HI_LC[core.toLowerCase()];
    return h ? m[1] + h + m[3] : null;
  }
  function walk(node) {
    if (node.nodeType === 3) { const t = tr(node.nodeValue); if (t) node.nodeValue = t; return; }
    if (node.nodeType !== 1 || node.tagName === 'SCRIPT' || node.tagName === 'STYLE' || node.tagName === 'TEXTAREA') return;
    if (node.placeholder) { const t = tr(node.placeholder); if (t) node.placeholder = t; }
    if (node.title) { const t = tr(node.title); if (t) node.title = t; }
    if (node.tagName === 'OPTION' && node.textContent) { const t = tr(node.textContent); if (t) node.textContent = t; return; }
    for (const ch of Array.from(node.childNodes)) walk(ch);
  }
  function startObserver() {
    document.documentElement.lang = 'hi';
    const run = () => { const a = document.body; if (a) walk(a); };
    new MutationObserver((muts) => muts.forEach((m) => m.addedNodes.forEach(walk))).observe(document.documentElement, { childList: true, subtree: true });
    if (document.readyState !== 'loading') run(); else document.addEventListener('DOMContentLoaded', run);
  }
  I18N.init();
})();
