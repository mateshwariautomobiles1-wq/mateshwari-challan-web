// ---------- Payments, documents, calls ----------
(function () {
  const esc = U.esc, n = U.num;

  // ===== Payments / Disbursements =====
  const Pay = window.Pay = {};
  Pay.save = async function (p, id) {
    const me = Ch.me();
    const doc = Object.assign({ ref: '', remark: '' }, p, { amount: n(p.amount), byId: me.id, byName: me.name, at: DB.now() });
    if (id) await DB.set('cpay', id, doc, true); else await DB.add('cpay', doc);
  };
  // c = challan; kind: 'Payment' | 'Disbursement'; existing = payment to edit
  Pay.dialog = function (c, kind, existing, done) {
    const e = existing || {};
    kind = e.kind || kind;
    const isDisb = kind === 'Disbursement';
    const kinds = isDisb ? ['Disbursement'] : Ch.PAY_KINDS.filter((x) => x !== 'Disbursement');
    const k = Ch.calc(c);
    const hint = isDisb ? 'Finance pending: ' + U.money(k.finDue) : 'Total due: ' + U.money(k.due) + ' · DP due: ' + U.money(k.dpDue);
    const m = U.modal((existing ? 'Edit ' : '') + (isDisb ? 'Finance Disbursement' : 'Payment Entry') + ' · ' + c.challanNo,
      '<p class="muted small">' + esc(c.customerName) + ' · ' + hint + '</p><form class="form" id="pf"><div class="grid2">' +
      U.field('date', 'Date', e.date || U.dateKey(), { type: 'date', required: true }) +
      U.field('amount', 'Amount', e.amount || (isDisb ? (k.finDue || '') : ''), { type: 'number', step: '0.01', required: true }) +
      U.field('kind', 'Type', kind === 'Payment' ? (k.dpDue > 0 ? 'Down Payment' : 'Payment') : kind, { type: 'select', options: kinds }) +
      U.field('mode', 'Mode (Bank / Cash)', e.mode || (isDisb ? 'Bank' : 'Cash'), { type: 'select', options: Ch.PAY_MODES }) +
      U.field('ref', isDisb ? 'UTR / Ref No' : 'Receipt / UTR / Cheque No', e.ref || '') +
      (isDisb ? U.field('bank', 'Received in Bank', e.bank || '') : U.field('bank', 'Bank (agar bank me aaya)', e.bank || '')) + '</div>' +
      U.field('remark', 'Remark', e.remark || '', { type: 'textarea', rows: 2 }) +
      '<button class="btn block">Save</button></form>', {
      onOpen: (w) => {
        U.$('#pf', w).onsubmit = async (ev) => {
          ev.preventDefault(); const d = U.formData(ev.target);
          if (!(n(d.amount) > 0)) return U.toast('Amount daalein', 'err');
          U.loading(true);
          try {
            await Pay.save(Object.assign(d, { challanId: c.id, challanNo: c.challanNo, customerName: c.customerName, ownerId: c.ownerId }), existing && existing.id);
            await Ch.recompute(c.id); m.close(); U.toast('Entry save ho gayi', 'ok'); done && done();
          } catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
        };
      }
    });
  };
  Pay.remove = async function (c, p, done) {
    if (!(await U.confirm('Ye entry delete karein? ' + U.money(p.amount) + ' (' + p.kind + ')', 'Delete'))) return;
    U.loading(true);
    try { await DB.del('cpay', p.id); await Ch.recompute(c.id); U.toast(T('deleted'), 'ok'); done && done(); }
    catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
  };

  // ===== Documents (photo / pdf / any file) =====
  const Docs = window.Docs = {};
  Docs.save = async function (challanId, ownerId, challanNo, f, byCustomer) {
    const id = DB.newId('cfilemeta');
    const me = Ch.me();
    const meta = { challanId, ownerId, kind: f.kind }; if (byCustomer) meta.byCustomer = true;
    await Files.put('cfiledata', id, meta, f.data);
    await DB.set('cfilemeta', id, Object.assign({ challanId, challanNo: challanNo || '', ownerId, kind: f.kind, name: f.name || f.kind, mime: f.mime || '',
      size: Math.round((f.data || '').length * 0.75), byId: me.id, byName: me.name, at: DB.now() }, byCustomer ? { byCustomer: true, seen: false } : {}));
    Ch.dirty('files');
    return id;
  };
  Docs.uploadDialog = function (c, done) {
    const m = U.modal('Document Upload · ' + c.challanNo, '<form class="form" id="uf">' +
      U.field('kind', 'Document Type', S.cs.docTypes[0], { type: 'select', options: c.byCustomer ? ['Aadhaar Card', 'PAN Card', 'Bank Statement', 'Photo', 'Other'] : S.cs.docTypes }) +
      U.field('name', 'Naam / Note (optional)', '') +
      '<div class="row-btns left"><button type="button" class="btn ghost" data-src="camera">📷 Camera</button><button type="button" class="btn ghost" data-src="file">📁 File (PDF/Image)</button></div>' +
      '<p class="muted small" id="ufn">Koi file nahi chuni</p><button class="btn block">Upload</button></form>', {
      onOpen: (w) => {
        let picked = null;
        U.$$('[data-src]', w).forEach((b) => b.onclick = async () => {
          const file = await U.pickFile(b.dataset.src === 'camera' ? 'image/*' : 'application/pdf,image/*,.doc,.docx,.xls,.xlsx');
          if (!file) return;
          if (file.size > Files.MAX) return U.toast('File 8 MB se badi hai', 'err');
          const isImg = /^image\//.test(file.type);
          picked = { name: file.name, mime: isImg ? 'image/jpeg' : (file.type || 'application/octet-stream'), data: isImg ? await U.compressImage(file, 1600, 0.8) : await U.fileToDataURL(file) };
          U.$('#ufn', w).textContent = '✔ ' + file.name + ' (' + Math.round(file.size / 1024) + ' KB)';
        });
        U.$('#uf', w).onsubmit = async (ev) => {
          ev.preventDefault(); if (!picked) return U.toast('Pehle file chunein', 'err');
          const d = U.formData(ev.target);
          U.loading(true, 'Upload ho raha hai...');
          try {
            await Docs.save(c.id, c.ownerId, c.challanNo, Object.assign(picked, { kind: d.kind, name: d.name || picked.name }), !!c.byCustomer);
            if (!c.byCustomer && d.kind === 'Customer Photo' && /^image/.test(picked.mime)) {
              const img = await new Promise((r) => { const i = new Image(); i.onload = () => r(i); i.src = picked.data; });
              const cv = document.createElement('canvas'); const sc = 160 / Math.max(img.width, img.height); cv.width = img.width * sc; cv.height = img.height * sc;
              cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
              await DB.update('challans', c.id, { photoThumb: cv.toDataURL('image/jpeg', 0.6) }); Ch.dirty();
            }
            m.close(); U.toast('Upload ho gaya', 'ok'); done && done();
          } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
        };
      }
    });
  };
  Docs.open = async function (meta) {
    U.loading(true, 'File khul rahi hai...');
    try {
      const f = await Files.get('cfiledata', meta.id);
      if (!f || !f.data) throw new Error('File nahi mili');
      if (/^data:image/.test(f.data)) {
        U.modal(meta.kind + ' · ' + meta.name, '<img src="' + f.data + '" style="width:100%;border-radius:10px"><div class="row-btns"><button class="btn" id="dlimg">⬇ Download / Share</button></div>', {
          wide: true, onOpen: (w) => { U.$('#dlimg', w).onclick = () => U.openDataUrl((meta.name || 'photo').replace(/\.[a-z]+$/i, '') + '.jpg', f.data); }
        });
      } else U.openDataUrl(meta.name || 'document', f.data);
    } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
  };
  Docs.remove = async function (meta, done) {
    if (!(await U.confirm('Document delete karein? ' + meta.kind, 'Delete'))) return;
    U.loading(true);
    try { await Files.del('cfiledata', meta.id); await DB.del('cfilemeta', meta.id); Ch.dirty('files'); done && done(); }
    catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
  };

  // ===== Calling / follow-up (goes into customer ledger) =====
  const Calls = window.Calls = {};
  Calls.dialog = function (c, done) {
    const k = Ch.calc(c);
    const m = U.modal('Call Entry · ' + c.customerName,
      '<div class="call-head"><a class="btn" href="tel:' + esc(c.mobile) + '">📞 Call ' + esc(c.mobile) + '</a>' +
      '<a class="btn ghost" target="_blank" href="https://wa.me/91' + esc(c.mobile) + '?text=' + encodeURIComponent('Namaste ' + (c.customerName || '') + ' ji, ' +
        (S.company && S.company.name || APP_INFO.showroom) + ' se. Aapke vehicle (' + (c.model || '') + ') ka baki amount ' + U.moneyPlain(k.due) + ' hai. Kripya jald jama karein.') + '">WhatsApp</a></div>' +
      '<p class="muted small">Due: <b>' + U.money(k.due) + '</b> · ' + (k.dueDays || 0) + ' din se · Challan ' + esc(c.challanNo) + '</p><form class="form" id="cf"><div class="grid2">' +
      U.field('outcome', 'Result', 'Promise to Pay', { type: 'select', options: Ch.CALL_OUTCOMES }) +
      U.field('nextDate', 'Next Follow-up Date', '', { type: 'date' }) +
      U.field('promiseDate', 'Payment Promise Date', '', { type: 'date' }) + U.field('promiseAmount', 'Promise Amount', '', { type: 'number' }) + '</div>' +
      U.field('remark', 'Remark (ledger me dikhega)', '', { type: 'textarea', rows: 3, required: true }) + '<button class="btn block">Save Call</button></form>', {
      onOpen: (w) => {
        U.$('#cf', w).onsubmit = async (ev) => {
          ev.preventDefault(); const d = U.formData(ev.target);
          if (!d.remark) return U.toast('Remark likhein', 'err');
          const me = Ch.me(); U.loading(true);
          try {
            await DB.add('ccalls', Object.assign(d, { promiseAmount: n(d.promiseAmount), challanId: c.id, challanNo: c.challanNo, customerName: c.customerName, mobile: c.mobile,
              ownerId: c.ownerId, date: U.dateKey(), dueAtCall: k.due, byId: me.id, byName: me.name, at: DB.now() }));
            await DB.update('challans', c.id, { lastCallDate: U.dateKey(), lastCallRemark: d.outcome + ': ' + d.remark, nextFollow: d.nextDate || d.promiseDate || '', promiseDate: d.promiseDate || '',
              callCount: DB.inc(1) });
            Ch.dirty(); m.close(); U.toast('Call save ho gayi', 'ok'); done && done();
          } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
        };
      }
    });
  };
})();
