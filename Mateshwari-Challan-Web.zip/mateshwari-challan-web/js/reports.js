// ---------- Reports + Excel / PDF / Tally export ----------
(function () {
  const V = window.Views, esc = U.esc, n = U.num;
  const R = window.Reports = {};
  const fd = (v) => (v ? U.fmtDate(v) : '');
  const sum = (a, f) => U.round2(a.reduce((s, x) => s + n(f(x)), 0));

  R.TYPES = [
    ['sales', 'Sales Register (sab details)'], ['finance', 'Finance Company-wise Summary'], ['loanreg', 'Loan / Finance Case Register'], ['collection', 'Collection Register (Cash/Bank)'],
    ['daybook', 'Day-wise Sale & Collection'], ['due', 'Due Payment + Ageing'], ['dpdue', 'Down Payment Due'], ['findue', 'Finance Disbursement Pending'], ['income', 'Income / Margin Report'],
    ['insurance', 'Insurance Register'], ['rto', 'RTO Register'], ['exchange', 'Exchange Register'], ['scheme', 'Scheme / Campaign / Claim Register'], ['model', 'Model & Colour-wise Sale'],
    ['exec', 'Executive-wise Sale'], ['tat', 'Tracking: Sale → Billing → Finance → Payment (days)'], ['pendency', 'Pendency Report'], ['calls', 'Call Log / Follow-up'], ['customers', 'Customer Master']
  ];

  R.build = async function (type, from, to) {
    const all = (await Ch.challans()).filter((c) => !c.cancelled);
    const inR = all.filter((c) => Ch.inRange(c.challanDate, from, to));
    const sub = (from ? fd(from) : 'Start') + ' to ' + (to ? fd(to) : fd(U.dateKey()));
    const inc = Ch.can('viewIncome');
    const items = Ch.priceItems();
    if (type === 'sales') {
      const cols = ['Challan No', 'Date', 'Customer', 'Father', 'Mobile', 'Address', 'City', 'Model', 'Variant', 'Colour', 'Engine No', 'Chassis No', 'Invoice No', 'Invoice Date', 'Invoice Amt', 'Type', 'Financer', 'Loan App No', 'Loan Amt']
        .concat(items.map((i) => i.l), ['Discount', 'Scheme', 'Payable', 'Exchange', 'Cust Paid', 'Disbursed', 'Due', 'Insurance Co', 'Policy No', 'Reg No', 'RTO', 'Executive', 'Entry By'], inc ? ['Income'] : []);
      return { title: 'Sales Register', sub, columns: cols, rows: inR.map((c) => { const k = Ch.calc(c); return [c.challanNo, fd(c.challanDate), c.customerName, c.fatherName, c.mobile, c.address, c.city, c.model, c.variant, c.colour, c.engineNo, c.chassisNo,
        c.invoiceNo, fd(c.invoiceDate), n(c.invoiceAmount), c.saleType, c.financer, c.loanAppNo, n(c.loanAmount)].concat(items.map((i) => n((c.price || {})[i.k])),
        [k.discount, k.custScheme, k.payable, k.exValue, k.custPaid, k.disbursed, k.due, c.insCompany, c.policyNo, c.regNo, c.rtoStatus, c.executive, c.createdByName], inc ? [k.income] : []).map((v) => (v == null ? '' : v)); }) };
    }
    if (type === 'finance') {
      const g = {}; inR.filter((c) => c.saleType === 'Finance').forEach((c) => { (g[c.financer || '—'] = g[c.financer || '—'] || []).push(c); });
      const rows = Object.keys(g).map((f) => [f, g[f].length, sum(g[f], (c) => c.loanAmount), sum(g[f], (c) => c.sumDisbursed), sum(g[f], (c) => c.finDue), g[f].filter((c) => (c.loanFileStatus || 'Pending') === 'Pending').length,
        g[f].filter((c) => c.loanFileStatus === 'Complete').length, U.round2(sum(g[f], (c) => c.loanAmount) / g[f].length)]);
      return { title: 'Finance Company-wise Business', sub, columns: ['Finance Company', 'Cases', 'Loan Amount', 'Disbursed', 'Pending', 'Files Pending', 'Files Complete', 'Avg Loan'], rows,
        foot: ['TOTAL', sum(rows, (r) => r[1]), sum(rows, (r) => r[2]), sum(rows, (r) => r[3]), sum(rows, (r) => r[4]), sum(rows, (r) => r[5]), sum(rows, (r) => r[6]), ''] };
    }
    if (type === 'loanreg') {
      const L = inR.filter((c) => c.saleType === 'Finance');
      return { title: 'Loan / Finance Case Register', sub, columns: ['Challan', 'Date', 'Customer', 'Mobile', 'Financer', 'Loan App No', 'Loan Amt', 'Tenure', 'EMI', 'ROI', 'EMI Start', 'Status', 'File', 'Disbursed', 'Disb. Date', 'Pending', 'Days', 'Remark'],
        rows: L.map((c) => [c.challanNo, fd(c.challanDate), c.customerName, c.mobile, c.financer, c.loanAppNo, n(c.loanAmount), c.tenure || '', n(c.emi), c.roi || '', fd(c.emiStart), c.loanStatus, c.loanFileStatus || 'Pending',
          n(c.sumDisbursed), fd(c.disbDate), n(c.finDue), c.disbDate ? Ch.daysBetween(c.challanDate, c.disbDate) : Ch.daysBetween(c.challanDate), c.fileRemark || '']),
        foot: ['', '', 'TOTAL', '', '', '', sum(L, (c) => c.loanAmount), '', '', '', '', '', '', sum(L, (c) => c.sumDisbursed), '', sum(L, (c) => c.finDue), '', ''] };
    }
    if (type === 'collection' || type === 'daybook') {
      const pays = (await Ch.allPayments()).filter((p) => Ch.inRange(p.date, from, to)).sort((a, b) => String(a.date).localeCompare(String(b.date)));
      if (type === 'collection') return { title: 'Collection Register', sub, columns: ['Date', 'Challan', 'Customer', 'Type', 'Mode', 'Cash', 'Bank/UPI/Finance', 'Ref', 'Remark', 'Entered By'],
        rows: pays.map((p) => { const a = n(p.amount) * (p.kind === 'Refund' ? -1 : 1); return [fd(p.date), p.challanNo, p.customerName, p.kind, p.mode, p.mode === 'Cash' ? a : 0, p.mode === 'Cash' ? 0 : a, p.ref || '', p.remark || '', p.byName || '']; }),
        foot: ['', '', 'TOTAL', '', '', sum(pays.filter((p) => p.mode === 'Cash'), (p) => n(p.amount) * (p.kind === 'Refund' ? -1 : 1)), sum(pays.filter((p) => p.mode !== 'Cash'), (p) => n(p.amount) * (p.kind === 'Refund' ? -1 : 1)), '', '', ''] };
      const dk = {}; inR.forEach((c) => { const x = dk[c.challanDate] = dk[c.challanDate] || [0, 0, 0, 0, 0, 0]; x[0]++; if (c.saleType === 'Finance') x[1]++; x[2] += n(c.payable); });
      pays.forEach((p) => { const x = dk[p.date] = dk[p.date] || [0, 0, 0, 0, 0, 0]; const a = n(p.amount) * (p.kind === 'Refund' ? -1 : 1); if (p.kind === 'Disbursement') x[5] += a; else if (p.mode === 'Cash') x[3] += a; else x[4] += a; });
      const rows = Object.keys(dk).sort().map((d) => [fd(d), dk[d][0], dk[d][0] - dk[d][1], dk[d][1], U.round2(dk[d][2]), U.round2(dk[d][3]), U.round2(dk[d][4]), U.round2(dk[d][5])]);
      return { title: 'Day-wise Sale & Collection', sub, columns: ['Date', 'Sale', 'Cash Sale', 'Finance Sale', 'Payable', 'Cash Coll.', 'Bank Coll.', 'Disbursed'], rows,
        foot: ['TOTAL'].concat([1, 2, 3, 4, 5, 6, 7].map((i) => sum(rows, (r) => r[i]))) };
    }
    if (type === 'due' || type === 'dpdue' || type === 'findue') {
      const key = type === 'due' ? 'due' : type === 'dpdue' ? 'dpDue' : 'finDue';
      const L = inR.filter((c) => n(c[key]) > 0.5).map((c) => Object.assign(c, { _d: Ch.daysBetween(c.challanDate) })).sort((a, b) => b._d - a._d);
      return { title: { due: 'Due Payment Report', dpdue: 'Down Payment Due', findue: 'Finance Disbursement Pending' }[type], sub,
        columns: ['Challan', 'Date', 'Customer', 'Father', 'Mobile', 'Model', 'Type', 'Financer', 'Payable', 'Received', 'Amount Due', 'Days', 'Ageing', 'Last Payment', 'Last Call', 'Next Follow-up'],
        rows: L.map((c) => [c.challanNo, fd(c.challanDate), c.customerName, c.fatherName, c.mobile, c.model, c.saleType, c.financer || '', n(c.payable), n(c.received), n(c[key]), c._d, Ch.ageBucket(c._d), fd(c.lastPayDate), c.lastCallRemark || '', fd(c.nextFollow)]),
        foot: ['', '', 'TOTAL', '', '', '', '', '', sum(L, (c) => c.payable), sum(L, (c) => c.received), sum(L, (c) => c[key]), '', '', '', '', ''] };
    }
    if (type === 'income') {
      if (!inc) throw new Error('Income dekhne ka right nahi hai');
      const cols = ['Challan', 'Date', 'Customer', 'Model'].concat(items.map((i) => i.l + ' margin'), ['Vehicle Margin', 'Company Claim', 'Discount+Scheme', 'Other', 'Income', 'Mode']);
      const rows = inR.map((c) => { const k = Ch.calc(c); return [c.challanNo, fd(c.challanDate), c.customerName, c.model].concat(items.map((i) => { const co = (c.cost || {})[i.k]; return co == null || co === '' ? '' : U.round2(n((c.price || {})[i.k]) - n(co)); }),
        [n(c.dealerMargin), k.claimScheme, U.round2(k.discount + k.custScheme), n(c.otherIncome), k.income, c.incomeManual !== undefined && c.incomeManual !== '' ? 'Manual' : 'Auto']); });
      return { title: 'Income / Margin Report', sub, columns: cols, rows, foot: ['', '', 'TOTAL', ''].concat(items.map(() => ''), ['', '', '', '', sum(rows, (r) => r[r.length - 2]), '']) };
    }
    if (type === 'insurance') return { title: 'Insurance Register', sub, columns: ['Challan', 'Date', 'Customer', 'Mobile', 'Model', 'Chassis', 'Engine', 'Ins. Company', 'Policy No', 'From', 'To', 'Premium', 'IDV', 'Charged'].concat(inc ? ['Cost', 'Margin'] : []),
      rows: inR.map((c) => [c.challanNo, fd(c.challanDate), c.customerName, c.mobile, c.model, c.chassisNo, c.engineNo, c.insCompany || '', c.policyNo || 'PENDING', fd(c.insFrom), fd(c.insTo), n(c.insPremium), n(c.idv), n((c.price || {}).insurance)]
        .concat(inc ? [n((c.cost || {}).insurance), U.round2(n((c.price || {}).insurance) - n((c.cost || {}).insurance))] : [])) };
    if (type === 'rto') return { title: 'RTO Register', sub, columns: ['Challan', 'Date', 'Customer', 'Father', 'Mobile', 'Model', 'Chassis', 'Engine', 'Reg No', 'RTO Status', 'Applied', 'Plate', 'RTO Charged'].concat(inc ? ['RTO Cost'] : []),
      rows: inR.map((c) => [c.challanNo, fd(c.challanDate), c.customerName, c.fatherName, c.mobile, c.model, c.chassisNo, c.engineNo, c.regNo || '', c.rtoStatus || 'Pending', fd(c.rtoDate), c.plateStatus || 'Pending', n((c.price || {}).rto)].concat(inc ? [n((c.cost || {}).rto)] : [])) };
    if (type === 'exchange') { const L = inR.filter((c) => c.isExchange); return { title: 'Exchange Register', sub, columns: ['Challan', 'Date', 'Customer', 'Mobile', 'New Model', 'Old Vehicle', 'Old Reg No', 'Year', 'Owner', 'Value', 'Remark'],
      rows: L.map((c) => [c.challanNo, fd(c.challanDate), c.customerName, c.mobile, c.model, c.exOldModel, c.exRegNo, c.exYear, c.exOwner, n(c.exValue), c.exRemark || '']), foot: ['', '', 'TOTAL', '', '', '', '', '', '', sum(L, (c) => c.exValue), ''] }; }
    if (type === 'scheme') {
      const rows = []; inR.filter((c) => c.hasScheme).forEach((c) => (c.schemes || []).forEach((s) => rows.push([c.challanNo, fd(c.challanDate), c.customerName, c.model, s.name, n(s.amount), s.toCustomer ? 'Yes' : 'No', s.claim ? 'Yes' : 'No', s.claim ? (s.claimReceived ? 'Received' : 'Pending') : ''])));
      return { title: 'Scheme / Campaign / Claim Register', sub, columns: ['Challan', 'Date', 'Customer', 'Model', 'Scheme', 'Amount', 'To Customer', 'Company Claim', 'Claim Status'], rows, foot: ['', '', 'TOTAL', '', '', sum(rows, (r) => r[5]), '', '', ''] };
    }
    if (type === 'model') {
      const g = {}; inR.forEach((c) => { const k = (c.model || '—') + '|' + (c.colour || '—'); const x = g[k] = g[k] || [0, 0, 0]; x[0]++; if (c.saleType === 'Finance') x[1]++; x[2] += n(c.payable); });
      const rows = Object.keys(g).sort().map((k) => k.split('|').concat([g[k][0], g[k][0] - g[k][1], g[k][1], U.round2(g[k][2])]));
      return { title: 'Model & Colour-wise Sale', sub, columns: ['Model', 'Colour', 'Qty', 'Cash', 'Finance', 'Value'], rows, foot: ['TOTAL', '', sum(rows, (r) => r[2]), sum(rows, (r) => r[3]), sum(rows, (r) => r[4]), sum(rows, (r) => r[5])] };
    }
    if (type === 'exec') {
      const g = {}; inR.forEach((c) => { const k = c.executive || c.createdByName || '—'; (g[k] = g[k] || []).push(c); });
      const rows = Object.keys(g).map((k) => [k, g[k].length, g[k].filter((c) => c.saleType === 'Finance').length, sum(g[k], (c) => c.payable), sum(g[k], (c) => c.received), sum(g[k], (c) => Math.max(0, n(c.due)))].concat(inc ? [sum(g[k], (c) => c.income)] : []));
      return { title: 'Executive-wise Sale', sub, columns: ['Executive', 'Sale', 'Finance', 'Payable', 'Received', 'Due'].concat(inc ? ['Income'] : []), rows };
    }
    if (type === 'tat') return { title: 'Tracking Report (days)', sub, columns: ['Challan', 'Sale Date', 'Customer', 'Type', 'Billing Date', 'Sale→Bill', 'Disb. Date', 'Sale→Finance', 'Last Payment', 'Sale→Last Pay', 'Due', 'Due Days'],
      rows: inR.map((c) => [c.challanNo, fd(c.challanDate), c.customerName, c.saleType, fd(c.invoiceDate), c.invoiceDate ? Ch.daysBetween(c.challanDate, c.invoiceDate) : '', fd(c.disbDate), c.disbDate ? Ch.daysBetween(c.challanDate, c.disbDate) : '',
        fd(c.lastPayDate), c.lastPayDate ? Ch.daysBetween(c.challanDate, c.lastPayDate) : '', n(c.due), n(c.due) > 0.5 ? Ch.daysBetween(c.challanDate) : '']) };
    if (type === 'pendency') {
      const metas = await Ch.allFileMeta().catch(() => []); const fk = {}; metas.forEach((m) => { (fk[m.challanId] = fk[m.challanId] || {})[m.kind] = true; });
      return { title: 'Pendency Report', sub, columns: ['Challan', 'Date', 'Customer', 'Mobile', 'Model', 'Pending Items', 'Count'],
        rows: inR.map((c) => [c, Lists.pendencies(c, fk)]).filter((x) => x[1].length).map(([c, p]) => [c.challanNo, fd(c.challanDate), c.customerName, c.mobile, c.model, p.join(', '), p.length]) };
    }
    if (type === 'calls') {
      const calls = (await Ch.allCalls()).filter((x) => Ch.inRange(x.date, from, to)).sort((a, b) => String(b.date).localeCompare(String(a.date)));
      return { title: 'Call Log', sub, columns: ['Date', 'Challan', 'Customer', 'Mobile', 'Result', 'Remark', 'Promise Date', 'Promise Amt', 'Next Follow-up', 'Due at Call', 'By'],
        rows: calls.map((x) => [fd(x.date), x.challanNo, x.customerName, x.mobile, x.outcome, x.remark, fd(x.promiseDate), n(x.promiseAmount) || '', fd(x.nextDate), n(x.dueAtCall), x.byName]) };
    }
    return { title: 'Customer Master', sub, columns: ['Customer', 'Father', 'Mobile', 'Alt Mobile', 'Address', 'City', 'Aadhaar', 'PAN', 'DOB', 'Challan', 'Model', 'Chassis', 'Reg No', 'App Login'],
      rows: inR.map((c) => [c.customerName, c.fatherName, c.mobile, c.altMobile, c.address, c.city, c.aadhaar, c.pan, fd(c.dob), c.challanNo, c.model, c.chassisNo, c.regNo, c.custUid ? 'C' + c.mobile : '']) };
  };

  // ===== Excel =====
  R.excel = async function (rep) {
    const aoa = [[rep.title + ' (' + (rep.sub || '') + ')'], rep.columns].concat(rep.rows);
    if (rep.foot) aoa.push(rep.foot);
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = rep.columns.map((c) => ({ wch: Math.max(10, String(c).length + 2) }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, String(rep.title).slice(0, 30).replace(/[\\/?*\[\]:]/g, ''));
    await U.saveFile(rep.title.replace(/\W+/g, '_') + '_' + U.dateKey() + '.xlsx', XLSX.write(wb, { bookType: 'xlsx', type: 'base64' }), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  };

  // ===== Tally XML (Masters + Sales + Receipt vouchers) =====
  const x = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const td = (d) => String(d || U.dateKey()).replace(/-/g, '');
  const party = (c) => (c.customerName || 'Customer') + ' (' + (c.mobile || c.challanNo) + ')';
  R.tally = async function (from, to) {
    const all = (await Ch.challans()).filter((c) => !c.cancelled);
    const cs = all.filter((c) => Ch.inRange(c.challanDate, from, to));
    const byId = {}; all.forEach((c) => byId[c.id] = c);
    const pays = (await Ch.allPayments()).filter((p) => Ch.inRange(p.date, from, to) && byId[p.challanId]);
    const led = S.cs.tallyLedgers || {};
    const ledgerOf = (it) => led[it.k] || it.l;
    const masters = new Set(); const groups = {};
    cs.concat(pays.map((p) => byId[p.challanId])).forEach((c) => { masters.add(party(c)); groups[party(c)] = 'Sundry Debtors'; });
    Ch.priceItems().forEach((it) => { masters.add(ledgerOf(it)); groups[ledgerOf(it)] = it.k === 'exShowroom' ? 'Sales Accounts' : 'Indirect Incomes'; });
    [[S.cs.tallyCashLedger || 'Cash', 'Cash-in-Hand'], [S.cs.tallyBankLedger || 'Bank Account', 'Bank Accounts'], ['Discount Allowed', 'Indirect Expenses'], ['Exchange Vehicle Purchase', 'Purchase Accounts']]
      .forEach(([l, g]) => { masters.add(l); groups[l] = g; });
    const entry = (ledger, amt, dr) => '<ALLLEDGERENTRIES.LIST><LEDGERNAME>' + x(ledger) + '</LEDGERNAME><ISDEEMEDPOSITIVE>' + (dr ? 'Yes' : 'No') + '</ISDEEMEDPOSITIVE><AMOUNT>' + (dr ? -U.round2(amt) : U.round2(amt)) + '</AMOUNT></ALLLEDGERENTRIES.LIST>';
    let v = '';
    cs.forEach((c) => {
      const k = Ch.calc(c); const pr = c.price || {};
      let body = entry(party(c), k.payable, true);
      if (k.discount + k.custScheme) body += entry('Discount Allowed', k.discount + k.custScheme, true);
      Ch.priceItems().forEach((it) => { if (n(pr[it.k])) body += entry(ledgerOf(it), n(pr[it.k]), false); });
      v += '<TALLYMESSAGE xmlns:UDF="TallyUDF"><VOUCHER VCHTYPE="Sales" ACTION="Create"><DATE>' + td(c.invoiceDate || c.challanDate) + '</DATE><VOUCHERTYPENAME>Sales</VOUCHERTYPENAME><VOUCHERNUMBER>' + x(c.invoiceNo || c.challanNo) +
        '</VOUCHERNUMBER><REFERENCE>' + x(c.challanNo) + '</REFERENCE><PARTYLEDGERNAME>' + x(party(c)) + '</PARTYLEDGERNAME><NARRATION>' + x('Challan ' + c.challanNo + ' ' + (c.model || '') + ' Chassis ' + (c.chassisNo || '') + ' Engine ' + (c.engineNo || '')) +
        '</NARRATION>' + body + '</VOUCHER></TALLYMESSAGE>';
      if (c.isExchange && n(c.exValue)) v += '<TALLYMESSAGE xmlns:UDF="TallyUDF"><VOUCHER VCHTYPE="Journal" ACTION="Create"><DATE>' + td(c.challanDate) + '</DATE><VOUCHERTYPENAME>Journal</VOUCHERTYPENAME><NARRATION>' +
        x('Exchange ' + (c.exOldModel || '') + ' ' + (c.exRegNo || '') + ' against ' + c.challanNo) + '</NARRATION>' + entry('Exchange Vehicle Purchase', n(c.exValue), true) + entry(party(c), n(c.exValue), false) + '</VOUCHER></TALLYMESSAGE>';
    });
    pays.forEach((p) => {
      const c = byId[p.challanId]; const cash = p.mode === 'Cash';
      const acc = cash ? (S.cs.tallyCashLedger || 'Cash') : (S.cs.tallyBankLedger || 'Bank Account');
      const refund = p.kind === 'Refund';
      v += '<TALLYMESSAGE xmlns:UDF="TallyUDF"><VOUCHER VCHTYPE="' + (refund ? 'Payment' : 'Receipt') + '" ACTION="Create"><DATE>' + td(p.date) + '</DATE><VOUCHERTYPENAME>' + (refund ? 'Payment' : 'Receipt') + '</VOUCHERTYPENAME><NARRATION>' +
        x(p.kind + ' ' + c.challanNo + ' ' + (p.mode || '') + ' ' + (p.ref || '') + (p.kind === 'Disbursement' ? ' ' + (c.financer || '') : '')) + '</NARRATION>' +
        (refund ? entry(party(c), n(p.amount), true) + entry(acc, n(p.amount), false) : entry(acc, n(p.amount), true) + entry(party(c), n(p.amount), false)) + '</VOUCHER></TALLYMESSAGE>';
    });
    const env = (rep, data) => '<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>' + rep + '</REPORTNAME></REQUESTDESC><REQUESTDATA>' + data + '</REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';
    const mx = Array.from(masters).map((m) => '<TALLYMESSAGE xmlns:UDF="TallyUDF"><LEDGER NAME="' + x(m) + '" ACTION="Create"><NAME.LIST><NAME>' + x(m) + '</NAME></NAME.LIST><PARENT>' + x(groups[m]) + '</PARENT></LEDGER></TALLYMESSAGE>').join('');
    const b64 = (s) => btoa(unescape(encodeURIComponent(s)));
    await U.saveFile('Tally_Masters_' + U.dateKey() + '.xml', b64('<?xml version="1.0" encoding="UTF-8"?>' + env('All Masters', mx)), 'application/xml');
    await U.saveFile('Tally_Vouchers_' + U.dateKey() + '.xml', b64('<?xml version="1.0" encoding="UTF-8"?>' + env('Vouchers', v)), 'application/xml');
    return { sales: cs.length, receipts: pays.length };
  };

  V.reports = async function (el, p) {
    if (!Ch.can('reports')) { el.innerHTML = U.empty('Reports ka right nahi hai'); return; }
    const d = new Date();
    const type = p.type || 'sales', from = p.from !== undefined ? p.from : U.dateKey(new Date(d.getFullYear(), d.getMonth(), 1)), to = p.to !== undefined ? p.to : U.dateKey();
    el.innerHTML = '<h2 class="page-title">📑 Reports</h2><div class="card form"><div class="grid2">' +
      U.field('rt', 'Report', type, { type: 'select', options: R.TYPES.filter((r) => r[0] !== 'income' || Ch.can('viewIncome')).map((r) => ({ v: r[0], l: r[1] })) }) +
      '<div class="grid2">' + U.field('rf', 'From', from, { type: 'date' }) + U.field('rto', 'To', to, { type: 'date' }) + '</div></div>' +
      '<div class="row-btns left"><button class="btn" id="rShow">Show</button>' + (Ch.can('export') ? '<button class="btn ghost" id="rX">⬇ Excel</button><button class="btn ghost" id="rP">⬇ PDF</button><button class="btn ghost" id="rT">⬇ Tally XML</button>' : '') +
      '</div><p class="muted small">Date khali chhodne par sab data aayega. Due reports aaj tak ka outstanding dikhate hain.</p></div><div id="rOut"></div>';
    const get = () => ({ type: U.$('[name=rt]').value, from: U.$('[name=rf]').value, to: U.$('[name=rto]').value });
    let rep = null;
    const show = async () => {
      const g = get(); S.params = g; U.loading(true);
      try {
        rep = await R.build(g.type, g.from, g.to);
        U.$('#rOut').innerHTML = '<div class="card"><div class="row-between"><h3>' + esc(rep.title) + '</h3><small class="muted">' + esc(rep.sub) + ' · ' + rep.rows.length + ' rows</small></div><div class="table-wrap"><table class="tbl"><thead><tr>' +
          rep.columns.map((c) => '<th>' + esc(c) + '</th>').join('') + '</tr></thead><tbody>' + rep.rows.slice(0, 300).map((r) => '<tr>' + r.map((v) => '<td>' + esc(typeof v === 'number' ? U.round2(v).toLocaleString('en-IN') : v) + '</td>').join('') + '</tr>').join('') +
          '</tbody>' + (rep.foot ? '<tfoot><tr>' + rep.foot.map((v) => '<td>' + esc(typeof v === 'number' ? U.round2(v).toLocaleString('en-IN') : v) + '</td>').join('') + '</tr></tfoot>' : '') + '</table></div>' +
          (rep.rows.length > 300 ? '<p class="muted small">Screen par 300 rows; Excel/PDF me sab aayenge.</p>' : '') + '</div>';
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
    U.$('#rShow').onclick = show;
    const ensure = async () => { const g = get(); if (!rep || S.params.type !== g.type || S.params.from !== g.from || S.params.to !== g.to) await show(); return rep; };
    const on = (id, fn) => { const b = U.$('#' + id); if (b) b.onclick = async () => { try { U.loading(true); await fn(); } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); } }; };
    on('rX', async () => R.excel(await ensure()));
    on('rP', async () => Print.table(await ensure()));
    on('rT', async () => { const g = get(); const r = await R.tally(g.from, g.to); U.toast('Tally: ' + r.sales + ' sales + ' + r.receipts + ' receipts. Pehle Masters file, fir Vouchers file import karein.', 'ok'); });
    show();
  };
})();
