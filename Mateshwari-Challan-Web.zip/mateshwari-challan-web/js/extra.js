// ---------- Customer search (due warning), handover, renewal, DPD, flags, stock, masters ----------
(function () {
  const V = window.Views, esc = U.esc, n = U.num;
  const t = (v) => esc(v == null ? '' : v);
  const fd = (v) => (v ? U.fmtDate(v) : '-');
  const chip = (ok, txt) => '<span class="pill ' + (ok ? 'p-ok' : 'p-bad') + '">' + (ok ? '✓ ' : '✗ ') + esc(txt) + '</span>';
  const statusChips = (c) => { const f = Ch.flags(c); return Object.keys(f).filter((k) => k !== 'Payment').map((k) => chip(Ch.flagOk(f[k]), k)).join(' '); };

  // ===== Due warning popup (before opening a customer with dues) =====
  const Due = window.DueWarn = {};
  Due.open = function (c) {
    const k = Ch.calc(c);
    if (k.due <= 0.5 || c.cancelled) return Lists.open(c.id);
    const dpd = Ch.dpd(c);
    const m = U.modal('⚠️ Payment Due', '<div class="warn-banner big">⚠️ ' + t(c.customerName) + ' ka <b>' + U.money(k.due) + '</b> PAYMENT DUE hai<br><small>' + (k.dueDays || 0) + ' din se · DPD ' + dpd + ' · ' + t(c.challanNo) + '</small></div>' +
      '<p><b>Payment clear hone par hi Insurance, RC aur Number Plate dena hai.</b></p>' +
      '<div class="kv"><div><span>Payable</span><b>' + U.money(k.payable) + '</b></div><div><span>Received</span><b>' + U.money(k.received) + '</b></div>' +
      (c.saleType === 'Finance' ? '<div><span>Finance pending</span><b>' + U.money(k.finDue) + '</b></div>' : '') + '<div><span>DP due</span><b>' + U.money(k.dpDue) + '</b></div></div>' +
      '<div>' + statusChips(c) + '</div>' +
      '<div class="row-btns left mt"><button class="btn" data-x="open">📒 Ledger kholein</button>' + (Ch.can('payment') ? '<button class="btn ghost" data-x="pay">+ Payment</button>' : '') +
      (Ch.can('calling') ? '<button class="btn ghost" data-x="call">📞 Call</button>' : '') + '</div>', {
      onOpen: (w) => U.$$('[data-x]', w).forEach((b) => b.onclick = () => {
        m.close();
        if (b.dataset.x === 'open') Lists.open(c.id);
        else if (b.dataset.x === 'pay') Pay.dialog(c, 'Payment', null, () => Lists.open(c.id));
        else Calls.dialog(c, () => App.refresh());
      })
    });
  };

  V.search = async function (el) {
    const all = await Ch.challans();
    el.innerHTML = '<h2 class="page-title">🔎 Customer Search</h2><input class="search" id="sq" placeholder="🔍 Naam / mobile / chassis / engine / reg no / challan" autofocus>' +
      '<p class="muted small">Jis customer ka payment due hai, kholne se pehle warning aayegi.</p><div id="sres"></div>';
    const draw = () => {
      const q = U.$('#sq').value.trim();
      const rows = (q ? all.filter((c) => Lists.match(c, { q })) : all.filter((c) => n(c.due) > 0.5).slice(0, 25)).slice(0, 100);
      U.$('#sres').innerHTML = (q ? '' : '<h4>Due wale customers</h4>') + (rows.length ? rows.map((c) => {
        const due = n(c.due) > 0.5 && !c.cancelled;
        return '<div class="card ch-row' + (due ? ' due-row' : '') + '" data-s="' + c.id + '"><div class="grow"><b>' + t(c.customerName) + '</b> <small class="muted">' + t(c.mobile) + '</small><small class="d">' + t(c.challanNo) + ' · ' + t(c.model) + ' · ' + t(c.chassisNo) + (c.regNo ? ' · ' + t(c.regNo) : '') +
          '</small><small class="d">' + statusChips(c) + '</small></div><div class="right">' + (due ? '<b class="low">⚠️ ' + U.money(c.due) + '</b><small class="d">DPD ' + Ch.dpd(c) + '</small>' : '<span class="badge ok">Clear</span>') + '</div></div>';
      }).join('') : U.empty());
      U.$$('[data-s]').forEach((r) => r.onclick = () => Due.open(all.find((c) => c.id === r.dataset.s)));
    };
    U.$('#sq').oninput = draw; draw();
  };

  // ===== Number plate / RC / insurance handover =====
  V.handover = async function (el, p) {
    const all = (await Ch.challans()).filter((c) => !c.cancelled);
    const tab = p.ht || 'plateShow';
    const sets = {
      plateShow: ['Plate showroom par aana baaki', (c) => c.plateShowroom !== 'Received'],
      plateGive: ['Plate aayi — customer ko dena baaki', (c) => c.plateShowroom === 'Received' && c.plateGiven !== 'Given'],
      rcGive: ['RC dena baaki', (c) => c.rcGiven !== 'Given' && (c.regNo || c.rtoStatus === 'Done')],
      insGive: ['Insurance dena baaki', (c) => c.insGiven !== 'Given' && c.policyNo],
      given: ['Sab de diya', (c) => c.plateGiven === 'Given' && c.rcGiven === 'Given']
    };
    const rows = all.filter(sets[tab][1]).sort((a, b) => String(a.challanDate).localeCompare(String(b.challanDate)));
    el.innerHTML = '<h2 class="page-title">🔑 Number Plate / RC / Insurance</h2><div class="tabs">' + Object.keys(sets).map((k) => '<button class="' + (k === tab ? 'on' : '') + '" onclick="App.go(\'handover\',{ht:\'' + k + '\'})">' +
      sets[k][0] + ' (' + all.filter(sets[k][1]).length + ')</button>').join('') + '</div>' +
      (rows.length ? rows.map((c) => '<div class="card ch-row' + (n(c.due) > 0.5 ? ' due-row' : '') + '"><div class="grow" data-cid="' + c.id + '"><b>' + t(c.customerName) + '</b> <small class="muted">' + t(c.challanNo) + ' · ' + t(c.model) + ' · ' + t(c.regNo || 'Reg pending') + '</small>' +
        '<small class="d">Plate: ' + t(c.plateShowroom || 'Not Received') + (c.plateRecvDate ? ' (' + fd(c.plateRecvDate) + ')' : '') + ' → ' + t(c.plateGiven || 'Not Given') + (c.plateGivenDate ? ' (' + fd(c.plateGivenDate) + ')' : '') +
        ' · RC: ' + t(c.rcGiven || 'Not Given') + ' · Ins: ' + t(c.insGiven || 'Not Given') + '</small>' + (n(c.due) > 0.5 ? '<small class="d low">⚠️ Due ' + U.money(c.due) + ' — pehle payment lein</small>' : '') + '</div>' +
        (Ch.can('handover') ? '<button class="btn sm" data-ho="' + c.id + '">Update</button>' : '') + '</div>').join('') : U.empty('Is list me koi nahi'));
    Lists.bind(el);
    U.$$('[data-ho]').forEach((b) => b.onclick = () => ChForm.handoverDialog(rows.find((c) => c.id === b.dataset.ho), () => App.refresh()));
  };

  // ===== Insurance renewal (OD + TP) =====
  const RENEW_ST = ['Pending', 'Interested', 'Call Back', 'Renewed (Showroom)', 'Renewed (Outside)', 'Not Interested'];
  V.renewal = async function (el, p) {
    const all = (await Ch.challans()).filter((c) => !c.cancelled && (c.odTo || c.insTo || c.tpTo));
    const days = Number(S.cs.renewalDays) || 30, today = U.dateKey();
    const tab = p.rt || 'od';
    const exp = (c) => (tab === 'tp' ? c.tpTo : (c.odTo || c.insTo));
    const rows = all.map((c) => Object.assign(c, { _e: exp(c), _l: exp(c) ? Ch.daysBetween(today, exp(c)) : null }))
      .filter((c) => c._e && (tab === 'all' || (c._l <= days && c._l >= -90)) && !/^Renewed/.test(tab === 'tp' ? (c.tpRenewal || '') : (c.renewalStatus || '')))
      .sort((a, b) => a._l - b._l);
    el.innerHTML = '<h2 class="page-title">🛡️ Insurance Renewal Follow-up</h2><div class="tabs">' +
      [['od', 'OD cover (' + days + ' din me / expired)'], ['tp', 'Third Party'], ['all', 'Sab policies']].map((x) => '<button class="' + (x[0] === tab ? 'on' : '') + '" onclick="App.go(\'renewal\',{rt:\'' + x[0] + '\'})">' + x[1] + '</button>').join('') + '</div>' +
      '<div class="sum-bar"><b>' + rows.length + '</b> customers · ' + rows.filter((c) => c._l < 0).length + ' expire ho chuke</div>' +
      (rows.length ? rows.map((c) => '<div class="card call-card"><div class="row-between"><div class="grow" data-cid="' + c.id + '"><b>' + t(c.customerName) + '</b> <small class="muted">' + t(c.mobile) + ' · ' + t(c.model) + ' · ' + t(c.regNo) + '</small><br><small>' +
        t(c.insCompany) + ' · ' + t(c.policyNo) + ' · OD: ' + fd(c.odTo || c.insTo) + ' · TP: ' + fd(c.tpTo) + '</small><br><small>' + (c.renewalRemark ? '📝 ' + t(c.renewalRemark) : 'Abhi follow-up nahi') +
        (c.renewalNext ? ' · Next: ' + fd(c.renewalNext) : '') + '</small></div><div class="right"><b class="' + (c._l < 0 ? 'low' : c._l <= 7 ? 'warn-t' : '') + '">' + (c._l < 0 ? (-c._l) + ' din pehle expire' : c._l + ' din baaki') + '</b><small class="d">' + t(c.renewalStatus || 'Pending') + '</small></div></div>' +
        '<div class="act-row"><a class="btn sm" href="tel:' + t(c.mobile) + '">📞 Call</a><button class="btn ghost sm" data-rwa="' + c.id + '">💬 WhatsApp</button><button class="btn ghost sm" data-rf="' + c.id + '">📝 Follow-up</button></div></div>').join('') : U.empty('Abhi koi renewal nahi'));
    Lists.bind(el);
    const find = (id) => rows.find((c) => c.id === id);
    U.$$('[data-rwa]').forEach((b) => b.onclick = () => {
      const c = find(b.dataset.rwa);
      const msg = 'Namaste ' + c.customerName + ' ji,\n' + Print.co().name + ' se. Aapki gaadi ' + (c.regNo || c.model || '') + ' ka insurance (' + (c.insCompany || '') + ') ' + U.fmtDate(c._e) + ' ko ' +
        (c._l < 0 ? 'expire ho chuka hai' : 'expire ho raha hai') + '. Renewal ke liye showroom aayein ya call karein: ' + Print.co().phone;
      window.open('https://wa.me/91' + String(c.mobile || '').replace(/\D/g, '').slice(-10) + '?text=' + encodeURIComponent(msg), '_system');
    });
    U.$$('[data-rf]').forEach((b) => b.onclick = () => {
      const c = find(b.dataset.rf);
      const m = U.modal('Renewal Follow-up · ' + c.customerName, '<form class="form" id="rff"><div class="grid2">' +
        U.field('st', 'Status', (tab === 'tp' ? c.tpRenewal : c.renewalStatus) || 'Pending', { type: 'select', options: RENEW_ST }) + U.field('next', 'Next follow-up', c.renewalNext || '', { type: 'date' }) +
        U.field('newPolicy', 'Naya Policy No (renew hua to)', '') + U.field('newTo', 'Nayi expiry date', '', { type: 'date' }) + '</div>' +
        U.field('remark', 'Remark', '', { type: 'textarea', rows: 2, required: true }) + '<button class="btn block">Save</button></form>', {
        onOpen: (w) => U.$('#rff', w).onsubmit = async (ev) => {
          ev.preventDefault(); const d = U.formData(ev.target); if (!d.remark) return U.toast('Remark likhein', 'err');
          const me = Ch.me(); U.loading(true);
          try {
            await DB.add('ccalls', { challanId: c.id, challanNo: c.challanNo, customerName: c.customerName, mobile: c.mobile, ownerId: c.ownerId, purpose: 'Insurance Renewal (' + (tab === 'tp' ? 'TP' : 'OD') + ')',
              outcome: d.st, remark: d.remark, nextDate: d.next, date: U.dateKey(), byId: me.id, byName: me.name, at: DB.now(), dueAtCall: n(c.due) });
            const upd = { renewalRemark: d.st + ': ' + d.remark, renewalNext: d.next || '' };
            if (tab === 'tp') upd.tpRenewal = d.st; else upd.renewalStatus = d.st;
            if (d.newPolicy) upd.renewedPolicyNo = d.newPolicy;
            if (d.newTo) { if (tab === 'tp') upd.tpTo = d.newTo; else { upd.odTo = d.newTo; } upd.renewalStatus = /^Renewed/.test(d.st) ? 'Pending' : d.st; }
            await DB.update('challans', c.id, upd); Ch.dirty(); m.close(); U.toast(T('saved'), 'ok'); App.refresh();
          } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
        }
      });
    });
  };

  // ===== DPD =====
  V.dpd = async function (el, p) {
    const all = (await Ch.challans()).filter((c) => !c.cancelled && n(c.due) > 0.5).map((c) => Object.assign(c, { _dpd: Ch.dpd(c) }));
    const b = p.b || '';
    const agg = {}; Ch.DPD_BUCKETS.forEach((x) => agg[x] = { c: 0, a: 0 }); all.forEach((c) => { const k = Ch.dpdBucket(c._dpd); agg[k].c++; agg[k].a += n(c.due); });
    const rows = all.filter((c) => !b || Ch.dpdBucket(c._dpd) === b).sort((x, y) => y._dpd - x._dpd);
    el.innerHTML = '<h2 class="page-title">📉 DPD — Days Past Due</h2><p class="muted small">Due date = challan date + ' + (Number(S.cs.creditDays) || 0) + ' din (Settings me badlein) ya challan me "Payment Due Date".</p>' +
      '<div class="dash-grid">' + Ch.DPD_BUCKETS.map((x) => '<div class="dtile' + (x === b ? ' sel' : '') + (x !== Ch.DPD_BUCKETS[0] ? ' alert' : '') + '" onclick="App.go(\'dpd\',{b:' + (x === b ? '\'\'' : '\'' + x + '\'') + '})"><b>' + U.money(agg[x].a) + '</b><span>' + x + ' (' + agg[x].c + ')</span></div>').join('') + '</div>' +
      (rows.length ? rows.map((c) => Lists.row(c, '<b class="low">' + U.money(c.due) + '</b><small class="d">DPD ' + c._dpd + '</small>', 'Due date ' + fd(Ch.dueDate(c)) + ' · ' + Ch.dpdBucket(c._dpd) + (c.lastCallRemark ? ' · 📞 ' + t(c.lastCallRemark) : ''))).join('') : U.empty());
    Lists.bind(el);
  };

  // ===== Delivered vehicle flag report =====
  V.flags = async function (el, p) {
    const all = (await Ch.challans()).filter((c) => !c.cancelled);
    const only = p.only !== false;
    const keys = Object.keys(Ch.flags({}));
    const rows = all.filter((c) => !only || keys.some((k) => !Ch.flagOk(Ch.flags(c)[k])));
    const cnt = {}; keys.forEach((k) => cnt[k] = all.filter((c) => !Ch.flagOk(Ch.flags(c)[k])).length);
    el.innerHTML = '<h2 class="page-title">🚩 Delivery Flag Report</h2><div class="chips">' + keys.map((k) => '<span class="chip">' + esc(k) + ' pending: <b>' + cnt[k] + '</b></span>').join('') + '</div>' +
      '<label class="chk"><input type="checkbox" id="onlyP"' + (only ? ' checked' : '') + '> Sirf pending wale dikhayein</label>' + (Ch.can('reports') ? ' <button class="btn ghost sm" onclick="App.go(\'reports\',{type:\'flags\',from:\'\',to:\'\'})">⬇ Excel / PDF</button>' : '') +
      '<div class="card"><div class="table-wrap"><table class="tbl flags"><thead><tr><th>Challan</th><th>Customer</th><th>Delivery</th>' + keys.map((k) => '<th>' + esc(k) + '</th>').join('') + '</tr></thead><tbody>' +
      rows.map((c) => { const f = Ch.flags(c); return '<tr data-cid="' + c.id + '"><td>' + t(c.challanNo) + '</td><td>' + t(c.customerName) + '<br><small>' + t(c.model) + '</small></td><td>' + fd(Ch.baseDate(c)) + '</td>' +
        keys.map((k) => '<td class="' + (Ch.flagOk(f[k]) ? 'f-ok' : 'f-bad') + '">' + esc(f[k]) + '</td>').join('') + '</tr>'; }).join('') + '</tbody></table></div></div>';
    U.$('#onlyP').onchange = (e) => App.go('flags', { only: e.target.checked });
    U.$$('tr[data-cid]').forEach((r) => r.onclick = () => Lists.open(r.dataset.cid));
  };

  // ===== Stock =====
  const SCOLS = [['Chassis No', 'chassisNo'], ['Engine No', 'engineNo'], ['Model', 'model'], ['Variant', 'variant'], ['Colour', 'colour'], ['Key No', 'keyNo'], ['Battery No', 'batteryNo'],
    ['Purchase Invoice No', 'mfgInvoiceNo'], ['Purchase Invoice Date', 'mfgInvoiceDate', 'date'], ['Received Date', 'receivedDate', 'date'], ['Purchase Price', 'purchasePrice', 'num'], ['Location', 'location']];
  const Stock = window.Stock = {};
  Stock.save = async function (rows, source) {
    const me = Ch.me(); const ops = []; let added = 0, skipped = 0;
    const existing = {}; (await DB.all('cstock')).forEach((s) => existing[s.id] = s);
    rows.forEach((r) => {
      const id = Ch.stockId(r.chassisNo); if (!id) { skipped++; return; }
      if (existing[id]) { skipped++; return; }
      const o = {}; SCOLS.forEach(([, k]) => { if (r[k] !== undefined && r[k] !== '') o[k] = typeof r[k] === 'string' ? r[k].trim().toUpperCase() : r[k]; });
      o.chassisNo = id; if (o.engineNo) o.engineNo = String(o.engineNo).replace(/\s+/g, '');
      ['mfgInvoiceDate', 'receivedDate'].forEach((k) => { if (o[k]) o[k] = Importx.date(o[k]); });
      ops.push(['set', 'cstock', id, Object.assign(o, { status: 'In Stock', source, receivedDate: o.receivedDate || U.dateKey(), addedBy: me.name, at: DB.now() })]);
      existing[id] = o; added++;
    });
    await DB.batch(ops); Ch.dirty('stock');
    return { added, skipped };
  };
  // purchase invoice (PDF / photo): one or many vehicles
  Stock.parseInvoice = function (text) {
    const T2 = text.toUpperCase();
    const inv = OCR.parseInvoice(text);
    const L = T2.split('\n');
    const out = []; const seen = {};
    L.forEach((line, i) => {
      const re = /\b(M[A-Z0-9]{16})\b/g; let m;
      while ((m = re.exec(line.replace(/O(?=[0-9]{3})/g, '0')))) {
        const ch = m[1]; if (seen[ch]) continue; seen[ch] = 1;
        const ctx = line + ' ' + (L[i + 1] || '') + ' ' + (L[i - 1] || '');
        const eng = (/(?:ENGINE|ENG\.?|MOTOR)\s*(?:NO|NUMBER)?\.?\s*[:\-]?\s*([A-Z0-9]{8,16})/.exec(ctx) || [])[1] ||
          (ctx.replace(ch, '').match(/\b([A-Z]{2}[A-Z0-9]{6,14})\b/g) || []).filter((x) => /\d/.test(x) && !/^(MODEL|COLOU?R|CHASSIS|ENGINE|INVOICE|TOTAL)/.test(x))[0] || '';
        // prefer the vehicle's own line; neighbours only as fallback
        const pick = (list) => { for (const seg of [line, L[i + 1] || '', L[i - 1] || '']) { const v = list.find((x) => seg.includes(String(x).toUpperCase())); if (v) return v; } return ''; };
        const colour = pick(Ch.list('colours'));
        let model = pick(Ch.list('models'));
        if (!model || !line.includes(String(model).toUpperCase())) {
          const before = line.slice(0, line.indexOf(ch)).replace(/CHASSIS\s*(NO|NUMBER)?\.?\s*:?/g, '').replace(/^\s*\d+[\s\.\)]+/, '');
          const guess = before.replace(colour ? new RegExp('\\b' + String(colour).toUpperCase() + '\\b') : /$^/, '').replace(/\s+/g, ' ').trim();
          if (/[A-Z]{2,}/.test(guess) && guess.length <= 40) model = guess;
        }
        out.push({ chassisNo: ch, engineNo: eng, model, colour, mfgInvoiceNo: inv.invoiceNo || '', mfgInvoiceDate: inv.invoiceDate || '', receivedDate: U.dateKey() });
      }
    });
    return out;
  };
  function previewSave(rows, source) {
    if (!rows.length) return U.toast('Koi gaadi nahi mili', 'err');
    const m = U.modal('Stock preview (' + rows.length + ')', '<p class="muted small">Check karke sudhar sakte hain, fir Save.</p><div class="table-wrap"><table class="tbl sp"><thead><tr><th>Chassis</th><th>Engine</th><th>Model</th><th>Colour</th></tr></thead><tbody>' +
      rows.map((r, i) => '<tr>' + ['chassisNo', 'engineNo', 'model', 'colour'].map((k) => '<td><input data-i="' + i + '" data-k="' + k + '" value="' + esc(r[k] || '') + '"></td>').join('') + '</tr>').join('') +
      '</tbody></table></div><button class="btn block" id="spSave">💾 ' + rows.length + ' gaadi stock me jodein</button>', {
      wide: true, onOpen: (w) => U.$('#spSave', w).onclick = async () => {
        U.$$('input[data-i]', w).forEach((inp) => rows[inp.dataset.i][inp.dataset.k] = inp.value.trim());
        U.loading(true);
        try { const r = await Stock.save(rows, source); m.close(); U.toast(r.added + ' gaadi judi' + (r.skipped ? ', ' + r.skipped + ' pehle se thi / chassis nahi' : ''), 'ok'); App.refresh(); }
        catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
      }
    });
  }
  V.stock = async function (el, p) {
    if (!Ch.can('stock') && !Ch.can('stockAdd')) { el.innerHTML = U.empty('Stock ka right nahi hai'); return; }
    const all = await DB.all('cstock');
    const st = p.st || 'In Stock';
    const add = Ch.can('stockAdd');
    el.innerHTML = '<h2 class="page-title">📦 Stock</h2>' + (add ? '<div class="row-btns left"><button class="btn sm" id="sAdd">➕ Gaadi jodein</button><button class="btn ghost sm" id="sPdf">📤 Purchase Invoice PDF/Photo</button>' +
      '<button class="btn ghost sm" id="sXl">⬆ Excel import</button><button class="btn ghost sm" id="sOpen">⬆ Opening Stock</button><button class="btn ghost sm" id="sTpl">⬇ Template</button></div>' : '') +
      '<div class="tabs">' + ['In Stock', 'Delivered', 'All'].map((x) => '<button class="' + (x === st ? 'on' : '') + '" onclick="App.go(\'stock\',{st:\'' + x + '\'})">' + x + ' (' + (x === 'All' ? all.length : all.filter((s) => s.status === x).length) + ')</button>').join('') + '</div>' +
      '<input class="search" id="stq" placeholder="🔍 Chassis / Engine / Model / Colour"><div id="sSum" class="sum-bar"></div><div id="sList"></div>';
    const draw = () => {
      const q = U.$('#stq').value.trim().toUpperCase();
      const rows = all.filter((s) => (st === 'All' || s.status === st) && (!q || [s.chassisNo, s.engineNo, s.model, s.colour, s.customerName].some((x) => String(x || '').toUpperCase().includes(q))))
        .sort((a, b) => String(a.receivedDate || '').localeCompare(String(b.receivedDate || '')));
      const mg = {}; rows.forEach((s) => mg[s.model || '—'] = (mg[s.model || '—'] || 0) + 1);
      U.$('#sSum').innerHTML = '<b>' + rows.length + '</b> gaadi<div class="chips">' + Object.keys(mg).map((k) => '<span class="chip">' + esc(k) + ': ' + mg[k] + '</span>').join('') + '</div>';
      U.$('#sList').innerHTML = rows.slice(0, 300).map((s) => '<div class="card ch-row"><div class="grow"><b>' + t(s.model) + ' ' + t(s.colour) + '</b> <span class="badge ' + (s.status === 'In Stock' ? 'ok' : 'muted') + '">' + t(s.status) + '</span>' +
        '<small class="d">Chassis ' + t(s.chassisNo) + ' · Engine ' + t(s.engineNo) + '</small><small class="d">Aayi ' + fd(s.receivedDate) + (s.status === 'In Stock' ? ' · ' + (Ch.daysBetween(s.receivedDate) || 0) + ' din se stock me' : ' · ' + t(s.challanNo) + ' · ' + t(s.customerName) + ' · ' + fd(s.deliveredDate)) +
        (s.mfgInvoiceNo ? ' · Inv ' + t(s.mfgInvoiceNo) : '') + ' · ' + t(s.source || '') + '</small></div>' + (S.isAdmin && s.status === 'In Stock' ? '<button class="icon-btn" data-sdel="' + esc(s.id) + '">🗑</button>' : '') + '</div>').join('') || U.empty();
      U.$$('[data-sdel]').forEach((b) => b.onclick = async () => { if (await U.confirm('Ye gaadi stock se hatayein? ' + b.dataset.sdel, 'Delete')) { await DB.del('cstock', b.dataset.sdel); Ch.dirty('stock'); App.refresh(); } });
    };
    U.$('#stq').oninput = draw; draw();
    if (!add) return;
    U.$('#sAdd').onclick = () => {
      const m = U.modal('Gaadi stock me jodein', '<form class="form upper" id="saf"><div class="grid2">' + SCOLS.map(([l, k, typ]) => U.field(k, l, k === 'receivedDate' ? U.dateKey() : '', { type: typ === 'date' ? 'date' : typ === 'num' ? 'number' : 'text', required: k === 'chassisNo' })).join('') +
        '</div><button class="btn block">Save</button></form>', { onOpen: (w) => {
        const mi = U.$('[name=model]', w); mi.setAttribute('list', 'dl-sm'); w.insertAdjacentHTML('beforeend', '<datalist id="dl-sm">' + Ch.list('models').map((x) => '<option value="' + esc(x) + '">').join('') + '</datalist>');
        U.$('#saf', w).onsubmit = async (ev) => { ev.preventDefault(); const d = U.formData(ev.target); if (!d.chassisNo) return U.toast('Chassis No daalein', 'err');
          U.loading(true); try { const r = await Stock.save([d], 'Manual'); m.close(); U.toast(r.added ? 'Stock me jud gayi' : 'Ye chassis pehle se stock me hai', r.added ? 'ok' : 'err'); App.refresh(); } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); } };
      } });
    };
    U.$('#sTpl').onclick = async () => {
      const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([SCOLS.map((x) => x[0]), ['MBLHAW123R9K00001', 'HA11EVR9K00001', Ch.list('models')[0] || 'MODEL', '', 'BLACK', '', '', '', '', U.dateKey(), '', '']]), 'Stock');
      await U.saveFile('Stock_Import_Template.xlsx', XLSX.write(wb, { bookType: 'xlsx', type: 'base64' }), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    };
    const xl = (source) => async () => {
      const file = await U.pickFile('.xlsx,.xls,.csv'); if (!file) return;
      try {
        const wb = XLSX.read(await file.arrayBuffer(), { type: 'array' });
        const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { defval: '' }).map((r) => { const o = {}; SCOLS.forEach(([h, k]) => { const v = r[h] !== undefined ? r[h] : r[h.toUpperCase()]; if (v !== undefined && v !== '') o[k] = typeof v === 'number' && /Date/.test(h) ? Importx.date(v) : String(v); }); return o; }).filter((o) => o.chassisNo);
        previewSave(rows, source);
      } catch (e) { U.toast('Excel nahi padh paaye: ' + e.message, 'err'); }
    };
    U.$('#sXl').onclick = xl('Excel'); U.$('#sOpen').onclick = xl('Opening');
    U.$('#sPdf').onclick = async () => {
      const file = await U.pickFile('application/pdf,image/*'); if (!file) return;
      try {
        const isPdf = /pdf/i.test(file.type) || /\.pdf$/i.test(file.name);
        const data = isPdf ? await U.fileToDataURL(file) : await U.compressImage(file, 2200, 0.85);
        U.loading(true, 'Invoice padh rahe hain...');
        const r = await OCR.extract(data, (pct) => U.loading(true, 'OCR ' + pct + '%'));
        U.loading(false);
        previewSave(Stock.parseInvoice(r.text), 'Invoice PDF');
      } catch (e) { U.loading(false); U.toast('Invoice nahi padh paaye: ' + e.message, 'err'); }
    };
  };

  // ===== Masters: model / village / finance / colour / insurer + model price =====
  V.masters = async function (el) {
    if (!Ch.can('masters')) { el.innerHTML = U.empty('Masters ka right nahi hai'); return; }
    S.cm = (await DB.get('cmasters', 'lists').catch(() => null)) || {}; S.mp = (await DB.get('cmasters', 'prices').catch(() => null)) || {}; delete S.mp.id; delete S.cm.id;
    const kinds = [['models', 'Models'], ['villages', 'Villages / Cities'], ['financers', 'Finance Companies'], ['colours', 'Colours'], ['insurers', 'Insurance Companies']];
    const items = Ch.priceItems();
    el.innerHTML = '<h2 class="page-title">🗂️ Masters</h2>' + kinds.map(([k, l]) => '<details class="card sec"><summary><b>' + l + ' (' + Ch.list(k).length + ')</b></summary><div class="sec-body">' +
      '<div class="row"><input class="grow mi" data-k="' + k + '" placeholder="Naya ' + l + '"><button class="btn sm" data-add="' + k + '">＋ Jodein</button></div><div class="chips">' +
      Ch.list(k).map((v) => '<span class="chip">' + esc(v) + ((S.cm[k] || []).includes(v) && S.isAdmin ? ' <a data-rm="' + k + '" data-v="' + esc(v) + '">✕</a>' : '') + '</span>').join('') + '</div></div></details>').join('') +
      '<details class="card sec" open><summary><b>💰 Model-wise On-Road Price (challan me auto aayega)</b></summary><div class="sec-body"><div class="table-wrap"><table class="tbl price-tbl mp"><thead><tr><th>Model</th>' +
      items.map((it) => '<th>' + esc(it.l) + '</th>').join('') + '</tr></thead><tbody>' + Ch.list('models').map((mo) => '<tr data-m="' + esc(mo) + '"><td>' + esc(mo) + '</td>' +
      items.map((it) => '<td><input type="number" data-pk="' + it.k + '" value="' + esc(((S.mp[mo] || {})[it.k]) == null ? '' : S.mp[mo][it.k]) + '"></td>').join('') + '</tr>').join('') +
      '</tbody></table></div><button class="btn" id="mpSave">💾 Price save</button></div></details>';
    U.$$('[data-add]').forEach((b) => b.onclick = async () => {
      const inp = U.$('.mi[data-k="' + b.dataset.add + '"]'); if (!inp.value.trim()) return;
      try { const ok = await Ch.addMaster(b.dataset.add, inp.value); U.toast(ok ? 'Jud gaya' : 'Pehle se hai', ok ? 'ok' : 'info'); App.refresh(); } catch (e) { U.toast(e.message, 'err'); }
    });
    U.$$('[data-rm]').forEach((a) => a.onclick = async () => { await DB.set('cmasters', 'lists', { [a.dataset.rm]: DB.remove(a.dataset.v) }, true); App.refresh(); });
    U.$('#mpSave').onclick = async () => {
      const o = {}; U.$$('tr[data-m]').forEach((r) => { const pr = {}; U.$$('input', r).forEach((i) => { if (i.value !== '') pr[i.dataset.pk] = n(i.value); }); if (Object.keys(pr).length) o[r.dataset.m] = pr; });
      U.loading(true); try { await DB.set('cmasters', 'prices', o); S.mp = o; U.toast(T('saved'), 'ok'); } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  };
})();
