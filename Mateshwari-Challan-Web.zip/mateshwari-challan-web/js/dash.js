// ---------- Dynamic dashboard ----------
(function () {
  const V = window.Views, esc = U.esc, n = U.num;

  function range(key) {
    const d = new Date(), y = d.getFullYear(), m = d.getMonth();
    const k = (x) => U.dateKey(x);
    if (key === 'today') return [k(d), k(d)];
    if (key === 'month') return [k(new Date(y, m, 1)), k(d)];
    if (key === 'last') return [k(new Date(y, m - 1, 1)), k(new Date(y, m, 0))];
    if (key === 'fy') { const fy = m >= 3 ? y : y - 1; return [fy + '-04-01', k(d)]; }
    return ['', ''];
  }

  V.dash = async function (el, p) {
    if (!Ch.can('dashboard')) return App.go('list');
    const rk = p.r || 'month';
    let [from, to] = p.from !== undefined ? [p.from, p.to] : range(rk);
    const [all, pays, reqs, metas] = await Promise.all([Ch.challans(), Ch.allPayments(), DB.query('ccallreq', [['status', '==', 'open']].concat(Ch.ownWhere())).catch(() => []),
      Ch.allFileMeta().catch(() => [])]);
    const live = all.filter((c) => !c.cancelled);
    const sales = live.filter((c) => Ch.inRange(c.challanDate, from, to));
    const pr = pays.filter((x) => Ch.inRange(x.date, from, to));
    const sum = (a, f) => U.round2(a.reduce((s, x) => s + n(f(x)), 0));
    const fin = sales.filter((c) => c.saleType === 'Finance');
    const inc = Ch.can('viewIncome');
    const today = U.dateKey();
    const kpi = (v, l, cls, go) => '<div class="dtile' + (cls ? ' ' + cls : '') + '"' + (go ? ' onclick="App.go(\'' + go + '\')"' : '') + '><b>' + v + '</b><span>' + l + '</span></div>';

    // outstanding (all time, not range)
    const dueList = live.filter((c) => n(c.due) > 0.5);
    const ageing = {}; Ch.AGE_BUCKETS.forEach((b) => ageing[b] = { c: 0, a: 0 });
    dueList.forEach((c) => { const b = Ch.ageBucket(Ch.daysBetween(c.challanDate)); ageing[b].c++; ageing[b].a += n(c.due); });
    const maxAge = Math.max(1, ...Object.values(ageing).map((x) => x.a));

    // group helpers
    const group = (arr, key) => { const g = {}; arr.forEach((c) => { const k = key(c) || '—'; (g[k] = g[k] || []).push(c); }); return g; };
    const fg = group(fin, (c) => c.financer);
    const mg = group(sales, (c) => c.model);
    const eg = group(sales, (c) => c.executive || c.createdByName);
    const tbl = (head, rows) => '<div class="table-wrap"><table class="tbl"><thead><tr>' + head.map((h) => '<th>' + h + '</th>').join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody></table></div>';

    // daily sales bars
    const days = {}; sales.forEach((c) => days[c.challanDate] = (days[c.challanDate] || 0) + 1);
    const dkeys = Object.keys(days).sort().slice(-31); const dmax = Math.max(1, ...dkeys.map((k) => days[k]));

    const followToday = dueList.filter((c) => c.nextFollow && c.nextFollow <= today).length;
    const custUploads = metas.filter((m) => m.byCustomer && !m.seen).length;

    el.innerHTML = '<div class="row-between"><h2 class="page-title">📊 Dashboard</h2>' + (Ch.can('create') ? '<button class="btn sm" onclick="App.go(\'form\')">➕ New Challan</button>' : '') + '</div>' +
      '<div class="chips">' + [['today', 'Aaj'], ['month', 'Is Mahine'], ['last', 'Pichhle Mahine'], ['fy', 'Is FY'], ['all', 'Sab']].map((x) => '<span class="chip' + (x[0] === rk && p.from === undefined ? ' on' : '') + '" data-r="' + x[0] + '">' + x[1] + '</span>').join('') +
      '<input type="date" id="dFrom" value="' + esc(from) + '"><input type="date" id="dTo" value="' + esc(to) + '"></div>' +
      '<h3 class="sec-title">Sales (' + (from ? U.fmtDate(from) : 'start') + ' → ' + (to ? U.fmtDate(to) : 'aaj') + ')</h3><div class="dash-grid">' +
      kpi(sales.length, 'Total Sale', '', 'list') + kpi(sales.length - fin.length, 'Cash Sale') + kpi(fin.length, 'Finance Sale', '', 'loans') +
      kpi(sales.filter((c) => c.isExchange).length, 'Exchange') + kpi(U.money(sum(sales, (c) => c.gross)), 'On-Road Value') + kpi(U.money(sum(sales, (c) => c.payable)), 'Net Payable') +
      kpi(U.money(sum(pr.filter((x) => x.kind !== 'Disbursement'), (x) => (x.kind === 'Refund' ? -1 : 1) * x.amount)), 'Customer Collection') +
      kpi(U.money(sum(pr.filter((x) => x.kind !== 'Disbursement' && x.mode === 'Cash'), (x) => (x.kind === 'Refund' ? -1 : 1) * x.amount)), 'Cash') +
      kpi(U.money(sum(pr.filter((x) => x.kind !== 'Disbursement' && x.mode !== 'Cash'), (x) => (x.kind === 'Refund' ? -1 : 1) * x.amount)), 'Bank / UPI') +
      kpi(U.money(sum(pr.filter((x) => x.kind === 'Disbursement'), (x) => x.amount)), 'Finance Disbursed') +
      (inc ? kpi(U.money(sum(sales, (c) => c.income)), 'Income', 'good') + kpi(U.money(sum(sales, (c) => (c.price || {}).insurance)), 'Insurance (charged)') : '') + '</div>' +
      '<h3 class="sec-title">Outstanding (aaj tak)</h3><div class="dash-grid">' +
      kpi(U.money(sum(dueList, (c) => c.due)), 'Total Due (' + dueList.length + ')', 'alert', 'due') +
      kpi(U.money(sum(live, (c) => c.dpDue)), 'Down Payment Due', 'alert', 'dpdue') +
      kpi(U.money(sum(live, (c) => c.finDue)), 'Finance Pending (' + live.filter((c) => n(c.finDue) > 0.5).length + ')', 'alert', 'findue') +
      kpi(live.filter((c) => c.saleType === 'Finance' && (c.loanFileStatus || 'Pending') === 'Pending').length + ' / ' + live.filter((c) => c.saleType === 'Finance' && c.loanFileStatus === 'Complete').length,
        'Loan File Pending / Complete', '', 'loans') +
      kpi(followToday, 'Aaj ke Follow-up', followToday ? 'alert' : '', 'calling') + kpi(reqs.length, 'Customer Callback Request', reqs.length ? 'alert' : '', 'calling') +
      kpi(live.filter((c) => (c.rtoStatus || 'Pending') !== 'Done').length, 'RTO Pending', '', 'pendency') + kpi(live.filter((c) => !c.policyNo).length, 'Insurance Pending', '', 'pendency') +
      kpi(U.money(sum(live, (c) => (c.hasScheme ? c.schemes || [] : []).filter((s) => s.claim && !s.claimReceived).reduce((a, s) => a + n(s.amount), 0))), 'Scheme Claim Pending', '', 'claims') +
      (custUploads ? kpi(custUploads, 'Customer ne docs bheje', 'alert') : '') + '</div>' +
      '<div class="card"><h3>Due Ageing (din ke hisaab se)</h3>' + Ch.AGE_BUCKETS.map((b) => '<div class="pct-row"><span>' + b + ' <small class="muted">(' + ageing[b].c + ')</small></span><div class="bar"><i style="width:' +
        Math.round(ageing[b].a / maxAge * 100) + '%"></i></div><b>' + U.money(ageing[b].a) + '</b></div>').join('') + '</div>' +
      '<div class="card"><h3>🏦 Finance Company-wise Business</h3>' + (Object.keys(fg).length ? tbl(['Company', 'Cases', 'Loan Amt', 'Disbursed', 'Pending'], Object.keys(fg).sort((a, b) => fg[b].length - fg[a].length).map((k) =>
        '<tr><td>' + esc(k) + '</td><td>' + fg[k].length + '</td><td>' + U.money(sum(fg[k], (c) => c.loanAmount)) + '</td><td>' + U.money(sum(fg[k], (c) => c.sumDisbursed)) + '</td><td>' + U.money(sum(fg[k], (c) => c.finDue)) + '</td></tr>')) : U.empty()) + '</div>' +
      '<div class="card"><h3>🏍️ Model-wise Sale</h3>' + (Object.keys(mg).length ? tbl(['Model', 'Qty', 'Cash', 'Finance', 'Value'], Object.keys(mg).sort((a, b) => mg[b].length - mg[a].length).map((k) =>
        '<tr><td>' + esc(k) + '</td><td>' + mg[k].length + '</td><td>' + mg[k].filter((c) => c.saleType !== 'Finance').length + '</td><td>' + mg[k].filter((c) => c.saleType === 'Finance').length + '</td><td>' + U.money(sum(mg[k], (c) => c.payable)) + '</td></tr>')) : U.empty()) + '</div>' +
      '<div class="card"><h3>👥 Executive-wise Sale</h3>' + (Object.keys(eg).length ? tbl(['Executive', 'Qty', 'Value', 'Due'], Object.keys(eg).sort((a, b) => eg[b].length - eg[a].length).map((k) =>
        '<tr><td>' + esc(k) + '</td><td>' + eg[k].length + '</td><td>' + U.money(sum(eg[k], (c) => c.payable)) + '</td><td>' + U.money(sum(eg[k], (c) => Math.max(0, n(c.due)))) + '</td></tr>')) : U.empty()) + '</div>' +
      '<div class="card"><h3>📅 Day-wise Sale</h3>' + (dkeys.length ? '<div class="daybars">' + dkeys.map((k) => '<div title="' + U.fmtDate(k) + ': ' + days[k] + '"><i style="height:' + Math.round(days[k] / dmax * 100) + '%"></i><small>' + k.slice(8) + '</small><b>' + days[k] + '</b></div>').join('') + '</div>' : U.empty()) + '</div>';

    U.$$('[data-r]').forEach((c) => c.onclick = () => App.go('dash', { r: c.dataset.r }));
    const cust = () => App.go('dash', { r: 'custom', from: U.$('#dFrom').value, to: U.$('#dTo').value });
    U.$('#dFrom').onchange = cust; U.$('#dTo').onchange = cust;
  };
})();
