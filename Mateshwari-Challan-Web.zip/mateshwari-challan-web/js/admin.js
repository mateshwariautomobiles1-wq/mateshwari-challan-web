// ---------- Admin: staff rights (employees from Staff App), settings & masters ----------
(function () {
  const V = window.Views, esc = U.esc, n = U.num;

  // ===== Staff & Rights =====
  V.staff = async function (el) {
    if (!S.isAdmin) { el.innerHTML = U.empty('Sirf admin'); return; }
    const [emps, rights] = await Promise.all([DB.all('employees'), DB.all('crights')]);
    const rm = {}; rights.forEach((r) => rm[r.id] = r);
    const list = emps.filter((e) => e.active !== false).sort((a, b) => String(a.name).localeCompare(String(b.name)));
    el.innerHTML = '<h2 class="page-title">🔐 Staff & Rights</h2><p class="muted small">Employees Staff App se apne aap aa rahe hain (same login). Jis employee ko Challan App dena hai uska "access" ON karke rights chunein.</p>' +
      '<div class="row-btns left"><button class="btn ghost sm" id="allDef">Sabko default rights do</button><button class="btn ghost sm" id="allOff">Sabka access band</button></div>' +
      '<input class="search" id="sq" placeholder="🔍 Employee search">' +
      (list.length ? list.map((e) => {
        const r = Object.assign({}, rm[e.id] ? Object.assign(Object.fromEntries(Ch.RIGHTS.map((x) => [x[0], false])), rm[e.id]) : Object.assign(Ch.defaultRights(), { access: false }));
        return '<form class="card form rights" data-r="' + esc(e.id) + '" data-q="' + esc((e.name + ' ' + e.id + ' ' + (e.mobile || '') + ' ' + (e.designation || '')).toLowerCase()) + '"><div class="row">' +
          (e.photo ? '<img class="avatar" style="width:38px;height:38px" src="' + esc(e.photo) + '">' : '<span class="avatar ph" style="width:38px;height:38px">' + esc((e.name || '?')[0]) + '</span>') +
          '<b class="grow">' + esc(e.name) + ' <small class="muted">' + esc(e.id) + ' · ' + esc(e.designation || '') + ' · ' + esc(e.mobile || '') + '</small></b>' +
          '<span class="badge ' + (r.access ? 'ok' : 'muted') + '">' + (r.access ? 'Access ON' : 'No access') + '</span></div>' +
          '<details><summary>Rights badlein</summary><div class="rights-grid">' + Ch.RIGHTS.map((x) => U.field(x[0], x[1], r[x[0]], { type: 'checkbox' })).join('') + '</div>' +
          '<button class="btn sm">Save</button></details></form>';
      }).join('') : U.empty('Staff App me koi employee nahi mila'));
    U.$$('form.rights').forEach((f) => f.onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(f); const r = {}; Ch.RIGHTS.forEach((x) => r[x[0]] = !!d[x[0]]);
      const e = list.find((x) => x.id === f.dataset.r);
      U.loading(true);
      try { await DB.set('crights', f.dataset.r, Object.assign(r, { name: e.name, updatedAt: DB.now() })); U.toast(e.name + ': ' + T('saved'), 'ok'); App.refresh(); }
      catch (err) { U.toast(err.message, 'err'); } finally { U.loading(false); }
    });
    U.$('#sq').oninput = (ev) => { const q = ev.target.value.toLowerCase(); U.$$('form.rights').forEach((f) => f.style.display = f.dataset.q.includes(q) ? '' : 'none'); };
    U.$('#allDef').onclick = async () => {
      if (!(await U.confirm('Sabhi active employees ko default rights (access ON) de dein?', 'Haan'))) return;
      U.loading(true); await DB.batch(list.map((e) => ['set', 'crights', e.id, Object.assign(Ch.defaultRights(), { name: e.name, updatedAt: DB.now() })])); U.loading(false); App.refresh();
    };
    U.$('#allOff').onclick = async () => {
      if (!(await U.confirm('Sabka Challan App access band karein?', 'Band karein'))) return;
      U.loading(true); await DB.batch(list.map((e) => ['merge', 'crights', e.id, { access: false }])); U.loading(false); App.refresh();
    };
  };

  // ===== Settings & Masters =====
  const lines = (a) => (a || []).join('\n');
  const toList = (s) => String(s || '').split('\n').map((x) => x.trim()).filter(Boolean);
  V.settings = async function (el) {
    if (!S.isAdmin) { el.innerHTML = U.empty('Sirf admin'); return; }
    const cs = S.cs;
    const counter = (await DB.get('ccounter', 'challan')) || { next: 0 };
    const req = cs.required || {};
    const groups = {}; Ch.FIELDS.forEach((f) => (groups[f[2]] = groups[f[2]] || []).push(f));
    const show = Object.assign(Cust.defaultShow(), cs.custShow || {});
    const tl = cs.tallyLedgers || {};
    el.innerHTML = '<h2 class="page-title">⚙️ Settings & Masters</h2><form id="stf" class="form">' +
      '<details class="card sec" open><summary><b>🏢 Showroom & Challan No</b></summary><div class="sec-body"><div class="grid2">' +
      U.field('prefix', 'Challan Prefix', cs.prefix) + U.field('padding', 'Number digits', cs.padding, { type: 'number' }) +
      U.field('nextNo', 'Agla challan number (abhi tak ' + (counter.next || 0) + ' bane)', (counter.next || 0) + 1, { type: 'number' }) +
      U.field('showroomPhone', 'Showroom Phone', cs.showroomPhone) + U.field('gstin', 'GSTIN', cs.gstin) + '</div>' +
      U.field('showroomAddress', 'Showroom Address (print par)', cs.showroomAddress, { type: 'textarea', rows: 2 }) +
      U.field('challanTerms', 'Challan Terms (print par)', cs.challanTerms, { type: 'textarea', rows: 3 }) + '</div></details>' +
      '<details class="card sec"><summary><b>📚 Masters (har line me ek)</b></summary><div class="sec-body"><div class="grid2">' +
      U.field('models', 'Models', lines(cs.models), { type: 'textarea', rows: 6 }) + U.field('colours', 'Colours', lines(cs.colours), { type: 'textarea', rows: 6 }) +
      U.field('financers', 'Finance Companies', lines(cs.financers), { type: 'textarea', rows: 6 }) + U.field('insurers', 'Insurance Companies', lines(cs.insurers), { type: 'textarea', rows: 6 }) +
      U.field('schemes', 'Schemes / Campaigns / Cash Bonus', lines(cs.schemes), { type: 'textarea', rows: 6 }) + U.field('docTypes', 'Document Types', lines(cs.docTypes), { type: 'textarea', rows: 6 }) + '</div>' +
      U.field('priceItems', 'On-Road Price items (code|Naam) — code mat badlein, naye jod sakte hain', (cs.priceItems || Ch.DEFAULT_PRICE_ITEMS).map((x) => x.k + '|' + x.l).join('\n'), { type: 'textarea', rows: 8 }) + '</div></details>' +
      '<details class="card sec"><summary><b>✅ Mandatory Fields (kya bharna zaroori hai)</b></summary><div class="sec-body">' +
      Object.keys(groups).map((g) => '<h4>' + esc(g) + '</h4><div class="rights-grid">' + groups[g].map((f) => U.field('req_' + f[0], f[1], !!req[f[0]], { type: 'checkbox' })).join('') + '</div>').join('') +
      '<p class="muted small">Finance fields sirf Finance sale par aur Exchange fields sirf exchange tick hone par check honge.</p></div></details>' +
      '<details class="card sec"><summary><b>👤 Customer App — default kya dikhe / kya kar sake</b></summary><div class="sec-body"><div class="rights-grid">' +
      Cust.RIGHTS.map((r) => U.field('cs_' + r[0], r[1], show[r[0]], { type: 'checkbox' })).join('') + '</div>' +
      U.field('custDocKinds', 'Customer kaun se documents download kar sake (har line me ek)', lines(cs.custDocKinds), { type: 'textarea', rows: 4 }) +
      '<p class="muted small">Har customer ke liye alag setting challan → 👤 Customer Login me badal sakte hain.</p></div></details>' +
      '<details class="card sec"><summary><b>✉️ Letters & WhatsApp templates</b></summary><div class="sec-body"><p class="muted small">Placeholders: {name} {father} {challanNo} {date} {model} {colour} {chassis} {engine} {regNo} {invoiceNo} {payable} {received} {due} {dueDays} {dpDue} {financer} {loanAmount} {emi} {tenure} {emiStart} {policyNo} {insCompany} {showroom} {phone} {today}</p>' +
      U.field('welcomeTemplate', 'Welcome Letter', cs.welcomeTemplate, { type: 'textarea', rows: 6 }) + U.field('dueTemplate', 'Due Payment Notice', cs.dueTemplate, { type: 'textarea', rows: 6 }) +
      U.field('waWelcome', 'WhatsApp Welcome', cs.waWelcome, { type: 'textarea', rows: 4 }) + U.field('waDue', 'WhatsApp Due Reminder', cs.waDue, { type: 'textarea', rows: 4 }) + '</div></details>' +
      '<details class="card sec"><summary><b>📒 Tally Ledger names</b></summary><div class="sec-body"><div class="grid2">' +
      U.field('tallyCashLedger', 'Cash ledger', cs.tallyCashLedger) + U.field('tallyBankLedger', 'Bank ledger', cs.tallyBankLedger) +
      (cs.priceItems || Ch.DEFAULT_PRICE_ITEMS).map((it) => U.field('tl_' + it.k, it.l + ' → ledger', tl[it.k] || it.l)).join('') + '</div></div></details>' +
      '<div class="sticky-save"><button class="btn block">💾 Save Settings</button></div></form>';

    U.$('#stf').onsubmit = async (ev) => {
      ev.preventDefault(); const d = U.formData(ev.target);
      const o = { prefix: d.prefix, padding: n(d.padding) || 1, showroomPhone: d.showroomPhone, gstin: d.gstin, showroomAddress: d.showroomAddress, challanTerms: d.challanTerms,
        models: toList(d.models), colours: toList(d.colours), financers: toList(d.financers), insurers: toList(d.insurers), schemes: toList(d.schemes), docTypes: toList(d.docTypes),
        custDocKinds: toList(d.custDocKinds), welcomeTemplate: d.welcomeTemplate, dueTemplate: d.dueTemplate, waWelcome: d.waWelcome, waDue: d.waDue,
        tallyCashLedger: d.tallyCashLedger, tallyBankLedger: d.tallyBankLedger, required: {}, custShow: {}, tallyLedgers: {} };
      o.priceItems = toList(d.priceItems).map((l) => { const [k, ...rest] = l.split('|'); return { k: k.trim().replace(/\W+/g, ''), l: (rest.join('|') || k).trim() }; }).filter((x) => x.k);
      if (!o.priceItems.length) o.priceItems = Ch.DEFAULT_PRICE_ITEMS;
      if (!o.docTypes.length) o.docTypes = Ch.defaultSettings().docTypes;
      Ch.FIELDS.forEach((f) => { if (d['req_' + f[0]]) o.required[f[0]] = true; });
      Cust.RIGHTS.forEach((r) => o.custShow[r[0]] = !!d['cs_' + r[0]]);
      o.priceItems.forEach((it) => { if (d['tl_' + it.k]) o.tallyLedgers[it.k] = d['tl_' + it.k]; });
      U.loading(true);
      try {
        await DB.set('settings', 'challan', o, true);
        const nx = Math.max(1, parseInt(d.nextNo) || 1);
        if (nx - 1 !== (counter.next || 0)) await DB.set('ccounter', 'challan', { next: nx - 1 }, true);
        S.cs = Object.assign(Ch.defaultSettings(), S.cs, o);
        U.toast(T('saved'), 'ok');
      } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
    };
  };
})();
