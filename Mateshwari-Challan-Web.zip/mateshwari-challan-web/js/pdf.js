// ---------- PDF: challan, statement, due notice, welcome letter, report tables ----------
(function () {
  const P = window.Print = {};
  const n = U.num, M = U.moneyPlain;
  const fd = (v) => (v ? U.fmtDate(v) : '-');
  // jsPDF core fonts are Latin only: strip emoji / Hindi
  const clean = (s) => String(s == null ? '' : s).replace(/₹/g, 'Rs.').replace(/[^\x20-\x7E\n]/g, '').trim();

  let logoData = null;
  async function logo() {
    if (logoData !== null) return logoData;
    const src = (S.company && S.company.logo) || 'img/logo.png';
    if (/^data:/.test(src)) return (logoData = src);
    try {
      logoData = await new Promise((res) => { const i = new Image(); i.onload = () => { const c = document.createElement('canvas'); c.width = i.width; c.height = i.height; c.getContext('2d').drawImage(i, 0, 0); res(c.toDataURL('image/png')); }; i.onerror = () => res(''); i.src = src; });
    } catch (e) { logoData = ''; }
    return logoData;
  }
  P.co = () => ({
    name: (S.company && S.company.name) || APP_INFO.showroom,
    address: S.cs.showroomAddress || (S.company && S.company.address) || '',
    phone: S.cs.showroomPhone || (S.company && S.company.phone) || '',
    gstin: S.cs.gstin || (S.company && S.company.gstin) || ''
  });
  P.vars = function (c, k) {
    const co = P.co();
    return { name: c.customerName || '', father: c.fatherName || '', mobile: c.mobile || '', address: c.address || '', challanNo: c.challanNo || '', date: fd(c.challanDate),
      today: fd(U.dateKey()), model: c.model || '', colour: c.colour || '', chassis: c.chassisNo || '', engine: c.engineNo || '', regNo: c.regNo || '',
      invoiceNo: c.invoiceNo || '', payable: M(k.payable), received: M(k.received), due: M(Math.max(0, k.due)), dueDays: k.dueDays || 0, dpDue: M(k.dpDue),
      financer: c.financer || '', loanAmount: M(c.loanAmount), emi: M(c.emi), tenure: c.tenure || '', emiStart: fd(c.emiStart),
      policyNo: c.policyNo || '', insCompany: c.insCompany || '', showroom: co.name, phone: co.phone };
  };

  async function doc(orient) { const { jsPDF } = window.jspdf; return new jsPDF({ orientation: orient || 'portrait', unit: 'mm', format: 'a4' }); }
  async function header(d, title) {
    const co = P.co(); const W = d.internal.pageSize.getWidth();
    const lg = await logo();
    if (lg) { try { d.addImage(lg, 'PNG', 12, 8, 26, 16); } catch (e) { } }
    d.setFont('helvetica', 'bold'); d.setFontSize(15); d.setTextColor(218, 37, 29); d.text(clean(co.name), W / 2, 14, { align: 'center' });
    d.setTextColor(40); d.setFont('helvetica', 'normal'); d.setFontSize(9);
    d.text(clean([co.address, co.phone ? 'Ph: ' + co.phone : '', co.gstin ? 'GSTIN: ' + co.gstin : ''].filter(Boolean).join('  |  ')), W / 2, 19, { align: 'center', maxWidth: W - 70 });
    d.setDrawColor(218, 37, 29); d.setLineWidth(0.6); d.line(10, 26, W - 10, 26);
    if (title) { d.setFont('helvetica', 'bold'); d.setFontSize(12); d.text(clean(title), W / 2, 33, { align: 'center' }); }
    return 38;
  }
  function footer(d) {
    const pages = d.internal.getNumberOfPages(), W = d.internal.pageSize.getWidth(), H = d.internal.pageSize.getHeight();
    for (let i = 1; i <= pages; i++) { d.setPage(i); d.setFontSize(8); d.setTextColor(120); d.text('Page ' + i + '/' + pages + '  ·  Generated ' + U.fmtDT(new Date()), W / 2, H - 6, { align: 'center' }); }
  }
  const kvTable = (d, y, rows, title) => {
    rows = rows.filter((r) => r[1] !== '' && r[1] != null && r[1] !== '-');
    if (!rows.length) return y;
    d.autoTable({ startY: y, head: title ? [[{ content: title, colSpan: 4 }]] : undefined, body: pairs(rows), theme: 'grid', styles: { fontSize: 9, cellPadding: 1.6 },
      headStyles: { fillColor: [218, 37, 29] }, columnStyles: { 0: { fontStyle: 'bold', cellWidth: 38 }, 2: { fontStyle: 'bold', cellWidth: 38 } }, margin: { left: 10, right: 10 } });
    return d.lastAutoTable.finalY + 4;
  };
  const pairs = (rows) => { const out = []; for (let i = 0; i < rows.length; i += 2) out.push([clean(rows[i][0]), clean(rows[i][1]), clean(rows[i + 1] ? rows[i + 1][0] : ''), clean(rows[i + 1] ? rows[i + 1][1] : '')]); return out; };
  async function finish(d, name, share) {
    footer(d);
    const b64 = d.output('datauristring').split(',')[1];
    if (share === 'b64') return b64;
    await U.saveFile(name.replace(/[^\w\-.]+/g, '_') + '.pdf', b64, 'application/pdf');
    return b64;
  }
  function signBlock(d, y) {
    const W = d.internal.pageSize.getWidth();
    y = Math.max(y + 18, 250); d.setFontSize(9); d.setTextColor(40);
    d.line(14, y, 70, y); d.line(W - 70, y, W - 14, y);
    d.text('Customer Signature', 14, y + 5); d.text('For ' + clean(P.co().name), W - 70, y + 5);
  }

  // ===== Delivery Challan =====
  P.challan = async function (c, pays, k, mode) {
    k = k || Ch.calc(c, pays);
    const d = await doc(); let y = await header(d, 'DELIVERY CHALLAN');
    y = kvTable(d, y, [['Challan No', c.challanNo], ['Date', fd(c.challanDate)], ['Sale Type', c.saleType], ['Sales Executive', c.executive]]);
    y = kvTable(d, y, [['Customer', c.customerName], ['Father Name', c.fatherName], ['Mobile', c.mobile], ['Alt Mobile', c.altMobile], ['Address', (c.address || '') + ' ' + (c.city || '')], ['Aadhaar / PAN', [c.aadhaar, c.pan].filter(Boolean).join(' / ')]], 'Customer Details');
    y = kvTable(d, y, [['Model', (c.model || '') + ' ' + (c.variant || '')], ['Colour', c.colour], ['Engine No', c.engineNo], ['Chassis No', c.chassisNo], ['Key No', c.keyNo], ['Battery No', c.batteryNo],
      ['Invoice No', c.invoiceNo], ['Invoice Date', c.invoiceDate ? fd(c.invoiceDate) : ''], ['Reg No', c.regNo], ['Insurance', [c.insCompany, c.policyNo].filter(Boolean).join(' - ')]], 'Vehicle Details');
    const pr = c.price || {};
    const body = Ch.priceItems().filter((it) => n(pr[it.k])).map((it) => [clean(it.l), M(pr[it.k])]);
    const adj = U.round2(Ch.gross(c) - Ch.itemsTotal(c)); if (Math.abs(adj) > 0.005) body.push([Ch.itemsTotal(c) ? 'On-Road (manual adjustment)' : 'On-Road Price', M(adj)]);
    if (k.discount) body.push(['Less: Discount', '- ' + M(k.discount)]);
    if (k.custScheme) body.push(['Less: Scheme', '- ' + M(k.custScheme)]);
    body.push([{ content: 'Net Payable', styles: { fontStyle: 'bold' } }, { content: M(k.payable), styles: { fontStyle: 'bold' } }]);
    if (c.isExchange) body.push(['Exchange (' + clean(c.exOldModel + ' ' + (c.exRegNo || '')) + ')', '- ' + M(k.exValue)]);
    if (c.saleType === 'Finance') body.push(['Finance (' + clean(c.financer) + ')', M(k.finAmt)]);
    body.push(['Received till date', M(k.custPaid + k.disbursed)]);
    body.push([{ content: 'Balance Due', styles: { fontStyle: 'bold' } }, { content: M(Math.max(0, k.due)), styles: { fontStyle: 'bold' } }]);
    d.autoTable({ startY: y, head: [['On-Road Price', 'Amount']], body, theme: 'grid', styles: { fontSize: 9, cellPadding: 1.6 }, headStyles: { fillColor: [218, 37, 29] },
      columnStyles: { 1: { halign: 'right', cellWidth: 45 } }, margin: { left: 10, right: 10 } });
    y = d.lastAutoTable.finalY + 5;
    if (S.cs.challanTerms) { d.setFontSize(8.5); d.text(d.splitTextToSize('Terms: ' + clean(S.cs.challanTerms), 185), 12, y); y += 14; }
    signBlock(d, y);
    return finish(d, 'Challan_' + c.challanNo, mode);
  };

  // ===== Customer statement (ledger) =====
  P.statement = async function (c, pays, calls, k, mode, forCustomer) {
    k = k || Ch.calc(c, pays);
    const d = await doc(); let y = await header(d, 'CUSTOMER STATEMENT / LEDGER');
    y = kvTable(d, y, [['Customer', c.customerName], ['Challan No', c.challanNo], ['Father Name', c.fatherName], ['Date', fd(c.challanDate)], ['Mobile', c.mobile], ['Vehicle', (c.model || '') + ' ' + (c.colour || '')],
      ['Chassis No', c.chassisNo], ['Sale Type', c.saleType + (c.financer ? ' - ' + c.financer : '')]]);
    const rows = Ledger.rows(c, pays, forCustomer ? [] : calls, k);
    d.autoTable({ startY: y, head: [['Date', 'Particulars', 'Debit', 'Credit', 'Balance']], body: rows.map((r) => [fd(r.date), clean(r.part), r.dr ? M(r.dr) : '', r.cr ? M(r.cr) : '', r.call ? '' : M(r.bal)]),
      foot: [['', 'Balance Due', '', '', M(k.due)]], theme: 'grid', styles: { fontSize: 8.5, cellPadding: 1.5 }, headStyles: { fillColor: [218, 37, 29] }, footStyles: { fillColor: [240, 240, 240], textColor: 20 },
      columnStyles: { 0: { cellWidth: 22 }, 2: { halign: 'right', cellWidth: 26 }, 3: { halign: 'right', cellWidth: 26 }, 4: { halign: 'right', cellWidth: 28 } }, margin: { left: 10, right: 10 } });
    y = d.lastAutoTable.finalY + 5;
    if (c.saleType === 'Finance' && c.emi) y = kvTable(d, y, [['Loan Amount', M(c.loanAmount)], ['EMI', M(c.emi) + ' x ' + (c.tenure || '')], ['EMI Start', fd(c.emiStart)], ['Disbursed', M(k.disbursed)]], 'Finance');
    return finish(d, 'Statement_' + c.challanNo + '_' + c.customerName, mode);
  };

  // ===== Letters =====
  async function letter(c, k, title, tpl, mode, extraRows) {
    const d = await doc(); let y = await header(d, title);
    const W = d.internal.pageSize.getWidth();
    d.setFont('helvetica', 'normal'); d.setFontSize(10); d.setTextColor(30);
    d.text('Ref: ' + clean(c.challanNo), 12, y); d.text('Date: ' + fd(U.dateKey()), W - 12, y, { align: 'right' }); y += 7;
    d.text(d.splitTextToSize(clean('To,\n' + c.customerName + (c.fatherName ? ' S/o ' + c.fatherName : '') + '\n' + (c.address || '') + ' ' + (c.city || '') + '\nMobile: ' + (c.mobile || '')), 120), 12, y);
    y += 24;
    const body = d.splitTextToSize(clean(U.fillTemplate(tpl, P.vars(c, k))), W - 24);
    d.text(body, 12, y); y += body.length * 4.6 + 4;
    if (extraRows && extraRows.length) y = kvTable(d, y, extraRows);
    d.setFont('helvetica', 'bold'); d.text('For ' + clean(P.co().name), W - 12, Math.max(y + 16, 240), { align: 'right' });
    d.setFont('helvetica', 'normal'); d.text('Authorised Signatory', W - 12, Math.max(y + 30, 254), { align: 'right' });
    return finish(d, title.replace(/\s+/g, '_') + '_' + c.challanNo, mode);
  }
  // rows filtered by what admin allows customers to see
  P.visibleRows = function (c, k, show) {
    const r = [];
    if (show.vehicle) r.push(['Vehicle', (c.model || '') + ' ' + (c.colour || '')], ['Chassis No', c.chassisNo], ['Engine No', c.engineNo], ['Reg No', c.regNo]);
    if (show.invoice) r.push(['Invoice No', c.invoiceNo], ['Invoice Date', c.invoiceDate ? fd(c.invoiceDate) : '']);
    if (show.price) r.push(['On-Road Price', M(k.gross)], ['Net Payable', M(k.payable)]);
    if (show.payments) r.push(['Amount Received', M(k.custPaid + k.disbursed)]);
    if (show.due) r.push(['Balance Due', M(Math.max(0, k.due))]);
    if (show.finance && c.saleType === 'Finance') r.push(['Finance', c.financer], ['Loan Amount', M(c.loanAmount)]);
    if (show.emi && c.emi) r.push(['EMI', M(c.emi) + ' x ' + (c.tenure || '')], ['EMI Start', fd(c.emiStart)]);
    if (show.insurance) r.push(['Insurance', c.insCompany], ['Policy No', c.policyNo], ['Valid till', c.insTo ? fd(c.insTo) : '']);
    if (show.rto) r.push(['RTO Status', c.rtoStatus]);
    if (show.exchange && c.isExchange) r.push(['Exchange Vehicle', c.exOldModel], ['Exchange Value', M(c.exValue)]);
    return r;
  };
  P.welcome = (c, k, mode) => letter(c, k, 'WELCOME LETTER', S.cs.welcomeTemplate, mode, P.visibleRows(c, k, Cust.showFor(c)));
  P.dueNotice = (c, k, mode) => letter(c, k, 'PAYMENT DUE NOTICE', S.cs.dueTemplate, mode,
    [['Challan No', c.challanNo], ['Sale Date', fd(c.challanDate)], ['Vehicle', (c.model || '') + ' ' + (c.chassisNo || '')], ['Net Payable', M(k.payable)], ['Received', M(k.received)],
      ['Balance Due', M(Math.max(0, k.due))], ['Due since', (k.dueDays || 0) + ' days']]);

  // ===== Report table =====
  P.table = async function (rep, mode) {
    const wide = rep.columns.length > 8;
    const d = await doc(wide ? 'landscape' : 'portrait'); const y = await header(d, rep.title + (rep.sub ? ' (' + rep.sub + ')' : ''));
    d.autoTable({ startY: y, head: [rep.columns.map(clean)], body: rep.rows.map((r) => r.map((v) => (typeof v === 'number' ? U.round2(v).toLocaleString('en-IN') : clean(v)))),
      foot: rep.foot ? [rep.foot.map((v) => (typeof v === 'number' ? U.round2(v).toLocaleString('en-IN') : clean(v)))] : undefined,
      theme: 'grid', styles: { fontSize: wide ? 6.5 : 8, cellPadding: 1.2 }, headStyles: { fillColor: [218, 37, 29] }, footStyles: { fillColor: [240, 240, 240], textColor: 20, fontStyle: 'bold' }, margin: { left: 6, right: 6 } });
    return finish(d, rep.title + '_' + U.dateKey(), mode);
  };
})();
