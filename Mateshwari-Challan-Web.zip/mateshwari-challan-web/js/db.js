// ---------- Firebase data layer (same project as Staff App) ----------
(function () {
  const DB = {};
  let auth, fs, FV;

  DB.configured = function () {
    const c = window.FIREBASE_CONFIG || {};
    return c.apiKey && !/PASTE/.test(c.apiKey) && c.projectId && !/PASTE/.test(c.projectId);
  };
  DB.init = function () {
    firebase.initializeApp(window.FIREBASE_CONFIG);
    auth = firebase.auth(); fs = firebase.firestore();
    try { fs.enablePersistence && fs.enablePersistence({ synchronizeTabs: true }).catch(() => { }); } catch (e) { }
    FV = firebase.firestore.FieldValue;
    DB.auth = auth; DB.fs = fs;
  };

  DB.now = () => FV.serverTimestamp();
  DB.inc = (n) => FV.increment(n);
  DB.delField = () => FV.delete();
  DB.union = (...v) => FV.arrayUnion(...v);
  DB.remove = (...v) => FV.arrayRemove(...v);

  const col = (n) => fs.collection(n);
  const snapList = (s) => s.docs.map((d) => Object.assign({ id: d.id }, d.data()));
  const docData = (d) => (d.exists ? Object.assign({ id: d.id }, d.data()) : null);

  DB.newId = (c) => col(c).doc().id;
  DB.get = async (c, id) => docData(await col(c).doc(id).get());
  DB.set = (c, id, data, merge) => col(c).doc(id).set(data, merge ? { merge: true } : undefined);
  DB.update = (c, id, data) => col(c).doc(id).update(data);
  DB.add = async (c, data) => { const r = await col(c).add(data); return r.id; };
  DB.del = (c, id) => col(c).doc(id).delete();
  DB.all = async (c) => snapList(await col(c).get());
  DB.query = async (c, wheres) => {
    let q = col(c);
    (wheres || []).forEach((w) => { q = q.where(w[0], w[1], w[2]); });
    return snapList(await q.get());
  };
  // batch write: ops = [['set'|'update'|'delete', col, id, data]]
  DB.batch = async function (ops) {
    for (let i = 0; i < ops.length; i += 400) {
      const b = fs.batch();
      ops.slice(i, i + 400).forEach((o) => {
        const ref = col(o[1]).doc(o[2]);
        if (o[0] === 'set') b.set(ref, o[3]); else if (o[0] === 'merge') b.set(ref, o[3], { merge: true });
        else if (o[0] === 'update') b.update(ref, o[3]); else b.delete(ref);
      });
      await b.commit();
    }
  };
  // Next running number (challan no.) — safe for many users at once
  DB.nextNumber = async function (key) {
    const ref = col('ccounter').doc(key);
    return fs.runTransaction(async (t) => {
      const d = await t.get(ref);
      const n = ((d.exists && d.data().next) || 0) + 1;
      t.set(ref, { next: n }, { merge: true });
      return n;
    });
  };

  DB.signIn = async function (id, pass) {
    let email = id.trim().toLowerCase();
    if (!email.includes('@')) {
      const mob = (/^c\s*\d/.test(email) ? 'c' : '') + email.replace(/\D/g, '');
      const map = await DB.get('logins', mob);
      if (!map) throw new Error(T('loginNotFound'));
      email = map.email;
    }
    return auth.signInWithEmailAndPassword(email, pass);
  };
  DB.signOut = () => auth.signOut();
  DB.changePassword = async (oldPass, newPass) => {
    const u = auth.currentUser;
    const cred = firebase.auth.EmailAuthProvider.credential(u.email, oldPass);
    await u.reauthenticateWithCredential(cred);
    await u.updatePassword(newPass);
  };
  window.DB = DB;
})();

// ---------- Large files: base64 split across Firestore docs (no Firebase Storage needed) ----------
(function () {
  const F = window.Files = {};
  const CHUNK = 700000;
  F.MAX = 8 * 1024 * 1024;
  F.put = async function (col, id, meta, data) {
    const parts = [];
    for (let i = 0; i < data.length; i += CHUNK) parts.push(data.slice(i, i + CHUNK));
    if (!parts.length) parts.push('');
    for (let i = 1; i < parts.length; i++) await DB.set(col, id + '__p' + i, Object.assign({}, meta, { data: parts[i], partOf: id }));
    await DB.set(col, id, Object.assign({}, meta, { data: parts[0], parts: parts.length }));
  };
  F.get = async function (col, id) {
    const d = await DB.get(col, id);
    if (!d) return null;
    let data = d.data || '';
    for (let i = 1; i < (d.parts || 1); i++) { const p = await DB.get(col, id + '__p' + i); data += (p && p.data) || ''; }
    return Object.assign({}, d, { data });
  };
  F.del = async function (col, id) {
    let n = 1; try { const d = await DB.get(col, id); n = (d && d.parts) || 1; } catch (e) { }
    for (let i = 1; i < n; i++) { try { await DB.del(col, id + '__p' + i); } catch (e) { } }
    try { await DB.del(col, id); } catch (e) { }
  };
})();
