// ---------- Customer: letters, WhatsApp, customer login + rights, customer portal ----------
(function () {
  const V = window.Views, esc = U.esc, n = U.num;
  const Cust = window.Cust = {};
  const CDOMAIN = 'cust.mateshwari.app';

  Cust.RIGHTS = [
    ['vehicle', 'Vehicle details (model, chassis, engine, reg no)'], ['invoice', 'Invoice details'], ['price', 'On-road price breakup'],
    ['payments', 'Payment history'], ['due', 'Balance due'], ['finance', 'Finance / loan details'], ['emi', 'EMI schedule'],
    ['insurance', 'Insurance details'], ['rto', 'RTO / registration status'], ['exchange', 'Exchange details'],
    ['statement', 'Statement PDF download'], ['downloadDocs', 'Documents download'], ['uploadDocs', 'Document upload (KYC etc.)'], ['callback', 'Callback / query request']
  ];
  Cust.defaultShow = () => ({ vehicle: true, invoice: true, price: true, payments: true, due: true, finance: true, emi: true, insurance: true, rto: true, exchange: true,
    statement: true, downloadDocs: true, uploadDocs: false, callback: true });

  // extra defaults for settings
  const baseDefaults = Ch.defaultSettings;
  Ch.defaultSettings = () => Object.assign(baseDefaults(), {
    custShow: Cust.defaultShow(),
    custDocKinds: ['Invoice', 'Insurance Policy', 'RC / Form 20', 'Delivery Photo'],
    welcomeTemplate: 'Dear {name},\n\nWelcome to the {showroom} family! Thank you for choosing us for your new {model} ({colour}). Your delivery challan no. is {challanNo} dated {date}.\n\nChassis No: {chassis}   Engine No: {engine}\n\nFor service bookings, insurance renewal or any help, please call us at {phone}. We wish you many happy and safe rides.',
    dueTemplate: 'Dear {name},\n\nThis is to remind you that an amount of {due} is pending against your vehicle {model} (Challan No. {challanNo} dated {date}) for the last {dueDays} days.\n\nKindly clear the outstanding amount at the earliest to avoid any inconvenience. If you have already paid, please ignore this notice and share the payment details with us.\n\nFor any query please call {phone}.',
    waWelcome: 'Namaste {name} ji,\n{showroom} parivar me aapka swagat hai! Aapki nayi {model} ({colour}) ki delivery ke liye badhai.\nChallan No: {challanNo}\nChassis: {chassis}\nKisi bhi madad ke liye call karein: {phone}',
    waDue: 'Namaste {name} ji,\n{showroom} se yaad dilana tha ki aapke vehicle {model} (Challan {challanNo}) ka {due} baki hai ({dueDays} din se).\nKripya jald jama karein. Already pay kar diya ho to details share karein.\nCall: {phone}'
  });

  Cust.showFor = (c) => Object.assign(Cust.defaultShow(), S.cs.custShow || {}, (c && c.custShow) || {});

  Cust.whatsapp = function (c, k, type) {
    const tpl = type === 'due' ? S.cs.waDue : S.cs.waWelcome;
    let msg = U.fillTemplate(tpl, Print.vars(c, k));
    if (type !== 'due') {
      const show = Cust.showFor(c);
      const extra = Print.visibleRows(c, k, show).filter((r) => r[1] && r[1] !== '-').map((r) => r[0] + ': ' + r[1]).join('\n');
      if (extra) msg += '\n\n' + extra;
      if (c.custUid) msg += '\n\nApp Login ID: C' + c.mobile;
    }
    window.open('https://wa.me/91' + String(c.mobile || '').replace(/\D/g, '').slice(-10) + '?text=' + encodeURIComponent(msg), '_system');
  };

  // Letters / WhatsApp menu from challan view
  Cust.lettersDialog = function (c, k) {
    const m = U.modal('Letters & WhatsApp · ' + c.customerName, '<div class="menu-list">' +
      '<a data-x="welcome">📄 Welcome Letter (PDF)</a><a data-x="due">⚠️ Due Payment Notice (PDF)</a>' +
      '<a data-x="waWelcome">💬 WhatsApp: Welcome message</a><a data-x="waDue">💬 WhatsApp: Due reminder</a>' +
      '<a data-x="share">📤 Statement PDF → WhatsApp share</a></div><p class="muted small">PDF share karne par WhatsApp chunein aur customer ka chat select karein.</p>', {
      onOpen: (w) => U.$$('[data-x]', w).forEach((a) => a.onclick = async () => {
        const x = a.dataset.x; m.close();
        U.loading(true, 'Ban raha hai...');
        try {
          if (x === 'welcome') await Print.welcome(c, k);
          else if (x === 'due') { if (k.due <= 0.5) U.toast('Is customer ka koi due nahi hai', 'info'); await Print.dueNotice(c, k); }
          else if (x === 'waWelcome') Cust.whatsapp(c, k, 'welcome');
          else if (x === 'waDue') Cust.whatsapp(c, k, 'due');
          else { const pays = await Ch.payments(c.id); await Print.statement(c, pays, [], k, null, true); }
        } catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
      })
    });
  };

  // ===== Customer login (admin only) =====
  async function createAuth(email, password) {
    const sec = firebase.initializeApp(window.FIREBASE_CONFIG, 'c' + Date.now());
    try { const cr = await sec.auth().createUserWithEmailAndPassword(email, password); const uid = cr.user.uid; await sec.auth().signOut(); return uid; }
    finally { try { await sec.delete(); } catch (e) { } }
  }
  Cust.loginDialog = async function (c, done) {
    const mob = String(c.mobile || '').replace(/\D/g, '').slice(-10);
    if (mob.length !== 10) return U.toast('Pehle customer ka sahi mobile number bharein', 'err');
    const map = await DB.get('logins', 'c' + mob);
    const user = map ? await DB.get('users', map.uid) : null;
    const show = Cust.showFor(c);
    const m = U.modal('Customer App Login', '<div class="note">User ID: <b>C' + mob + '</b>' + (user ? (user.active === false ? ' · <span class="low">Disabled</span>' : ' · <span class="good">Active</span>') : ' · abhi login nahi bana') + '</div>' +
      '<form class="form" id="clf">' + U.field('password', user ? 'Naya password (reset karna ho to)' : 'Password (min 6)', '', { type: 'text' }) +
      '<h4>Is customer ko kya dikhe / kya kar sake</h4><div class="rights-grid">' + Cust.RIGHTS.map((r) => U.field(r[0], r[1], show[r[0]], { type: 'checkbox' })).join('') + '</div>' +
      '<p class="muted small">Default sabhi customers ke liye Settings me set hai. Yahan ki setting sirf is challan/customer par lagegi.</p>' +
      '<button class="btn block">' + (user ? 'Update' : 'Create Login') + '</button>' +
      (user ? '<button type="button" class="btn ghost block" id="clDis">' + (user.active === false ? 'Enable Login' : 'Disable Login') + '</button>' : '') + '</form>', {
      onOpen: (w) => {
        const dis = U.$('#clDis', w);
        if (dis) dis.onclick = async () => { await DB.update('users', user.id, { active: user.active === false }); U.toast(T('saved'), 'ok'); m.close(); done && done(); };
        U.$('#clf', w).onsubmit = async (ev) => {
          ev.preventDefault(); const d = U.formData(ev.target);
          const custShow = {}; Cust.RIGHTS.forEach((r) => { custShow[r[0]] = !!d[r[0]]; });
          if (!user && d.password.length < 6) return U.toast(T('pwdShort'), 'err');
          if (user && d.password && d.password.length < 6) return U.toast(T('pwdShort'), 'err');
          U.loading(true);
          try {
            let uid = user && user.id;
            const ids = Array.from(new Set(((user && user.challanIds) || []).concat([c.id])));
            if (!user || d.password) {
              const email = 'c' + mob + (user ? '.' + Date.now().toString(36) : '') + '@' + CDOMAIN;
              const newUid = await createAuth(email, d.password);
              if (user) await DB.update('users', user.id, { active: false, replacedBy: newUid });
              uid = newUid;
              await DB.set('users', uid, { role: 'customer', name: c.customerName, mobile: mob, email, active: true, challanIds: ids, docKinds: S.cs.custDocKinds || [], createdAt: DB.now() });
              await DB.set('logins', 'c' + mob, { email, uid, type: 'customer' });
              // move other challans of this customer to the new login
              for (const cid of ids) { try { await DB.update('challans', cid, { custUid: uid }); } catch (e) { } }
            } else await DB.update('users', uid, { challanIds: ids, docKinds: S.cs.custDocKinds || [] });
            await DB.update('challans', c.id, { custUid: uid, custShow });
            Ch.dirty();
            await Cust.publish(c.id);
            m.close(); U.loading(false); U.toast('Customer login ready: C' + mob, 'ok'); done && done();
            if (!user || d.password) {
              const msg = 'Namaste ' + c.customerName + ' ji,\n' + Print.co().name + ' app me aapka login:\nUser ID: C' + mob + '\nPassword: ' + d.password + '\nApp me apni vehicle, payment aur documents ki details dekh sakte hain.';
              if (await U.confirm('Login details customer ko WhatsApp par bhejein?', 'WhatsApp')) window.open('https://wa.me/91' + mob + '?text=' + encodeURIComponent(msg), '_system');
            }
          } catch (e) { U.toast(App.authErr(e), 'err'); } finally { U.loading(false); }
        };
      }
    });
  };

  // ===== Publish customer-visible snapshot (only allowed fields leave the staff side) =====
  Cust.publish = async function (id) {
    const c = await DB.get('challans', id);
    if (!c || !c.custUid) return;
    const pays = await Ch.payments(id);
    const k = Ch.calc(c, pays);
    const sh = Cust.showFor(c);
    const s = { challanNo: c.challanNo, challanDate: c.challanDate, customerName: c.customerName, fatherName: c.fatherName || '', mobile: c.mobile, saleType: c.saleType, ownerId: c.ownerId, show: sh, cancelled: !!c.cancelled };
    if (sh.vehicle) Object.assign(s, { model: c.model || '', variant: c.variant || '', colour: c.colour || '', chassisNo: c.chassisNo || '', engineNo: c.engineNo || '', regNo: c.regNo || '', deliveryDate: c.deliveryDate || '' });
    if (sh.invoice) Object.assign(s, { invoiceNo: c.invoiceNo || '', invoiceDate: c.invoiceDate || '', invoiceAmount: n(c.invoiceAmount) });
    if (sh.price) s.price = Ch.priceItems().filter((it) => n((c.price || {})[it.k])).map((it) => [it.l, n(c.price[it.k])]), s.discount = k.discount + k.custScheme, s.gross = k.gross, s.payable = k.payable;
    if (sh.payments) s.payments = pays.map((p) => ({ date: p.date, kind: p.kind, mode: p.mode, amount: n(p.amount), ref: p.ref || '' })), s.received = k.received;
    if (sh.due) Object.assign(s, { due: Math.max(0, k.due), dueDays: k.dueDays || 0 });
    if (sh.finance && c.saleType === 'Finance') Object.assign(s, { financer: c.financer || '', loanAppNo: c.loanAppNo || '', loanAmount: n(c.loanAmount), loanStatus: c.loanStatus || '' });
    if (sh.emi && c.emi) Object.assign(s, { emi: n(c.emi), tenure: c.tenure || '', emiStart: c.emiStart || '', roi: c.roi || '' });
    if (sh.insurance) Object.assign(s, { insCompany: c.insCompany || '', policyNo: c.policyNo || '', insFrom: c.insFrom || '', insTo: c.insTo || '' });
    if (sh.rto) Object.assign(s, { rtoStatus: c.rtoStatus || '', plateStatus: c.plateStatus || '' });
    if (sh.exchange && c.isExchange) Object.assign(s, { exOldModel: c.exOldModel || '', exRegNo: c.exRegNo || '', exValue: n(c.exValue) });
    if (sh.downloadDocs) {
      const kinds = S.cs.custDocKinds || [];
      s.docs = (await Ch.files(id)).filter((f) => kinds.includes(f.kind) || f.byCustomer).map((f) => ({ id: f.id, kind: f.kind, name: f.name, mime: f.mime }));
    }
    await DB.set('cportal', c.custUid, { name: c.customerName, updatedAt: DB.now(), challans: { [id]: s } }, true);
  };

  // ===== Customer portal (role: customer) =====
  V.portal = async function (el) {
    const pdoc = (await DB.get('cportal', DB.auth.currentUser.uid)) || { challans: {} };
    const list = Object.keys(pdoc.challans || {}).map((id) => Object.assign({ id }, pdoc.challans[id])).filter((x) => !x.cancelled);
    const t = (v) => esc(v == null ? '' : v), d = (v) => (v ? U.fmtDate(v) : '-');
    const kv = (l, v) => (v === '' || v == null ? '' : '<div><span>' + esc(l) + '</span><b>' + v + '</b></div>');
    el.innerHTML = '<div class="hello card"><h2>Namaste, ' + t(pdoc.name || S.user.name) + ' 🙏</h2><small class="muted">' + esc(Print.co().name) + ' · ' + esc(Print.co().phone) + '</small></div>' +
      (list.length ? list.map((c) => {
        const sh = c.show || {};
        return '<div class="card"><div class="row-between"><b class="big">' + t(c.model || 'Vehicle') + ' ' + t(c.colour) + '</b><small>' + t(c.challanNo) + ' · ' + d(c.challanDate) + '</small></div>' +
          (sh.due ? '<div class="stats4 two"><div><b class="' + (c.due > 0.5 ? 'low' : 'good') + '">' + U.money(c.due) + '</b><small>Balance Due</small></div>' + (sh.payments ? '<div><b class="good">' + U.money(c.received) + '</b><small>Received</small></div>' : '') + '</div>' : '') +
          (sh.vehicle ? '<h4>Vehicle</h4><div class="kv">' + kv('Chassis No', t(c.chassisNo)) + kv('Engine No', t(c.engineNo)) + kv('Reg No', t(c.regNo)) + kv('Delivery', d(c.deliveryDate)) + '</div>' : '') +
          (sh.invoice && c.invoiceNo ? '<h4>Invoice</h4><div class="kv">' + kv('Invoice No', t(c.invoiceNo)) + kv('Date', d(c.invoiceDate)) + kv('Amount', c.invoiceAmount ? U.money(c.invoiceAmount) : '') + '</div>' : '') +
          (sh.price && c.price ? '<h4>Price</h4><div class="kv">' + c.price.map((p) => kv(p[0], U.money(p[1]))).join('') + kv('Discount / Scheme', c.discount ? '− ' + U.money(c.discount) : '') + kv('Net Payable', U.money(c.payable)) + '</div>' : '') +
          (sh.payments && c.payments ? '<h4>Payments</h4>' + (c.payments.length ? c.payments.map((p) => '<div class="li"><div class="grow"><b>' + U.money(p.amount) + '</b><small>' + d(p.date) + ' · ' + t(p.kind) + ' · ' + t(p.mode) + '</small></div></div>').join('') : U.empty()) : '') +
          (sh.finance && c.financer ? '<h4>Finance</h4><div class="kv">' + kv('Company', t(c.financer)) + kv('Loan App No', t(c.loanAppNo)) + kv('Loan Amount', U.money(c.loanAmount)) + kv('Status', t(c.loanStatus)) + '</div>' : '') +
          (sh.emi && c.emi ? '<div class="kv">' + kv('EMI', U.money(c.emi) + ' × ' + t(c.tenure)) + kv('EMI Start', d(c.emiStart)) + '</div>' : '') +
          (sh.insurance && c.policyNo ? '<h4>Insurance</h4><div class="kv">' + kv('Company', t(c.insCompany)) + kv('Policy No', t(c.policyNo)) + kv('Valid', d(c.insFrom) + ' → ' + d(c.insTo)) + '</div>' : '') +
          (sh.rto ? '<div class="kv">' + kv('RTO', t(c.rtoStatus)) + kv('Number Plate', t(c.plateStatus)) + '</div>' : '') +
          (sh.exchange && c.exOldModel ? '<div class="kv">' + kv('Exchange', t(c.exOldModel) + ' ' + t(c.exRegNo)) + kv('Value', U.money(c.exValue)) + '</div>' : '') +
          (sh.downloadDocs && c.docs && c.docs.length ? '<h4>Documents</h4>' + c.docs.map((f) => '<div class="li"><div class="grow"><b>' + t(f.kind) + '</b><small>' + t(f.name) + '</small></div><button class="btn ghost sm" data-cdoc="' + esc(c.id + '|' + f.id) + '">View</button></div>').join('') : '') +
          '<div class="act-row">' + (sh.statement ? '<button class="btn sm" data-cst="' + c.id + '">🧾 Statement PDF</button>' : '') +
          (sh.uploadDocs ? '<button class="btn ghost sm" data-cup="' + c.id + '">📎 Upload Document</button>' : '') +
          (sh.callback ? '<button class="btn ghost sm" data-ccb="' + c.id + '">☎️ Callback / Query</button>' : '') + '</div></div>';
      }).join('') : U.empty('Abhi aapke account me koi vehicle nahi juda hai'));
    const find = (id) => list.find((x) => x.id === id);
    U.$$('[data-cdoc]').forEach((b) => b.onclick = () => { const [cid, fid] = b.dataset.cdoc.split('|'); Docs.open(find(cid).docs.find((f) => f.id === fid)); });
    U.$$('[data-cst]').forEach((b) => b.onclick = () => Cust.portalStatement(find(b.dataset.cst)));
    U.$$('[data-cup]').forEach((b) => b.onclick = () => {
      const c = find(b.dataset.cup);
      Docs.uploadDialog({ id: c.id, ownerId: c.ownerId, challanNo: c.challanNo, byCustomer: true }, () => U.toast('Document showroom ko bhej diya gaya', 'ok'));
    });
    U.$$('[data-ccb]').forEach((b) => b.onclick = async () => {
      const c = find(b.dataset.ccb);
      const note = await U.prompt('Callback / Query', 'Aapka sawal ya kab call karein', '', 'textarea'); if (!note) return;
      await DB.add('ccallreq', { uid: DB.auth.currentUser.uid, challanId: c.id, challanNo: c.challanNo, ownerId: c.ownerId, customerName: c.customerName, mobile: c.mobile, note, status: 'open', at: DB.now() });
      U.toast('Request bhej di gayi. Showroom jald call karega.', 'ok');
    });
  };
  Cust.portalStatement = async function (c) {
    const { jsPDF } = window.jspdf; const d = new jsPDF();
    const co = Print.co(); const M = U.moneyPlain;
    d.setFontSize(14); d.text(co.name, 105, 14, { align: 'center' }); d.setFontSize(9); d.text(co.address + ' ' + co.phone, 105, 19, { align: 'center' });
    d.setFontSize(11); d.text('Customer Statement - ' + c.challanNo, 105, 28, { align: 'center' });
    const body = [['Customer', c.customerName], ['Date', U.fmtDate(c.challanDate)], ['Vehicle', (c.model || '') + ' ' + (c.colour || '')], ['Chassis', c.chassisNo || '']];
    (c.price || []).forEach((p) => body.push([p[0], M(p[1])]));
    if (c.payable != null) body.push(['Net Payable', M(c.payable)]);
    (c.payments || []).forEach((p) => body.push([U.fmtDate(p.date) + ' ' + p.kind + ' (' + p.mode + ')', M(p.amount)]));
    if (c.due != null) body.push(['Balance Due', M(c.due)]);
    d.autoTable({ startY: 33, body, theme: 'grid', styles: { fontSize: 9 }, columnStyles: { 1: { halign: 'right' } } });
    await U.saveFile('Statement_' + c.challanNo.replace(/\W+/g, '_') + '.pdf', d.output('datauristring').split(',')[1], 'application/pdf');
  };
})();
