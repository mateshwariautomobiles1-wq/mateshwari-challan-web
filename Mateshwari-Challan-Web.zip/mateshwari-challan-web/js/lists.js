// ---------- Lists: challans, due, DP due, finance pending, loan files, claims, pendency, customers, calling ----------
(function () {
  const V = window.Views, esc = U.esc, n = U.num;
  const L = window.Lists = {};
  const t = (v) => esc(v == null ? '' : v);

  L.open = (id) => { S.back = { v: S.view, p: S.params }; App.go('view', { id }); };
  L.row = function (c, right, sub) {
    const st = Ch.statusOf(c);
    return '<div class="card ch-row" data-cid="' + c.id + '">' + (c.photoThumb ? '<img class="avatar" style="width:44px;height:44px" src="' + esc(c.photoThumb) + '">' :
      '<span class="avatar ph" style="width:44px;height:44px;font-size:17px">' + esc((c.customerName || '?')[0]) + '</span>') +
      '<div class="grow"><b>' + t(c.customerName) + '</b> <small class="muted">' + t(c.mobile) + '</small><small class="d">' + t(c.challanNo) + ' · ' + U.fmtDate(c.challanDate) + ' · ' + t(c.model) + ' · ' +
      t(c.saleType) + (c.financer ? ' (' + t(c.financer) + ')' : '') + '</small>' + (sub ? '<small class="d">' + sub + '</small>' : '') + '</div>' +
      '<div class="right">' + (right != null ? right : '<span class="badge ' + st[1] + '">' + esc(st[0]) + '</span>') + '</div></div>';
  };
  L.bind = (el) => U.$$('[data-cid]', el).forEach((r) => r.onclick = () => L.open(r.dataset.cid));

  // generic filter bar
  function filterBar(o) {
    o = o || {};
    return '<div class="filters">' + '<input class="search" id="fq" placeholder="🔍 Naam / mobile / challan / chassis / reg no" value="' + esc(o.q || '') + '">' +
      '<input type="date" id="ff" value="' + esc(o.from || '') + '" title="From"><input type="date" id="ft" value="' + esc(o.to || '') + '" title="To">' +
      '<select id="fs"><option value="">Cash + Finance</option><option' + (o.type === 'Cash' ? ' selected' : '') + '>Cash</option><option' + (o.type === 'Finance' ? ' selected' : '') + '>Finance</option></select>' +
      '<select id="ffin"><option value="">All Finance Co.</option>' + (S.cs.financers || []).map((f) => '<option' + (o.fin === f ? ' selected' : '') + '>' + esc(f) + '</option>').join('') + '</select></div>';
  }
  const readFilter = () => ({ q: (U.$('#fq') || {}).value || '', from: (U.$('#ff') || {}).value || '', to: (U.$('#ft') || {}).value || '', type: (U.$('#fs') || {}).value || '', fin: (U.$('#ffin') || {}).value || '' });
  L.match = function (c, f) {
    if (f.q) { const q = f.q.toLowerCase(); if (![c.customerName, c.fatherName, c.mobile, c.altMobile, c.challanNo, c.chassisNo, c.engineNo, c.regNo, c.invoiceNo, c.loanAppNo, c.policyNo].some((x) => String(x || '').toLowerCase().includes(q))) return false; }
    if (!Ch.inRange(c.challanDate, f.from, f.to)) return false;
    if (f.type && c.saleType !== f.type) return false;
    if (f.fin && c.financer !== f.fin) return false;
    return true;
  };
  // page with filter + list; pick(list) -> {rows: [challans], right(c), sub(c), total}
  async function listPage(el, title, pick, extraTop) {
    const all = await Ch.challans();
    const st = S.params || {};
    el.innerHTML = '<h2 class="page-title">' + title + '</h2>' + (extraTop || '') + filterBar(st.f) + '<div id="lsum" class="sum-bar"></div><div id="lres"></div>';
    const draw = () => {
      const f = readFilter(); S.params = Object.assign({}, S.params, { f });
      const r = pick(all.filter((c) => L.match(c, f)), f);
      U.$('#lsum').innerHTML = r.summary || ('<b>' + r.rows.length + '</b> records');
      U.$('#lres').innerHTML = r.rows.length ? r.rows.slice(0, 300).map((c) => L.row(c, r.right && r.right(c), r.sub && r.sub(c))).join('') + (r.rows.length > 300 ? '<p class="muted center">Pehle 300 dikh rahe hain — search/filter lagayein</p>' : '') : U.empty();
      L.bind(U.$('#lres'));
    };
    U.$$('.filters input, .filters select').forEach((i) => { i.oninput = draw; i.onchange = draw; });
    draw();
  }

  V.list = (el) => listPage(el, '📋 All Challans', (rows) => ({
    rows, summary: '<b>' + rows.length + '</b> challan · Payable ' + U.money(rows.reduce((s, c) => s + n(c.payable), 0)) + ' · Due ' + U.money(rows.reduce((s, c) => s + Math.max(0, n(c.due)), 0))
  }), Ch.can('create') ? '<button class="btn" onclick="App.go(\'form\')">➕ New Challan</button>' : '');

  V.due = (el) => listPage(el, '⏰ Due Payment List', (rows) => {
    const r = rows.filter((c) => !c.cancelled && n(c.due) > 0.5).map((c) => Object.assign(c, { _d: Ch.daysBetween(c.challanDate) })).sort((a, b) => b._d - a._d);
    const buckets = {}; Ch.AGE_BUCKETS.forEach((b) => buckets[b] = 0); r.forEach((c) => buckets[Ch.ageBucket(c._d)] += n(c.due));
    return { rows: r, right: (c) => '<b class="low">' + U.money(c.due) + '</b><small class="d">' + c._d + ' din</small>',
      sub: (c) => (c.lastCallRemark ? '📞 ' + t(c.lastCallRemark) : '') + (c.nextFollow ? ' · Next: ' + U.fmtDate(c.nextFollow) : ''),
      summary: '<b>' + r.length + '</b> customers · Total due <b>' + U.money(r.reduce((s, c) => s + n(c.due), 0)) + '</b><div class="chips">' +
        Ch.AGE_BUCKETS.map((b) => '<span class="chip">' + b + ': ' + U.money(buckets[b]) + '</span>').join('') + '</div>' };
  });

  V.dpdue = (el) => listPage(el, '💵 Down Payment Due', (rows) => {
    const r = rows.filter((c) => !c.cancelled && n(c.dpDue) > 0.5).map((c) => Object.assign(c, { _d: Ch.daysBetween(c.challanDate) })).sort((a, b) => b._d - a._d);
    return { rows: r, right: (c) => '<b class="low">' + U.money(c.dpDue) + '</b><small class="d">' + c._d + ' din</small>',
      sub: (c) => 'Agreed DP ' + U.money(c.downPayment) + ' · Paid ' + U.money(c.sumPaid),
      summary: '<b>' + r.length + '</b> customers · DP due <b>' + U.money(r.reduce((s, c) => s + n(c.dpDue), 0)) + '</b>' };
  });

  V.findue = (el) => listPage(el, '🏦 Finance Disbursement Pending', (rows) => {
    const r = rows.filter((c) => !c.cancelled && c.saleType === 'Finance' && n(c.finDue) > 0.5).map((c) => Object.assign(c, { _d: Ch.daysBetween(c.challanDate) })).sort((a, b) => b._d - a._d);
    return { rows: r, right: (c) => '<b>' + U.money(c.finDue) + '</b><small class="d">' + c._d + ' din</small>', sub: (c) => Ch.loanBadge(c.loanStatus) + ' ' + t(c.loanAppNo),
      summary: '<b>' + r.length + '</b> files · Pending <b>' + U.money(r.reduce((s, c) => s + n(c.finDue), 0)) + '</b>' };
  });

  V.loans = async function (el) {
    const tab = (S.params && S.params.lt) || 'Pending';
    await listPage(el, '📂 Loan File Status', (rows) => {
      const fin = rows.filter((c) => !c.cancelled && c.saleType === 'Finance');
      const r = fin.filter((c) => (tab === 'All' ? true : (c.loanFileStatus || 'Pending') === tab));
      const cnt = (s) => fin.filter((c) => (c.loanFileStatus || 'Pending') === s).length;
      return { rows: r, right: (c) => Ch.loanBadge(c.loanStatus), sub: (c) => 'File: <b>' + t(c.loanFileStatus || 'Pending') + '</b> · ' + t(c.loanAppNo) + (c.fileRemark ? ' · ' + t(c.fileRemark) : ''),
        summary: 'Pending <b>' + cnt('Pending') + '</b> · Complete <b>' + cnt('Complete') + '</b> · ' + Ch.LOAN_STATUS.map((s) => s + ': ' + fin.filter((c) => (c.loanStatus || 'Pending') === s).length).join(' · ') };
    }, '<div class="tabs">' + ['Pending', 'Complete', 'All'].map((x) => '<button class="' + (x === tab ? 'on' : '') + '" onclick="App.go(\'loans\',{lt:\'' + x + '\'})">' + x + '</button>').join('') + '</div>');
  };

  V.claims = (el) => listPage(el, '🎁 Scheme / Company Claim Pending', (rows) => {
    const r = rows.filter((c) => !c.cancelled && c.hasScheme && (c.schemes || []).some((s) => s.claim && !s.claimReceived));
    const amt = (c) => (c.schemes || []).filter((s) => s.claim && !s.claimReceived).reduce((s, x) => s + n(x.amount), 0);
    return { rows: r, right: (c) => '<b>' + U.money(amt(c)) + '</b>', sub: (c) => (c.schemes || []).filter((s) => s.claim && !s.claimReceived).map((s) => t(s.name)).join(', '),
      summary: '<b>' + r.length + '</b> challans · Claim pending <b>' + U.money(r.reduce((s, c) => s + amt(c), 0)) + '</b> (Challan edit karke "Claim mila" tick karein)' };
  });

  // ===== Pendency =====
  L.pendencies = function (c, fileKinds) {
    const p = [];
    if (c.cancelled) return p;
    if (!c.invoiceNo) p.push('Invoice');
    if (!c.policyNo) p.push('Insurance');
    if ((c.rtoStatus || 'Pending') !== 'Done') p.push('RTO');
    if (c.plateShowroom !== 'Received') p.push('Plate @Showroom');
    if (c.plateGiven !== 'Given') p.push('Plate to Customer');
    if (c.rcGiven !== 'Given') p.push('RC to Customer');
    if (c.saleType === 'Finance' && (c.loanFileStatus || 'Pending') !== 'Complete') p.push('Loan File');
    if (c.saleType === 'Finance' && n(c.finDue) > 0.5) p.push('Disbursement');
    if (n(c.dpDue) > 0.5) p.push('Down Payment');
    if (n(c.due) > 0.5) p.push('Payment Due');
    if (c.isExchange && !c.exRegNo) p.push('Exchange Details');
    (c.hasScheme ? c.schemes || [] : []).forEach((s) => { if (s.claim && !s.claimReceived) p.push('Scheme Claim'); });
    if (fileKinds) ['Customer Photo', 'Delivery Photo', 'Aadhaar Card', 'Invoice', 'Insurance Policy'].forEach((k) => { if (S.cs.docTypes.includes(k) && !(fileKinds[c.id] || {})[k]) p.push('Doc: ' + k); });
    return Array.from(new Set(p));
  };
  V.pendency = async function (el) {
    const metas = await Ch.allFileMeta().catch(() => []);
    const fk = {}; metas.forEach((m) => { (fk[m.challanId] = fk[m.challanId] || {})[m.kind] = true; });
    const typ = (S.params && S.params.pt) || '';
    const allTypes = ['Invoice', 'Insurance', 'RTO', 'Plate @Showroom', 'Plate to Customer', 'RC to Customer', 'Loan File', 'Disbursement', 'Down Payment', 'Payment Due', 'Exchange Details', 'Scheme Claim', 'Doc: Customer Photo', 'Doc: Delivery Photo', 'Doc: Aadhaar Card', 'Doc: Invoice', 'Doc: Insurance Policy'];
    await listPage(el, '📌 Pendency List', (rows) => {
      const withP = rows.map((c) => Object.assign(c, { _p: L.pendencies(c, fk) })).filter((c) => c._p.length && (!typ || c._p.includes(typ)));
      const cnt = {}; rows.forEach((c) => (c._p || L.pendencies(c, fk)).forEach((x) => cnt[x] = (cnt[x] || 0) + 1));
      return { rows: withP, right: (c) => '<b>' + c._p.length + '</b><small class="d">pending</small>', sub: (c) => c._p.map((x) => '<span class="pill">' + esc(x) + '</span>').join(' '),
        summary: '<div class="chips">' + '<span class="chip' + (!typ ? ' on' : '') + '" onclick="App.go(\'pendency\')">Sab</span>' +
          allTypes.filter((x) => cnt[x]).map((x) => '<span class="chip' + (typ === x ? ' on' : '') + '" onclick="App.go(\'pendency\',{pt:\'' + esc(x) + '\'})">' + esc(x) + ' (' + cnt[x] + ')</span>').join('') + '</div>' };
    });
  };

  // ===== Customer search / customer-wise ledger =====
  V.customers = async function (el) {
    const all = await Ch.challans();
    el.innerHTML = '<h2 class="page-title">👤 Customer Ledger / Search</h2><input class="search" id="cq" placeholder="🔍 Naam / mobile / chassis / challan / reg no / loan no" autofocus><div id="cres"></div>';
    const draw = () => {
      const q = U.$('#cq').value.trim().toLowerCase();
      const rows = q ? all.filter((c) => L.match(c, { q })) : all.slice(0, 30);
      const g = {}; rows.forEach((c) => { const k = c.mobile || c.customerName; (g[k] = g[k] || []).push(c); });
      U.$('#cres').innerHTML = Object.keys(g).length ? Object.keys(g).map((k) => {
        const cs = g[k], due = cs.reduce((s, c) => s + Math.max(0, n(c.due)), 0);
        return '<div class="card"><div class="row-between"><div><b>' + t(cs[0].customerName) + '</b> <small class="muted">S/o ' + t(cs[0].fatherName) + ' · ' + t(cs[0].mobile) + '</small></div><b class="' + (due > 0.5 ? 'low' : 'good') + '">Due ' + U.money(due) + '</b></div>' +
          cs.map((c) => '<div class="li" data-cid="' + c.id + '"><div class="grow"><b>' + t(c.challanNo) + '</b><small>' + U.fmtDate(c.challanDate) + ' · ' + t(c.model) + ' · ' + t(c.chassisNo) + '</small></div><span>›</span></div>').join('') + '</div>';
      }).join('') : U.empty();
      L.bind(U.$('#cres'));
    };
    U.$('#cq').oninput = draw; draw();
  };

  // ===== Calling =====
  V.calling = async function (el) {
    const [all, reqs] = await Promise.all([Ch.challans(), DB.query('ccallreq', [['status', '==', 'open']].concat(Ch.ownWhere())).catch(() => [])]);
    const today = U.dateKey();
    const tab = (S.params && S.params.ct) || 'today';
    const due = all.filter((c) => !c.cancelled && n(c.due) > 0.5);
    const sets = {
      today: due.filter((c) => !c.nextFollow || c.nextFollow <= today),
      promise: due.filter((c) => c.promiseDate && c.promiseDate < today),
      never: due.filter((c) => !c.lastCallDate),
      all: due
    };
    const r = (sets[tab] || due).map((c) => Object.assign(c, { _d: Ch.daysBetween(c.challanDate) })).sort((a, b) => String(a.nextFollow || '').localeCompare(String(b.nextFollow || '')) || b._d - a._d);
    el.innerHTML = '<h2 class="page-title">📞 Due Payment Calling</h2>' +
      (reqs.length ? '<div class="card warn-card"><h3>☎️ Customer callback requests (' + reqs.length + ')</h3>' + reqs.map((q) => '<div class="li"><div class="grow"><b>' + t(q.customerName) + '</b> <a href="tel:' + t(q.mobile) + '">' + t(q.mobile) + '</a><small>' +
        t(q.challanNo) + ' · ' + U.fmtDT(q.at) + '</small><p>' + t(q.note) + '</p></div><button class="btn sm" data-rq="' + q.id + '">Done</button></div>').join('') + '</div>' : '') +
      '<div class="tabs">' + [['today', 'Aaj call karne (' + sets.today.length + ')'], ['promise', 'Promise toota (' + sets.promise.length + ')'], ['never', 'Kabhi call nahi (' + sets.never.length + ')'], ['all', 'Sab due (' + due.length + ')']]
        .map((x) => '<button class="' + (x[0] === tab ? 'on' : '') + '" onclick="App.go(\'calling\',{ct:\'' + x[0] + '\'})">' + x[1] + '</button>').join('') + '</div>' +
      (r.length ? r.map((c) => '<div class="card call-card"><div class="row-between"><div class="grow" data-cid="' + c.id + '"><b>' + t(c.customerName) + '</b> <small class="muted">' + t(c.challanNo) + ' · ' + t(c.model) + '</small><br><small>' +
        (c.lastCallRemark ? '📝 ' + t(c.lastCallRemark) + ' (' + U.fmtDate(c.lastCallDate) + ')' : 'Abhi tak call nahi') + (c.nextFollow ? ' · Next: <b>' + U.fmtDate(c.nextFollow) + '</b>' : '') + (c.promiseDate ? ' · Promise: ' + U.fmtDate(c.promiseDate) : '') + '</small></div>' +
        '<div class="right"><b class="low">' + U.money(c.due) + '</b><small class="d">' + c._d + ' din</small></div></div><div class="act-row"><a class="btn sm" href="tel:' + t(c.mobile) + '">📞 ' + t(c.mobile) + '</a>' +
        '<button class="btn ghost sm" data-call="' + c.id + '">📝 Remark</button><button class="btn ghost sm" data-wa="' + c.id + '">💬 WhatsApp</button></div></div>').join('') : U.empty('Is list me koi customer nahi'));
    L.bind(el);
    U.$$('[data-call]').forEach((b) => b.onclick = () => Calls.dialog(r.find((c) => c.id === b.dataset.call), () => App.refresh()));
    U.$$('[data-wa]').forEach((b) => b.onclick = () => { const c = r.find((x) => x.id === b.dataset.wa); Cust.whatsapp(c, Ch.calc(c), 'due'); });
    U.$$('[data-rq]').forEach((b) => b.onclick = async () => { await DB.update('ccallreq', b.dataset.rq, { status: 'done', doneBy: Ch.me().name, doneAt: DB.now() }); App.refresh(); });
  };
})();
