// ---------- Challan entry / edit form ----------
(function () {
  const V = window.Views, esc = U.esc, n = U.num;
  const Form = window.ChForm = {};
  let pending = []; // files picked before save: {kind, name, mime, data, thumb}

  const dl = (id, list) => '<datalist id="' + id + '">' + (list || []).map((x) => '<option value="' + esc(x) + '">').join('') + '</datalist>';
  const req = (k) => !!(S.cs.required || {})[k];
  function F(name, label, v, o) {
    o = Object.assign({}, o || {}); if (req(name)) o.required = true;
    let h = U.field(name, label, v, o);
    if (o.list) h = h.replace('<input name="' + name + '"', '<input list="' + o.list + '" name="' + name + '"');
    if (o.required) h = h.replace(/ required(?=[ >])/, ''); // we validate ourselves (sections may be hidden)
    if (o.add) h = h.replace('</label>', '<button type="button" class="add-mst" data-mst="' + o.add + '" data-for="' + name + '" title="Naya jodein">＋</button></label>');
    return h;
  }
  const sec = (id, title, body, open, extra) => '<details class="card sec" id="' + id + '"' + (open ? ' open' : '') + '><summary><b>' + title + '</b>' + (extra || '') + '</summary><div class="sec-body">' + body + '</div></details>';
  const ocrBox = (type, label) => '<div class="ocr-box"><button type="button" class="btn sm" data-ocr="' + type + '">📤 ' + label + ' PDF/Photo upload → Auto-fill + Match</button><small class="muted" id="ocr-' + type + '"></small></div>';
  Form.HANDOVER_KEYS = ['plateShowroom', 'plateRecvDate', 'plateGiven', 'plateGivenDate', 'rcGiven', 'rcGivenDate', 'insGiven', 'insGivenDate'];

  // due-payment guard before handing over RC / plate / insurance
  Form.handoverGuard = async function (c, before, after) {
    const items = [['plateGiven', 'Number Plate'], ['rcGiven', 'RC'], ['insGiven', 'Insurance']].filter(([k]) => after[k] === 'Given' && before[k] !== 'Given').map((x) => x[1]);
    if (!items.length) return true;
    const due = n(c.due);
    if (due <= 0.5) return true;
    const msg = '⚠️ Is customer ka ' + U.money(due) + ' PAYMENT DUE hai. Payment clear hone par hi ' + items.join(', ') + ' dena hai.';
    if (!Ch.can('handoverDue')) { U.toast(msg + ' (Due hote hue dene ka right nahi hai)', 'err'); return false; }
    return U.confirm(msg + '\n\nFir bhi "Given" mark karein?', 'Haan, de diya');
  };

  V.form = async function (el, p) {
    if (p.id ? !Ch.can('edit') : !Ch.can('create')) { el.innerHTML = U.empty('Aapko ye right nahi hai'); return; }
    const c = p.id ? await DB.get('challans', p.id) : { challanDate: U.dateKey(), saleType: 'Cash', executive: Ch.me().name, loanStatus: 'Pending', loanFileStatus: 'Pending', rtoStatus: 'Pending',
      plateShowroom: 'Not Received', plateGiven: 'Not Given', rcGiven: 'Not Given', insGiven: 'Not Given', price: {}, cost: {}, schemes: [] };
    if (!c) { el.innerHTML = U.empty('Challan nahi mila'); return; }
    const oldFiles = p.id ? await Ch.files(p.id).catch(() => []) : [];
    pending = [];
    const cs = S.cs, inc = Ch.can('viewIncome'), ho = Ch.can('handover');
    const pr = c.price || {}, co = c.cost || {};
    const priceRows = Ch.priceItems().map((it) => '<tr><td>' + esc(it.l) + '</td><td><input type="number" step="0.01" name="price.' + it.k + '" value="' + esc(pr[it.k] == null ? '' : pr[it.k]) + '"></td>' +
      (inc ? '<td><input type="number" step="0.01" name="cost.' + it.k + '" value="' + esc(co[it.k] == null ? '' : co[it.k]) + '" placeholder="cost"></td>' : '') + '</tr>').join('');
    const reqDocs = (cs.requiredDocs || []);
    const photoBtn = (kind, icon) => '<button type="button" class="btn ghost sm" data-photo="' + esc(kind) + '">' + icon + ' ' + esc(kind) + (reqDocs.includes(kind) ? ' *' : '') + '</button><span id="pv-' + kind.replace(/\W+/g, '-') + '" class="pv">' +
      (kind === 'Customer Photo' && c.photoThumb ? '<img src="' + esc(c.photoThumb) + '">' : oldFiles.some((x) => x.kind === kind) ? '✅' : '') + '</span>';
    const sel = (name, label, v, opts, extra) => F(name, label, v, Object.assign({ type: 'select', options: opts, readonly: !ho }, extra || {}));

    el.innerHTML = '<div class="row-between"><h2 class="page-title">' + (p.id ? 'Edit Challan ' + esc(c.challanNo) : 'New Delivery Challan') + '</h2>' +
      (p.id ? '<button class="btn ghost sm" onclick="App.go(\'view\',{id:\'' + esc(p.id) + '\'})">← Back</button>' : '') + '</div>' +
      '<form id="chf" class="form" novalidate>' +
      sec('s-ch', '🧾 Challan', '<div class="grid2">' +
        F('challanNo', 'Challan No', c.challanNo || '', { placeholder: 'Auto (' + esc(cs.prefix) + '....)', readonly: !!p.id && !S.isAdmin }) +
        F('challanDate', 'Challan / Sale Date', c.challanDate, { type: 'date', min: p.id ? '' : Ch.minDate(), max: U.dateKey() }) +
        F('saleType', 'Cash / Finance', c.saleType, { type: 'select', options: ['Cash', 'Finance'] }) +
        F('executive', 'Sales Executive', c.executive || '') +
        F('paymentDueDate', 'Payment Due Date (DPD ke liye)', c.paymentDueDate || '', { type: 'date' }) + '</div>' +
        '<div class="row wrap">' + photoBtn('Manual Challan Photo', '📝') + '</div>' +
        (p.id ? U.field('cancelled', 'Challan Cancelled', !!c.cancelled, { type: 'checkbox' }) : ''), true) +
      (Ch.can('stock') ? sec('s-st', '📦 Stock se gaadi chunein (auto-fill)', '<input class="search" id="stockQ" placeholder="🔍 Chassis / Engine / Model ke aakhri ank likhein" autocomplete="off"><div id="stockRes" class="stock-res"></div>', !p.id) : '') +
      sec('s-cu', '👤 Customer', '<div class="grid2">' +
        F('customerName', 'Customer Name', c.customerName) + F('fatherName', 'Father Name', c.fatherName) +
        F('mobile', 'Mobile No', c.mobile, { type: 'tel' }) + F('altMobile', 'Alternate Mobile', c.altMobile, { type: 'tel' }) +
        F('city', 'City / Village', c.city, { list: 'dl-vil', add: Ch.can('masters') ? 'villages' : '' }) + F('dob', 'Date of Birth', c.dob, { type: 'date' }) +
        F('aadhaar', 'Aadhaar No', c.aadhaar) + F('pan', 'PAN', c.pan) + '</div>' +
        F('address', 'Address', c.address, { type: 'textarea', rows: 2 }) +
        '<div class="row wrap">' + photoBtn('Customer Photo', '📷') + '</div>', true) +
      sec('s-ve', '🏍️ Vehicle', '<div class="grid2">' +
        F('model', 'Model', c.model, { list: 'dl-model', add: Ch.can('masters') ? 'models' : '' }) + F('variant', 'Variant', c.variant) + F('colour', 'Colour', c.colour, { list: 'dl-colour', add: Ch.can('masters') ? 'colours' : '' }) +
        F('engineNo', 'Engine No', c.engineNo) + F('chassisNo', 'Chassis No', c.chassisNo) + F('keyNo', 'Key No', c.keyNo) + F('batteryNo', 'Battery No', c.batteryNo) +
        F('deliveryDate', 'Delivery Date', c.deliveryDate || c.challanDate, { type: 'date' }) + '</div>' +
        '<div class="row wrap">' + photoBtn('Delivery Photo', '📸') + '<button type="button" class="btn ghost sm" id="addDoc">📎 Aur document</button><span id="pv-more" class="pv small"></span></div>', true) +
      sec('s-in', '📄 Invoice / Billing', ocrBox('invoice', 'Invoice') + '<div class="grid2">' +
        F('invoiceNo', 'Invoice No', c.invoiceNo) + F('invoiceDate', 'Invoice / Billing Date', c.invoiceDate, { type: 'date' }) +
        F('invoiceAmount', 'Invoice Amount', c.invoiceAmount, { type: 'number', step: '0.01' }) + F('invFinancer', 'Invoice par Finance / HP', c.invFinancer) + '</div>', !!p.id) +
      sec('s-pr', '💰 On-Road Price', '<p class="muted small">Model chunte hi Model Price master se rate aa jayenge — yahan haath se badal sakte hain.</p>' +
        '<div class="table-wrap"><table class="tbl price-tbl"><thead><tr><th>Item</th><th>Charged</th>' + (inc ? '<th>Actual Cost</th>' : '') + '</tr></thead><tbody>' + priceRows + '</tbody></table></div>' +
        '<div class="grid2">' + F('onRoadManual', 'On-Road Total (manual) — breakup ki jagah seedha total', c.onRoadManual, { type: 'number', step: '0.01' }) +
        F('discount', 'Discount (customer)', c.discount, { type: 'number', step: '0.01' }) +
        F('downPayment', 'Down Payment (agreed)', c.downPayment, { type: 'number', step: '0.01' }) +
        (inc ? F('dealerMargin', 'Vehicle Margin (dealer)', c.dealerMargin, { type: 'number', step: '0.01' }) + F('otherIncome', 'Other Income (payout etc.)', c.otherIncome, { type: 'number', step: '0.01' }) +
          F('incomeManual', 'Income (manual — khali chhodein to auto)', c.incomeManual, { type: 'number', step: '0.01' }) : '') + '</div>' +
        '<div id="liveTot" class="tot-box"></div>', true) +
      sec('s-fi', '🏦 Finance', '<div class="grid2">' +
        F('financer', 'Finance Company', c.financer, { list: 'dl-fin', add: Ch.can('masters') ? 'financers' : '' }) + F('loanAppNo', 'Loan Application No', c.loanAppNo) +
        F('loanAmount', 'Loan Amount', c.loanAmount, { type: 'number', step: '0.01' }) + F('disburseExpected', 'Net Disbursal Expected', c.disburseExpected, { type: 'number', step: '0.01' }) +
        F('tenure', 'Tenure (months)', c.tenure, { type: 'number' }) + F('emi', 'EMI', c.emi, { type: 'number', step: '0.01' }) +
        F('roi', 'ROI %', c.roi, { type: 'number', step: '0.01' }) + F('emiStart', 'EMI Start Date', c.emiStart, { type: 'date' }) +
        F('advanceEmi', 'Advance EMI (count)', c.advanceEmi, { type: 'number' }) + F('loanStatus', 'Loan Status', c.loanStatus, { type: 'select', options: Ch.LOAN_STATUS }) +
        F('loanFileStatus', 'Loan File', c.loanFileStatus || 'Pending', { type: 'select', options: ['Pending', 'Complete'] }) + F('doNo', 'DO No', c.doNo) + '</div>' +
        F('fileRemark', 'Loan File Remark (kya pending hai)', c.fileRemark, { type: 'textarea', rows: 2 }), c.saleType === 'Finance') +
      sec('s-ex', '🔁 Exchange', '<div id="exBody" class="grid2">' + F('exOldModel', 'Old Vehicle / Model', c.exOldModel) + F('exRegNo', 'Old Reg No', c.exRegNo) +
        F('exYear', 'Model Year', c.exYear) + F('exOwner', 'Owner Name', c.exOwner) + F('exValue', 'Exchange Value (adjusted)', c.exValue, { type: 'number', step: '0.01' }) +
        F('exRemark', 'Remark', c.exRemark) + '</div>', !!c.isExchange, '<label class="chk inline" onclick="event.stopPropagation()"><input type="checkbox" name="isExchange"' + (c.isExchange ? ' checked' : '') + '> Exchange hai</label>') +
      sec('s-sc', '🎁 Scheme / Campaign / Cash Bonus', '<div id="schemes"></div><button type="button" class="btn ghost sm" id="addSch">+ Scheme row</button>' +
        '<p class="muted small">Customer ko diya = price me se kam hoga. Company claim = company se milna hai (claim pending report me aayega).</p>', !!c.hasScheme,
        '<label class="chk inline" onclick="event.stopPropagation()"><input type="checkbox" name="hasScheme"' + (c.hasScheme ? ' checked' : '') + '> Scheme hai</label>') +
      sec('s-ins', '🛡️ Insurance', ocrBox('insurance', 'Insurance') + '<div class="grid2">' +
        F('insCompany', 'Insurance Company', c.insCompany, { list: 'dl-ins', add: Ch.can('masters') ? 'insurers' : '' }) + F('policyNo', 'Policy No', c.policyNo) +
        F('insType', 'Policy Type', c.insType || '', { type: 'select', options: ['', 'Comprehensive (1 OD + 5 TP)', 'Comprehensive (1 yr)', 'Third Party only', 'Other'] }) +
        F('insFrom', 'Policy From', c.insFrom, { type: 'date' }) + F('insTo', 'Policy To', c.insTo, { type: 'date' }) +
        F('odFrom', 'OD Cover From', c.odFrom, { type: 'date' }) + F('odTo', 'OD Cover Expiry (renewal)', c.odTo, { type: 'date' }) +
        F('tpFrom', 'Third Party From', c.tpFrom, { type: 'date' }) + F('tpTo', 'Third Party Expiry', c.tpTo, { type: 'date' }) +
        F('insPremium', 'Premium (policy)', c.insPremium, { type: 'number', step: '0.01' }) + F('idv', 'IDV', c.idv, { type: 'number', step: '0.01' }) +
        F('insFinancer', 'Policy par Finance / HP', c.insFinancer) + '</div>', !!p.id) +
      sec('s-rto', '🪪 RTO / RC', ocrBox('rc', 'RC') + '<div class="grid2">' + F('regNo', 'Registration No', c.regNo) + F('regDate', 'Registration Date', c.regDate, { type: 'date' }) +
        F('rtoStatus', 'RTO Status', c.rtoStatus || 'Pending', { type: 'select', options: ['Pending', 'Applied', 'Done'] }) + F('rtoDate', 'RTO Applied Date', c.rtoDate, { type: 'date' }) +
        F('rcOwner', 'RC par Owner', c.rcOwner) + F('rcFinancer', 'RC par Finance / HP', c.rcFinancer) + F('regValidTo', 'Registration Valid Upto', c.regValidTo, { type: 'date' }) + '</div>' +
        '<div id="finMatch" class="matches"></div>', !!p.id) +
      sec('s-ho', '🔑 Number Plate / RC / Insurance — Showroom & Customer', (ho ? '' : '<p class="muted small">Ye update karne ka right nahi hai.</p>') + '<div class="grid2">' +
        sel('plateShowroom', 'Number Plate Showroom par', c.plateShowroom || 'Not Received', Ch.PLATE_SHOWROOM) + F('plateRecvDate', 'Plate Showroom aayi (date)', c.plateRecvDate, { type: 'date', readonly: !ho }) +
        sel('plateGiven', 'Number Plate Customer ko', c.plateGiven || 'Not Given', Ch.GIVEN) + F('plateGivenDate', 'Plate di (date)', c.plateGivenDate, { type: 'date', readonly: !ho }) +
        sel('rcGiven', 'RC Customer ko', c.rcGiven || 'Not Given', Ch.GIVEN) + F('rcGivenDate', 'RC di (date)', c.rcGivenDate, { type: 'date', readonly: !ho }) +
        sel('insGiven', 'Insurance Customer ko', c.insGiven || 'Not Given', Ch.GIVEN) + F('insGivenDate', 'Insurance di (date)', c.insGivenDate, { type: 'date', readonly: !ho }) + '</div>' +
        '<p class="muted small">⚠️ Payment due ho to "Given" karte waqt warning aayegi.</p>', !!p.id) +
      '<div id="diffBox" class="tot-box diff"></div>' +
      (!p.id && Ch.can('payment') ? sec('s-pay', '💵 Payment received abhi (optional)', '<div class="grid2">' +
        U.field('payAmount', 'Amount', '', { type: 'number', step: '0.01' }) + U.field('payMode', 'Mode', 'Cash', { type: 'select', options: Ch.PAY_MODES.filter((x) => x !== 'Finance') }) +
        U.field('payRef', 'Ref / UTR / Cheque No', '') + U.field('payKind', 'Type', 'Down Payment', { type: 'select', options: ['Down Payment', 'Booking Amount', 'Payment'] }) +
        U.field('payDate', 'Payment Received Date', U.dateKey(), { type: 'date', min: Ch.minDate(), max: U.dateKey() }) + '</div>', true) : '') +
      sec('s-rm', '📝 Remarks', F('remark', 'Remark', c.remark, { type: 'textarea', rows: 2 }), !!c.remark) +
      '<div class="sticky-save"><button class="btn block" type="submit">💾 Save Challan</button></div></form>' +
      dl('dl-model', Ch.list('models')) + dl('dl-colour', Ch.list('colours')) + dl('dl-fin', Ch.list('financers')) + dl('dl-ins', Ch.list('insurers')) +
      dl('dl-sch', cs.schemes) + dl('dl-vil', Ch.list('villages'));

    const f = U.$('#chf');
    if (cs.upperCase) f.classList.add('upper');
    // schemes repeater
    const schBox = U.$('#schemes');
    const addSch = (s) => {
      s = s || {};
      const d = document.createElement('div'); d.className = 'sch-row';
      d.innerHTML = '<input list="dl-sch" class="s-name" placeholder="Scheme name" value="' + esc(s.name || '') + '"><input type="number" step="0.01" class="s-amt" placeholder="Amount" value="' + esc(s.amount || '') + '">' +
        '<label class="chk"><input type="checkbox" class="s-cust"' + (s.toCustomer !== false ? ' checked' : '') + '> Customer ko diya</label>' +
        '<label class="chk"><input type="checkbox" class="s-claim"' + (s.claim ? ' checked' : '') + '> Company claim</label>' +
        '<label class="chk"><input type="checkbox" class="s-rec"' + (s.claimReceived ? ' checked' : '') + '> Claim mila</label><button type="button" class="icon-btn" title="Remove">✕</button>';
      d.querySelector('button').onclick = () => { d.remove(); live(); };
      U.$$('input', d).forEach((i) => i.oninput = live);
      schBox.appendChild(d);
    };
    (c.schemes && c.schemes.length ? c.schemes : [{}]).forEach(addSch);
    U.$('#addSch').onclick = () => addSch();

    const readSchemes = () => U.$$('.sch-row', schBox).map((r) => ({ name: U.$('.s-name', r).value.trim(), amount: n(U.$('.s-amt', r).value),
      toCustomer: U.$('.s-cust', r).checked, claim: U.$('.s-claim', r).checked, claimReceived: U.$('.s-rec', r).checked })).filter((s) => s.name || s.amount);

    const isText = (el) => el && ((el.tagName === 'INPUT' && /^(text|tel|search|)$/.test(el.type || '')) || el.tagName === 'TEXTAREA');
    function collect() {
      const d = U.formData(f); const o = { price: {}, cost: {} };
      Object.keys(d).forEach((k) => {
        if (/^(pay[A-Z])/.test(k)) return;
        if (k.startsWith('price.')) { if (d[k] !== '') o.price[k.slice(6)] = n(d[k]); return; }
        if (k.startsWith('cost.')) { if (d[k] !== '') o.cost[k.slice(5)] = n(d[k]); return; }
        let v = d[k];
        if (cs.upperCase && typeof v === 'string' && isText(f.querySelector('[name="' + k + '"]'))) v = v.toUpperCase();
        o[k] = v;
      });
      if (!inc) { o.cost = c.cost || {}; ['dealerMargin', 'otherIncome', 'incomeManual'].forEach((k) => { if (c[k] !== undefined) o[k] = c[k]; }); }
      if (!ho) Form.HANDOVER_KEYS.forEach((k) => { if (c[k] !== undefined) o[k] = c[k]; else delete o[k]; });
      o.schemes = readSchemes();
      if (cs.upperCase) o.schemes.forEach((s) => s.name = s.name.toUpperCase());
      o.mobile = String(o.mobile || '').replace(/\D/g, '').slice(-10);
      ['chassisNo', 'engineNo', 'regNo', 'pan', 'exRegNo'].forEach((k) => { if (o[k]) o[k] = String(o[k]).toUpperCase().replace(/\s+/g, ''); });
      return o;
    }
    const finMatchHtml = (o) => {
      const src = [['Challan', o.financer], ['Invoice', o.invFinancer], ['Insurance', o.insFinancer], ['RC', o.rcFinancer]].filter((x) => x[1]);
      if (src.length < 2) return src.length ? '<span class="match">🏦 Finance: ' + esc(src[0][1]) + ' (' + src[0][0] + ')</span>' : '';
      const base = String(src[0][1]).toUpperCase().replace(/[^A-Z]/g, '').slice(0, 5);
      return src.map(([w, v]) => { const ok = String(v).toUpperCase().replace(/[^A-Z]/g, '').slice(0, 5) === base; return '<span class="match ' + (ok ? 'ok' : 'bad') + '">' + (ok ? '✅' : '❌') + ' ' + w + ': ' + esc(v) + '</span>'; }).join(' ');
    };
    function live() {
      const o = collect(); const k = Ch.calc(Object.assign({}, c, o));
      U.$('#liveTot').innerHTML = '<div><span>On-Road Total' + (n(o.onRoadManual) > 0 ? ' (manual)' : '') + '</span><b>' + U.money(k.gross) + '</b></div><div><span>Customer Payable</span><b>' + U.money(k.payable) + '</b></div>' +
        (o.saleType === 'Finance' ? '<div><span>Finance</span><b>' + U.money(k.finAmt) + '</b></div>' : '') + (o.isExchange ? '<div><span>Exchange</span><b>' + U.money(k.exValue) + '</b></div>' : '') +
        '<div><span>Down Payment banta</span><b>' + U.money(k.dpExpected) + '</b></div>' + (inc ? '<div><span>Income</span><b>' + U.money(k.income) + '</b></div>' : '') +
        (n(o.onRoadManual) > 0 && Ch.itemsTotal(o) && Math.abs(Ch.itemsTotal(o) - n(o.onRoadManual)) > 0.5 ? '<div><span>Breakup total</span><b class="low">' + U.money(Ch.itemsTotal(o)) + '</b></div>' : '');
      U.$('#s-fi').style.display = o.saleType === 'Finance' ? '' : 'none';
      const df = Ch.diffs(o);
      U.$('#diffBox').innerHTML = '<div><span>Delivery → Invoice</span><b>' + Ch.diffTxt(df.inv) + '</b></div><div><span>Delivery → Insurance</span><b>' + Ch.diffTxt(df.ins) +
        '</b></div><div><span>Delivery → Registration</span><b>' + Ch.diffTxt(df.reg) + '</b></div>';
      U.$('#finMatch').innerHTML = finMatchHtml(o);
    }
    f.addEventListener('input', live); f.addEventListener('change', live); live();
    U.$('[name=isExchange]').onchange = (e) => { U.$('#s-ex').open = e.target.checked; live(); };
    U.$('[name=hasScheme]').onchange = (e) => { U.$('#s-sc').open = e.target.checked; live(); };
    const setV = (k, v, force) => { const i = f.querySelector('[name="' + k + '"]'); if (i && v !== '' && v != null && (force || !i.value)) { i.value = cs.upperCase && isText(i) ? String(v).toUpperCase() : v; i.classList.add('ocr-filled'); } };

    // status -> auto date
    [['plateShowroom', 'Received', 'plateRecvDate'], ['plateGiven', 'Given', 'plateGivenDate'], ['rcGiven', 'Given', 'rcGivenDate'], ['insGiven', 'Given', 'insGivenDate']].forEach(([s, val, dk]) => {
      const e = f.querySelector('[name=' + s + ']'); if (!e) return;
      e.addEventListener('change', () => { const di = f.querySelector('[name=' + dk + ']'); if (e.value === val && !di.value) di.value = U.dateKey(); if (e.value !== val) di.value = ''; });
    });

    // model -> price master autofill (only empty cells)
    const mdl = f.querySelector('[name=model]');
    mdl.addEventListener('change', () => {
      const mp = Ch.modelPrice(mdl.value); if (!mp) return;
      let filled = 0; Ch.priceItems().forEach((it) => { if (mp[it.k] != null && mp[it.k] !== '') { const i = f.querySelector('[name="price.' + it.k + '"]'); if (i && !i.value) { i.value = mp[it.k]; i.classList.add('ocr-filled'); filled++; } } });
      if (filled) { U.toast(filled + ' price Model master se bhare', 'ok'); U.$('#s-pr').open = true; live(); }
    });

    // quick add masters
    U.$$('[data-mst]').forEach((b) => b.onclick = async () => {
      const kind = b.dataset.mst, inp = f.querySelector('[name=' + b.dataset.for + ']');
      const lbl = { models: 'Model', villages: 'Village / City', financers: 'Finance Company', colours: 'Colour', insurers: 'Insurance Company' }[kind];
      const v = await U.prompt('Naya ' + lbl + ' jodein', lbl + ' ka naam', inp.value || ''); if (!v) return;
      try { if (await Ch.addMaster(kind, v)) { U.toast(lbl + ' jud gaya', 'ok'); const L = U.$('#dl-' + { models: 'model', villages: 'vil', financers: 'fin', colours: 'colour', insurers: 'ins' }[kind]); L.insertAdjacentHTML('beforeend', '<option value="' + esc(cs.upperCase ? v.toUpperCase() : v) + '">'); } else U.toast('Pehle se list me hai', 'info'); inp.value = cs.upperCase ? v.toUpperCase() : v; inp.dispatchEvent(new Event('change')); }
      catch (e) { U.toast(e.message, 'err'); }
    });

    // stock search
    const sq = U.$('#stockQ');
    if (sq) {
      let stock = null, picked = c.stockId || '';
      const draw = async () => {
        if (!stock) { try { stock = await Ch.stockInHand(); } catch (e) { U.$('#stockRes').innerHTML = '<small class="muted">Stock nahi khula: ' + esc(e.message) + '</small>'; return; } }
        const q = sq.value.trim().toUpperCase();
        const r = (q ? stock.filter((s) => [s.chassisNo, s.engineNo, s.model, s.colour].some((x) => String(x || '').toUpperCase().includes(q))) : stock).slice(0, 12);
        U.$('#stockRes').innerHTML = (stock.length ? '<small class="muted">' + stock.length + ' gaadi stock me</small>' : '<small class="muted">Stock khali hai — Menu → Stock me gaadi jodein</small>') +
          r.map((s) => '<div class="li stock-li" data-sid="' + esc(s.id) + '"><div class="grow"><b>' + esc(s.model || '') + ' ' + esc(s.colour || '') + '</b><small>Chassis ' + esc(s.chassisNo) + ' · Engine ' + esc(s.engineNo || '') +
            (s.receivedDate ? ' · aayi ' + U.fmtDate(s.receivedDate) : '') + '</small></div><button type="button" class="btn sm">Chunein</button></div>').join('');
        U.$$('[data-sid]').forEach((x) => x.onclick = () => {
          const s = stock.find((y) => y.id === x.dataset.sid);
          ['model', 'variant', 'colour', 'engineNo', 'chassisNo', 'keyNo', 'batteryNo'].forEach((k) => setV(k, s[k], true));
          picked = s.id; U.$('#stockRes').innerHTML = '<span class="match ok">✅ Stock se chuna: ' + esc(s.chassisNo) + '</span>';
          mdl.dispatchEvent(new Event('change')); U.$('#s-ve').open = true; live();
        });
      };
      sq.addEventListener('focus', draw); sq.addEventListener('input', draw);
      Form.pickedStock = () => picked;
    } else Form.pickedStock = () => c.stockId || '';

    // photos (customer / delivery / manual challan)
    U.$$('[data-photo]').forEach((b) => b.onclick = async () => {
      if (!Ch.can('upload')) return U.toast('Upload right nahi hai', 'err');
      const file = await U.pickFile('image/*'); if (!file) return;
      const data = await U.compressImage(file, 1400, 0.75); const thumb = await U.compressImage(file, 160, 0.6);
      const kind = b.dataset.photo;
      pending = pending.filter((x) => x.kind !== kind).concat([{ kind, name: kind + '.jpg', mime: 'image/jpeg', data, thumb }]);
      U.$('#pv-' + kind.replace(/\W+/g, '-')).innerHTML = '<img src="' + thumb + '">';
    });
    U.$('#addDoc').onclick = async () => {
      if (!Ch.can('upload')) return U.toast('Upload right nahi hai', 'err');
      const def = reqDocs.find((k) => !pending.some((x) => x.kind === k) && !oldFiles.some((x) => x.kind === k)) || cs.docTypes[0];
      const kind = await new Promise((res) => {
        const m = U.modal('Document type', U.field('dk', 'Kaun sa document?', def, { type: 'select', options: cs.docTypes }) + '<button class="btn block" data-ok>File chunein</button>', { onClose: () => res(null) });
        m.el.querySelector('[data-ok]').onclick = () => { const v = m.el.querySelector('[name=dk]').value; m.el.remove(); res(v); };
      });
      if (!kind) return;
      const file = await U.pickFile('application/pdf,image/*'); if (!file) return;
      if (file.size > Files.MAX) return U.toast('File 8 MB se badi hai', 'err');
      const isImg = /^image\//.test(file.type);
      pending.push({ kind, name: file.name, mime: isImg ? 'image/jpeg' : (file.type || 'application/octet-stream'), data: isImg ? await U.compressImage(file, 1600, 0.8) : await U.fileToDataURL(file) });
      U.$('#pv-more').textContent = pending.filter((x) => !['Customer Photo', 'Delivery Photo', 'Manual Challan Photo', 'Invoice', 'Insurance Policy', 'RC / Form 20'].includes(x.kind)).map((x) => '✅ ' + x.kind).join('  ');
    };

    // OCR upload: invoice / insurance / RC  (+ match with what is already on the challan)
    U.$$('[data-ocr]').forEach((b) => b.onclick = async () => {
      const type = b.dataset.ocr, st = U.$('#ocr-' + type);
      const file = await U.pickFile('application/pdf,image/*'); if (!file) return;
      if (file.size > Files.MAX) return U.toast('File 8 MB se badi hai', 'err');
      try {
        const isPdf = /pdf/i.test(file.type) || /\.pdf$/i.test(file.name);
        const data = isPdf ? await U.fileToDataURL(file) : await U.compressImage(file, 2000, 0.85);
        const kind = { invoice: 'Invoice', insurance: 'Insurance Policy', rc: 'RC / Form 20' }[type];
        pending = pending.filter((x) => x.kind !== kind).concat([{ kind, name: file.name || kind, mime: isPdf ? 'application/pdf' : 'image/jpeg', data }]);
        st.textContent = 'Padh rahe hain...'; U.loading(true, 'File padh rahe hain (OCR)...');
        const r = await OCR.extract(data, (pct) => { U.loading(true, 'OCR ' + pct + '%'); });
        const g = type === 'invoice' ? OCR.parseInvoice(r.text) : type === 'insurance' ? OCR.parseInsurance(r.text) : OCR.parseRC(r.text);
        const before = collect();
        const mrep = OCR.matchReport(g, before);
        if (type === 'invoice') {
          ['invoiceNo', 'invoiceDate', 'invoiceAmount'].forEach((k) => setV(k, g[k], true)); setV('invFinancer', g.financer, true);
          ['chassisNo', 'engineNo', 'model', 'variant', 'colour', 'keyNo', 'batteryNo', 'customerName', 'fatherName', 'mobile', 'address'].forEach((k) => setV(k, g[k]));
          if (g.financer) { setV('financer', g.financer); if (!before.saleType || before.saleType === 'Cash') { f.querySelector('[name=saleType]').value = 'Finance'; } }
          if (g.exShowroom) setV('price.exShowroom', g.exShowroom);
        } else if (type === 'insurance') {
          ['policyNo', 'insCompany', 'insFrom', 'insTo', 'odFrom', 'odTo', 'tpFrom', 'tpTo', 'insPremium', 'idv'].forEach((k) => setV(k, g[k], true)); setV('insFinancer', g.financer, true);
          setV('price.insurance', g.insPremium); setV('chassisNo', g.chassisNo); setV('engineNo', g.engineNo); setV('regNo', g.regNo); setV('model', g.model);
          if (inc) setV('cost.insurance', g.insPremium);
          f.querySelector('[name=insType]').value = g.odTo && g.tpTo && g.odTo !== g.tpTo ? 'Comprehensive (1 OD + 5 TP)' : (f.querySelector('[name=insType]').value || 'Comprehensive (1 yr)');
        } else {
          ['regNo', 'regDate', 'regValidTo'].forEach((k) => setV(k, g[k], true)); setV('rcOwner', g.ownerName, true); setV('rcFinancer', g.financer, true);
          ['chassisNo', 'engineNo', 'model', 'colour', 'fatherName', 'address'].forEach((k) => setV(k, g[k])); setV('customerName', g.ownerName);
          if (g.regNo) { f.querySelector('[name=rtoStatus]').value = 'Done'; }
        }
        const got = Object.keys(g).filter((k) => g[k]).length;
        st.innerHTML = '✅ ' + esc(r.method) + ': ' + got + ' details mili. Peele (yellow) fields check karein; file documents me save hogi.<br>' + OCR.matchHtml(mrep) +
          (mrep.some((m) => !m.ok) ? '<br><b class="low">⚠️ Document aur challan ka number match nahi kar raha — dhyan se check karein!</b>' : '');
        U.$$('details', f).forEach((d) => { if (d.querySelector('.ocr-filled')) d.open = true; });
        Form.lastOcrText = r.text;
        live();
      } catch (e) { console.error(e); st.textContent = '⚠️ Auto-read nahi hua (' + (e.message || e) + '). File fir bhi save hogi — details haath se bharein.'; }
      finally { U.loading(false); }
    });

    f.onsubmit = async (e) => {
      e.preventDefault();
      const o = collect();
      // mandatory fields (admin decides)
      const miss = Ch.FIELDS.filter(([k, , secn]) => req(k) && k !== 'challanNo' &&
        !(secn === 'Finance' && o.saleType !== 'Finance') && !(secn === 'Exchange' && !o.isExchange) && (o[k] === '' || o[k] == null)).map((x) => x[1]);
      if (miss.length) { U.toast('Zaroori fields bharein: ' + miss.join(', '), 'err'); return; }
      // mandatory documents / photos
      const haveKinds = new Set(oldFiles.map((x) => x.kind).concat(pending.map((x) => x.kind)));
      const missDocs = reqDocs.filter((k) => !haveKinds.has(k));
      if (missDocs.length) { U.toast('Ye photo / document zaroori hain: ' + missDocs.join(', '), 'err'); return; }
      if (o.mobile && o.mobile.length !== 10) return U.toast('Mobile number 10 digit ka hona chahiye', 'err');
      if (!p.id && Ch.minDate() && o.challanDate < Ch.minDate()) return U.toast('Itni purani date ka challan banane ka right nahi hai (back date)', 'err');
      if (o.challanDate > U.dateKey()) return U.toast('Challan date aage ki nahi ho sakti', 'err');
      const d0 = U.formData(f);
      if (d0.payDate && (d0.payDate > U.dateKey() || (Ch.minDate() && d0.payDate < Ch.minDate()))) return U.toast('Payment date galat hai / back date ka right nahi', 'err');
      // handover guard (payment due warning)
      const k1 = Ch.calc(Object.assign({}, c, o));
      if (!(await Form.handoverGuard(Object.assign({}, c, { due: p.id ? k1.payable - n(c.received) : k1.payable - n(d0.payAmount) }), c, o))) return;
      try {
        U.loading(true, 'Save ho raha hai...');
        if (o.chassisNo) {
          const dup = (await DB.query('challans', [['chassisNo', '==', o.chassisNo]].concat(Ch.ownWhere()))).filter((x) => x.id !== p.id && !x.cancelled);
          if (dup.length) { U.loading(false); if (!(await U.confirm('Ye Chassis No pehle se challan ' + dup[0].challanNo + ' me hai. Fir bhi save karein?', 'Save'))) return; U.loading(true); }
        }
        const me = Ch.me();
        let id = p.id;
        if (!id) {
          id = DB.newId('challans');
          if (!o.challanNo) { const num = await DB.nextNumber('challan'); o.challanNo = Ch.fmtNo(num); o.seq = num; }
          Object.assign(o, { ownerId: me.id, createdBy: me.id, createdByName: me.name, createdAt: DB.now(), entryDate: U.dateKey(), backDated: o.challanDate < U.dateKey() });
        } else if (!S.isAdmin) delete o.challanNo;
        o.updatedAt = DB.now(); o.updatedBy = me.name;
        o.customerKey = (o.customerName || '').toLowerCase() + ' ' + (o.mobile || '');
        const sid = Ch.stockId(o.chassisNo); if (sid) o.stockId = sid;
        const photo = pending.find((x) => x.kind === 'Customer Photo'); if (photo) o.photoThumb = photo.thumb;
        const k0 = Ch.calc(Object.assign({}, c, o));
        Object.assign(o, Ch.summaryFields(o, k0));
        if (p.id) await DB.update('challans', id, o); else await DB.set('challans', id, o);
        const owner = p.id ? c.ownerId : me.id;
        if (!p.id && n(d0.payAmount) > 0) {
          await Pay.save({ challanId: id, challanNo: o.challanNo, customerName: o.customerName, ownerId: owner, date: d0.payDate || o.challanDate, kind: d0.payKind, mode: d0.payMode, amount: n(d0.payAmount), ref: d0.payRef, remark: 'Challan ke saath' });
        }
        // stock: mark delivered (or back to stock if cancelled / chassis changed)
        try {
          if (c.stockId && c.stockId !== sid) await DB.update('cstock', c.stockId, { status: 'In Stock', challanId: '', challanNo: '', deliveredDate: '', customerName: '' });
          if (sid) {
            const sd = await DB.get('cstock', sid);
            if (sd) await DB.update('cstock', sid, o.cancelled ? { status: 'In Stock', challanId: '', challanNo: '', deliveredDate: '', customerName: '' } :
              { status: 'Delivered', challanId: id, challanNo: o.challanNo || c.challanNo, deliveredDate: o.deliveryDate || o.challanDate, customerName: o.customerName });
          }
          Ch.dirty('stock');
        } catch (se) { console.warn('stock update', se); }
        for (const pf of pending) { U.loading(true, pf.kind + ' upload ho raha hai...'); await Docs.save(id, owner, o.challanNo || c.challanNo, pf); }
        await Ch.recompute(id);
        Ch.dirty();
        U.loading(false); U.toast('Challan ' + (o.challanNo || c.challanNo) + ' save ho gaya', 'ok');
        App.go('view', { id });
      } catch (err) { console.error(err); U.loading(false); U.toast('Save nahi hua: ' + (err.message || err), 'err'); }
    };
  };

  // quick handover update (plate / RC / insurance) from challan view or customer search
  Form.handoverDialog = function (c, done) {
    if (!Ch.can('handover')) return U.toast('Ye update karne ka right nahi hai', 'err');
    const due = n(c.due);
    const m = U.modal('🔑 Plate / RC / Insurance · ' + c.challanNo, (due > 0.5 ? '<div class="warn-banner">⚠️ PAYMENT DUE: ' + U.money(due) + ' — payment clear hone par hi RC, Number Plate aur Insurance dena hai.</div>' : '<div class="ok-banner">✅ Payment clear hai</div>') +
      '<form class="form" id="hof"><div class="grid2">' +
      U.field('plateShowroom', 'Number Plate Showroom par', c.plateShowroom || 'Not Received', { type: 'select', options: Ch.PLATE_SHOWROOM }) + U.field('plateRecvDate', 'Plate aayi (date)', c.plateRecvDate || '', { type: 'date' }) +
      U.field('plateGiven', 'Number Plate Customer ko', c.plateGiven || 'Not Given', { type: 'select', options: Ch.GIVEN }) + U.field('plateGivenDate', 'Plate di (date)', c.plateGivenDate || '', { type: 'date' }) +
      U.field('rcGiven', 'RC Customer ko', c.rcGiven || 'Not Given', { type: 'select', options: Ch.GIVEN }) + U.field('rcGivenDate', 'RC di (date)', c.rcGivenDate || '', { type: 'date' }) +
      U.field('insGiven', 'Insurance Customer ko', c.insGiven || 'Not Given', { type: 'select', options: Ch.GIVEN }) + U.field('insGivenDate', 'Insurance di (date)', c.insGivenDate || '', { type: 'date' }) +
      '</div><button class="btn block">Save</button></form>', {
      onOpen: (w) => {
        const fm = U.$('#hof', w);
        [['plateShowroom', 'Received', 'plateRecvDate'], ['plateGiven', 'Given', 'plateGivenDate'], ['rcGiven', 'Given', 'rcGivenDate'], ['insGiven', 'Given', 'insGivenDate']].forEach(([s, val, dk]) => {
          const e = fm.querySelector('[name=' + s + ']');
          e.addEventListener('change', () => { const di = fm.querySelector('[name=' + dk + ']'); if (e.value === val && !di.value) di.value = U.dateKey(); if (e.value !== val) di.value = ''; });
        });
        fm.onsubmit = async (ev) => {
          ev.preventDefault(); const d = U.formData(fm);
          if (!(await Form.handoverGuard(c, c, d))) return;
          U.loading(true);
          try { await DB.update('challans', c.id, d); Ch.dirty(); m.close(); U.toast(T('saved'), 'ok'); done && done(); }
          catch (e) { U.toast(e.message, 'err'); } finally { U.loading(false); }
        };
      }
    });
  };
})();
