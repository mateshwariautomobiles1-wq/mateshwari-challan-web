// ---------- Challan entry / edit form ----------
(function () {
  const V = window.Views, esc = U.esc, n = U.num;
  const Form = window.ChForm = {};
  let pending = []; // files picked before save: {kind, name, mime, data, thumb}

  const dl = (id, list) => '<datalist id="' + id + '">' + (list || []).map((x) => '<option value="' + esc(x) + '">').join('') + '</datalist>';
  const req = (k) => !!(S.cs.required || {})[k];
  function F(name, label, v, o) {
    o = Object.assign({}, o || {}); if (req(name)) o.required = true;
    let h = U.field(name, label, v, o);
    if (o.list) h = h.replace('<input name="' + name + '"', '<input list="' + o.list + '" name="' + name + '"');
    if (o.required) h = h.replace(/ required(?=[ >])/, ''); // we validate ourselves (sections may be hidden)
    return h;
  }
  const sec = (id, title, body, open, extra) => '<details class="card sec" id="' + id + '"' + (open ? ' open' : '') + '><summary><b>' + title + '</b>' + (extra || '') + '</summary><div class="sec-body">' + body + '</div></details>';

  V.form = async function (el, p) {
    if (p.id ? !Ch.can('edit') : !Ch.can('create')) { el.innerHTML = U.empty('Aapko ye right nahi hai'); return; }
    const c = p.id ? await DB.get('challans', p.id) : { challanDate: U.dateKey(), saleType: 'Cash', executive: Ch.me().name, loanStatus: 'Pending', loanFileStatus: 'Pending', rtoStatus: 'Pending', price: {}, cost: {}, schemes: [] };
    if (!c) { el.innerHTML = U.empty('Challan nahi mila'); return; }
    pending = [];
    const cs = S.cs, inc = Ch.can('viewIncome');
    const pr = c.price || {}, co = c.cost || {};
    const priceRows = Ch.priceItems().map((it) => '<tr><td>' + esc(it.l) + '</td><td><input type="number" step="0.01" name="price.' + it.k + '" value="' + esc(pr[it.k] == null ? '' : pr[it.k]) + '"></td>' +
      (inc ? '<td><input type="number" step="0.01" name="cost.' + it.k + '" value="' + esc(co[it.k] == null ? '' : co[it.k]) + '" placeholder="cost"></td>' : '') + '</tr>').join('');

    el.innerHTML = '<div class="row-between"><h2 class="page-title">' + (p.id ? 'Edit Challan ' + esc(c.challanNo) : 'New Delivery Challan') + '</h2>' +
      (p.id ? '<button class="btn ghost sm" onclick="App.go(\'view\',{id:\'' + esc(p.id) + '\'})">← Back</button>' : '') + '</div>' +
      '<form id="chf" class="form" novalidate>' +
      sec('s-ch', '🧾 Challan', '<div class="grid2">' +
        F('challanNo', 'Challan No', c.challanNo || '', { placeholder: 'Auto (' + esc(cs.prefix) + '....)', readonly: !!p.id && !S.isAdmin }) +
        F('challanDate', 'Challan / Sale Date', c.challanDate, { type: 'date' }) +
        F('saleType', 'Cash / Finance', c.saleType, { type: 'select', options: ['Cash', 'Finance'] }) +
        F('executive', 'Sales Executive', c.executive || '') + '</div>' +
        (p.id ? U.field('cancelled', 'Challan Cancelled', !!c.cancelled, { type: 'checkbox' }) : ''), true) +
      sec('s-cu', '👤 Customer', '<div class="grid2">' +
        F('customerName', 'Customer Name', c.customerName) + F('fatherName', 'Father Name', c.fatherName) +
        F('mobile', 'Mobile No', c.mobile, { type: 'tel' }) + F('altMobile', 'Alternate Mobile', c.altMobile, { type: 'tel' }) +
        F('city', 'City / Village', c.city) + F('dob', 'Date of Birth', c.dob, { type: 'date' }) +
        F('aadhaar', 'Aadhaar No', c.aadhaar) + F('pan', 'PAN', c.pan) + '</div>' +
        F('address', 'Address', c.address, { type: 'textarea', rows: 2 }) +
        '<div class="row"><button type="button" class="btn ghost sm" data-photo="Customer Photo">📷 Customer Photo</button><span id="pv-Customer-Photo" class="pv">' +
        (c.photoThumb ? '<img src="' + esc(c.photoThumb) + '">' : '') + '</span></div>', true) +
      sec('s-ve', '🏍️ Vehicle', '<div class="grid2">' +
        F('model', 'Model', c.model, { list: 'dl-model' }) + F('variant', 'Variant', c.variant) + F('colour', 'Colour', c.colour, { list: 'dl-colour' }) +
        F('engineNo', 'Engine No', c.engineNo) + F('chassisNo', 'Chassis No', c.chassisNo) + F('keyNo', 'Key No', c.keyNo) + F('batteryNo', 'Battery No', c.batteryNo) +
        F('deliveryDate', 'Delivery Date', c.deliveryDate || c.challanDate, { type: 'date' }) + '</div>' +
        '<div class="row"><button type="button" class="btn ghost sm" data-photo="Delivery Photo">📸 Delivery Photo</button><span id="pv-Delivery-Photo" class="pv"></span></div>', true) +
      sec('s-in', '📄 Invoice / Billing', '<div class="ocr-box"><button type="button" class="btn sm" data-ocr="invoice">📤 Invoice PDF/Photo upload → Auto-fill</button><small class="muted" id="ocr-invoice"></small></div><div class="grid2">' +
        F('invoiceNo', 'Invoice No', c.invoiceNo) + F('invoiceDate', 'Invoice / Billing Date', c.invoiceDate, { type: 'date' }) +
        F('invoiceAmount', 'Invoice Amount', c.invoiceAmount, { type: 'number', step: '0.01' }) + '</div>', !!p.id) +
      sec('s-pr', '💰 On-Road Price', '<div class="table-wrap"><table class="tbl price-tbl"><thead><tr><th>Item</th><th>Charged</th>' + (inc ? '<th>Actual Cost</th>' : '') + '</tr></thead><tbody>' + priceRows + '</tbody></table></div>' +
        '<div class="grid2">' + F('discount', 'Discount (customer)', c.discount, { type: 'number', step: '0.01' }) +
        F('downPayment', 'Down Payment (agreed)', c.downPayment, { type: 'number', step: '0.01' }) +
        (inc ? F('dealerMargin', 'Vehicle Margin (dealer)', c.dealerMargin, { type: 'number', step: '0.01' }) + F('otherIncome', 'Other Income (payout etc.)', c.otherIncome, { type: 'number', step: '0.01' }) +
          F('incomeManual', 'Income (manual — khali chhodein to auto)', c.incomeManual, { type: 'number', step: '0.01' }) : '') + '</div>' +
        '<div id="liveTot" class="tot-box"></div>', true) +
      sec('s-fi', '🏦 Finance', '<div class="grid2">' +
        F('financer', 'Finance Company', c.financer, { list: 'dl-fin' }) + F('loanAppNo', 'Loan Application No', c.loanAppNo) +
        F('loanAmount', 'Loan Amount', c.loanAmount, { type: 'number', step: '0.01' }) + F('disburseExpected', 'Net Disbursal Expected', c.disburseExpected, { type: 'number', step: '0.01' }) +
        F('tenure', 'Tenure (months)', c.tenure, { type: 'number' }) + F('emi', 'EMI', c.emi, { type: 'number', step: '0.01' }) +
        F('roi', 'ROI %', c.roi, { type: 'number', step: '0.01' }) + F('emiStart', 'EMI Start Date', c.emiStart, { type: 'date' }) +
        F('advanceEmi', 'Advance EMI (count)', c.advanceEmi, { type: 'number' }) + F('loanStatus', 'Loan Status', c.loanStatus, { type: 'select', options: Ch.LOAN_STATUS }) +
        F('loanFileStatus', 'Loan File', c.loanFileStatus || 'Pending', { type: 'select', options: ['Pending', 'Complete'] }) + F('doNo', 'DO No', c.doNo) + '</div>' +
        F('fileRemark', 'Loan File Remark (kya pending hai)', c.fileRemark, { type: 'textarea', rows: 2 }), c.saleType === 'Finance') +
      sec('s-ex', '🔁 Exchange', '<div id="exBody" class="grid2">' + F('exOldModel', 'Old Vehicle / Model', c.exOldModel) + F('exRegNo', 'Old Reg No', c.exRegNo) +
        F('exYear', 'Model Year', c.exYear) + F('exOwner', 'Owner Name', c.exOwner) + F('exValue', 'Exchange Value (adjusted)', c.exValue, { type: 'number', step: '0.01' }) +
        F('exRemark', 'Remark', c.exRemark) + '</div>', !!c.isExchange, '<label class="chk inline" onclick="event.stopPropagation()"><input type="checkbox" name="isExchange"' + (c.isExchange ? ' checked' : '') + '> Exchange hai</label>') +
      sec('s-sc', '🎁 Scheme / Campaign / Cash Bonus', '<div id="schemes"></div><button type="button" class="btn ghost sm" id="addSch">+ Scheme row</button>' +
        '<p class="muted small">Customer ko diya = price me se kam hoga. Company claim = company se milna hai (claim pending report me aayega).</p>', !!c.hasScheme,
        '<label class="chk inline" onclick="event.stopPropagation()"><input type="checkbox" name="hasScheme"' + (c.hasScheme ? ' checked' : '') + '> Scheme hai</label>') +
      sec('s-ins', '🛡️ Insurance', '<div class="ocr-box"><button type="button" class="btn sm" data-ocr="insurance">📤 Insurance PDF/Photo upload → Auto-fill</button><small class="muted" id="ocr-insurance"></small></div><div class="grid2">' +
        F('insCompany', 'Insurance Company', c.insCompany, { list: 'dl-ins' }) + F('policyNo', 'Policy No', c.policyNo) +
        F('insFrom', 'Policy From', c.insFrom, { type: 'date' }) + F('insTo', 'Policy To', c.insTo, { type: 'date' }) +
        F('insPremium', 'Premium (policy)', c.insPremium, { type: 'number', step: '0.01' }) + F('idv', 'IDV', c.idv, { type: 'number', step: '0.01' }) + '</div>', !!p.id) +
      sec('s-rto', '🪪 RTO', '<div class="grid2">' + F('regNo', 'Registration No', c.regNo) + F('rtoStatus', 'RTO Status', c.rtoStatus || 'Pending', { type: 'select', options: ['Pending', 'Applied', 'Done'] }) +
        F('rtoDate', 'RTO Applied Date', c.rtoDate, { type: 'date' }) + F('plateStatus', 'Number Plate', c.plateStatus || 'Pending', { type: 'select', options: ['Pending', 'Ordered', 'Fitted'] }) + '</div>', !!p.id) +
      (!p.id && Ch.can('payment') ? sec('s-pay', '💵 Payment received abhi (optional)', '<div class="grid2">' +
        U.field('payAmount', 'Amount', '', { type: 'number', step: '0.01' }) + U.field('payMode', 'Mode', 'Cash', { type: 'select', options: Ch.PAY_MODES.filter((x) => x !== 'Finance') }) +
        U.field('payRef', 'Ref / UTR / Cheque No', '') + U.field('payKind', 'Type', 'Down Payment', { type: 'select', options: ['Down Payment', 'Booking Amount', 'Payment'] }) + '</div>', true) : '') +
      sec('s-rm', '📝 Remarks', F('remark', 'Remark', c.remark, { type: 'textarea', rows: 2 }), !!c.remark) +
      '<div class="sticky-save"><button class="btn block" type="submit">💾 Save Challan</button></div></form>' +
      dl('dl-model', cs.models) + dl('dl-colour', cs.colours) + dl('dl-fin', cs.financers) + dl('dl-ins', cs.insurers) + dl('dl-sch', cs.schemes);

    const f = U.$('#chf');
    // schemes repeater
    const schBox = U.$('#schemes');
    const addSch = (s) => {
      s = s || {};
      const d = document.createElement('div'); d.className = 'sch-row';
      d.innerHTML = '<input list="dl-sch" class="s-name" placeholder="Scheme name" value="' + esc(s.name || '') + '"><input type="number" step="0.01" class="s-amt" placeholder="Amount" value="' + esc(s.amount || '') + '">' +
        '<label class="chk"><input type="checkbox" class="s-cust"' + (s.toCustomer !== false ? ' checked' : '') + '> Customer ko diya</label>' +
        '<label class="chk"><input type="checkbox" class="s-claim"' + (s.claim ? ' checked' : '') + '> Company claim</label>' +
        '<label class="chk"><input type="checkbox" class="s-rec"' + (s.claimReceived ? ' checked' : '') + '> Claim mila</label><button type="button" class="icon-btn" title="Remove">✕</button>';
      d.querySelector('button').onclick = () => { d.remove(); live(); };
      U.$$('input', d).forEach((i) => i.oninput = live);
      schBox.appendChild(d);
    };
    (c.schemes && c.schemes.length ? c.schemes : [{}]).forEach(addSch);
    U.$('#addSch').onclick = () => addSch();

    const readSchemes = () => U.$$('.sch-row', schBox).map((r) => ({ name: U.$('.s-name', r).value.trim(), amount: n(U.$('.s-amt', r).value),
      toCustomer: U.$('.s-cust', r).checked, claim: U.$('.s-claim', r).checked, claimReceived: U.$('.s-rec', r).checked })).filter((s) => s.name || s.amount);

    function collect() {
      const d = U.formData(f); const o = { price: {}, cost: {} };
      Object.keys(d).forEach((k) => {
        if (/^(pay[A-Z])/.test(k)) return;
        if (k.startsWith('price.')) { if (d[k] !== '') o.price[k.slice(6)] = n(d[k]); return; }
        if (k.startsWith('cost.')) { if (d[k] !== '') o.cost[k.slice(5)] = n(d[k]); return; }
        o[k] = d[k];
      });
      if (!inc) { o.cost = c.cost || {}; ['dealerMargin', 'otherIncome', 'incomeManual'].forEach((k) => { if (c[k] !== undefined) o[k] = c[k]; }); }
      o.schemes = readSchemes();
      o.mobile = String(o.mobile || '').replace(/\D/g, '').slice(-10);
      ['chassisNo', 'engineNo', 'regNo', 'pan', 'exRegNo'].forEach((k) => { if (o[k]) o[k] = String(o[k]).toUpperCase().replace(/\s+/g, ''); });
      return o;
    }
    function live() {
      const o = collect(); const k = Ch.calc(Object.assign({}, c, o));
      U.$('#liveTot').innerHTML = '<div><span>On-Road Total</span><b>' + U.money(k.gross) + '</b></div><div><span>Customer Payable</span><b>' + U.money(k.payable) + '</b></div>' +
        (o.saleType === 'Finance' ? '<div><span>Finance</span><b>' + U.money(k.finAmt) + '</b></div>' : '') + (o.isExchange ? '<div><span>Exchange</span><b>' + U.money(k.exValue) + '</b></div>' : '') +
        '<div><span>Down Payment banta</span><b>' + U.money(k.dpExpected) + '</b></div>' + (inc ? '<div><span>Income</span><b>' + U.money(k.income) + '</b></div>' : '');
      U.$('#s-fi').style.display = o.saleType === 'Finance' ? '' : 'none';
    }
    f.addEventListener('input', live); f.addEventListener('change', live); live();
    U.$('[name=isExchange]').onchange = (e) => { U.$('#s-ex').open = e.target.checked; live(); };
    U.$('[name=hasScheme]').onchange = (e) => { U.$('#s-sc').open = e.target.checked; live(); };
    const setV = (k, v, force) => { const i = f.querySelector('[name="' + k + '"]'); if (i && v !== '' && v != null && (force || !i.value)) { i.value = v; i.classList.add('ocr-filled'); } };

    // photos
    U.$$('[data-photo]').forEach((b) => b.onclick = async () => {
      if (!Ch.can('upload')) return U.toast('Upload right nahi hai', 'err');
      const file = await U.pickFile('image/*'); if (!file) return;
      const data = await U.compressImage(file, 1280, 0.75); const thumb = await U.compressImage(file, 160, 0.6);
      const kind = b.dataset.photo;
      pending = pending.filter((x) => x.kind !== kind).concat([{ kind, name: kind + '.jpg', mime: 'image/jpeg', data, thumb }]);
      U.$('#pv-' + kind.replace(/ /g, '-')).innerHTML = '<img src="' + thumb + '">';
    });

    // OCR upload: invoice / insurance
    U.$$('[data-ocr]').forEach((b) => b.onclick = async () => {
      const type = b.dataset.ocr, st = U.$('#ocr-' + type);
      const file = await U.pickFile('application/pdf,image/*'); if (!file) return;
      if (file.size > Files.MAX) return U.toast('File 8 MB se badi hai', 'err');
      try {
        const isPdf = /pdf/i.test(file.type) || /\.pdf$/i.test(file.name);
        const data = isPdf ? await U.fileToDataURL(file) : await U.compressImage(file, 2000, 0.85);
        const kind = type === 'invoice' ? 'Invoice' : 'Insurance Policy';
        pending = pending.filter((x) => x.kind !== kind).concat([{ kind, name: file.name || kind, mime: isPdf ? 'application/pdf' : 'image/jpeg', data }]);
        st.textContent = 'Padh rahe hain...'; U.loading(true, 'File padh rahe hain (OCR)...');
        const r = await OCR.extract(data, (pct) => { U.loading(true, 'OCR ' + pct + '%'); });
        const g = type === 'invoice' ? OCR.parseInvoice(r.text) : OCR.parseInsurance(r.text);
        if (type === 'invoice') {
          setV('invoiceNo', g.invoiceNo, true); setV('invoiceDate', g.invoiceDate, true); setV('invoiceAmount', g.invoiceAmount, true);
          setV('chassisNo', g.chassisNo); setV('engineNo', g.engineNo); setV('model', g.model); setV('colour', g.colour); setV('customerName', g.customerName); setV('mobile', g.mobile);
        } else {
          setV('policyNo', g.policyNo, true); setV('insCompany', g.insCompany, true); setV('insFrom', g.insFrom, true); setV('insTo', g.insTo, true);
          setV('insPremium', g.insPremium, true); setV('idv', g.idv, true); setV('price.insurance', g.insPremium); setV('chassisNo', g.chassisNo); setV('engineNo', g.engineNo);
          if (inc) setV('cost.insurance', g.insPremium);
        }
        const got = Object.keys(g).filter((k) => g[k]).length;
        st.textContent = '✅ ' + r.method + ': ' + got + ' fields bhare. Pila (yellow) rang wale fields check karein. File save ke saath documents me jayegi.';
        U.$$('details', f).forEach((d) => { if (d.querySelector('.ocr-filled')) d.open = true; });
        Form.lastOcrText = r.text;
        live();
      } catch (e) { console.error(e); st.textContent = '⚠️ Auto-read nahi hua (' + (e.message || e) + '). File fir bhi save hogi — details haath se bharein.'; }
      finally { U.loading(false); }
    });

    f.onsubmit = async (e) => {
      e.preventDefault();
      const o = collect();
      // mandatory check (admin decides)
      const miss = Ch.FIELDS.filter(([k, , secn]) => req(k) && k !== 'challanNo' &&
        !(secn === 'Finance' && o.saleType !== 'Finance') && !(secn === 'Exchange' && !o.isExchange) && (o[k] === '' || o[k] == null)).map((x) => x[1]);
      if (miss.length) { U.toast('Zaroori fields bharein: ' + miss.join(', '), 'err'); return; }
      if (o.mobile && o.mobile.length !== 10) return U.toast('Mobile number 10 digit ka hona chahiye', 'err');
      try {
        U.loading(true, 'Save ho raha hai...');
        if (o.chassisNo) {
          const dup = (await DB.query('challans', [['chassisNo', '==', o.chassisNo]].concat(Ch.ownWhere()))).filter((x) => x.id !== p.id && !x.cancelled);
          if (dup.length) { U.loading(false); if (!(await U.confirm('Ye Chassis No pehle se challan ' + dup[0].challanNo + ' me hai. Fir bhi save karein?', 'Save'))) return; U.loading(true); }
        }
        const me = Ch.me();
        let id = p.id;
        if (!id) {
          id = DB.newId('challans');
          if (!o.challanNo) { const num = await DB.nextNumber('challan'); o.challanNo = Ch.fmtNo(num); o.seq = num; }
          Object.assign(o, { ownerId: me.id, createdBy: me.id, createdByName: me.name, createdAt: DB.now() });
        } else if (!S.isAdmin) delete o.challanNo;
        o.updatedAt = DB.now(); o.updatedBy = me.name;
        o.customerKey = (o.customerName || '').toLowerCase() + ' ' + (o.mobile || '');
        const photo = pending.find((x) => x.kind === 'Customer Photo'); if (photo) o.photoThumb = photo.thumb;
        const k0 = Ch.calc(Object.assign({}, c, o));
        Object.assign(o, Ch.summaryFields(o, k0));
        if (p.id) await DB.update('challans', id, o); else await DB.set('challans', id, o);
        const owner = p.id ? c.ownerId : me.id;
        const d = U.formData(f);
        if (!p.id && n(d.payAmount) > 0) {
          await Pay.save({ challanId: id, challanNo: o.challanNo, customerName: o.customerName, ownerId: owner, date: o.challanDate, kind: d.payKind, mode: d.payMode, amount: n(d.payAmount), ref: d.payRef, remark: 'Challan ke saath' });
        }
        for (const pf of pending) { U.loading(true, pf.kind + ' upload ho raha hai...'); await Docs.save(id, owner, o.challanNo, pf); }
        await Ch.recompute(id);
        Ch.dirty();
        U.loading(false); U.toast('Challan ' + o.challanNo + ' save ho gaya', 'ok');
        App.go('view', { id });
      } catch (err) { console.error(err); U.loading(false); U.toast('Save nahi hua: ' + (err.message || err), 'err'); }
    };
  };
})();
