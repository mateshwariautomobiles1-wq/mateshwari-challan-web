// ---------- Challan masters, rights, calculations, data access ----------
(function () {
  const Ch = window.Ch = {};

  Ch.LOAN_STATUS = ['Pending', 'Login', 'Under Process', 'Approved', 'DO Received', 'Disbursed', 'Rejected'];
  Ch.PAY_KINDS = ['Down Payment', 'Payment', 'Booking Amount', 'Disbursement', 'Refund'];
  Ch.PAY_MODES = ['Cash', 'Bank', 'UPI', 'Cheque', 'Card', 'Finance'];
  Ch.CALL_OUTCOMES = ['Promise to Pay', 'Call Back', 'Not Reachable', 'Switched Off', 'Paid', 'Dispute', 'Other'];

  Ch.RIGHTS = [
    ['access', 'Challan App open kar sake'],
    ['viewAll', 'Sabhi challan dekh sake (warna sirf apne)'],
    ['create', 'Naya challan bana sake'],
    ['edit', 'Challan edit kar sake'],
    ['delete', 'Challan delete kar sake'],
    ['payment', 'Payment / Down payment entry'],
    ['disburse', 'Finance disbursement entry'],
    ['editPayment', 'Payment edit / delete'],
    ['calling', 'Calling + remark entry'],
    ['upload', 'Photo / document upload'],
    ['deleteFile', 'Document delete'],
    ['reports', 'Reports dekh sake'],
    ['export', 'Excel / PDF / Tally export'],
    ['import', 'Excel se import'],
    ['viewIncome', 'Income / cost / margin dekh sake'],
    ['dashboard', 'Dashboard dekh sake'],
    ['backDate', 'Back date entry (purani date se payment/challan)'],
    ['stock', 'Stock dekh sake / challan me stock se chune'],
    ['stockAdd', 'Stock add / import (Excel, invoice PDF, opening)'],
    ['masters', 'Model / Village / Finance company add kar sake'],
    ['handover', 'Number plate / RC / Insurance status update'],
    ['handoverDue', 'Due hote hue bhi RC / plate / insurance de sake'],
    ['renewal', 'Insurance renewal follow-up']
  ];
  Ch.defaultRights = () => ({ access: true, viewAll: false, create: true, edit: true, delete: false, payment: true, disburse: false, editPayment: false,
    calling: true, upload: true, deleteFile: false, reports: false, export: false, import: false, viewIncome: false, dashboard: true,
    backDate: false, stock: true, stockAdd: false, masters: true, handover: true, handoverDue: false, renewal: true });

  // Price components of on-road price (charged to customer + optional actual cost for income)
  Ch.DEFAULT_PRICE_ITEMS = [
    { k: 'exShowroom', l: 'Ex-Showroom' }, { k: 'rto', l: 'RTO / Registration' }, { k: 'insurance', l: 'Insurance' },
    { k: 'accessories', l: 'Accessories' }, { k: 'extWarranty', l: 'Extended Warranty' }, { k: 'hpCharges', l: 'HP / Hypothecation' },
    { k: 'amc', l: 'AMC / Service Pack' }, { k: 'numberPlate', l: 'Number Plate (HSRP)' }, { k: 'other', l: 'Other Charges' }
  ];

  // All fields of the challan form (key, label, section) — admin can mark any as mandatory
  Ch.FIELDS = [
    ['challanNo', 'Challan No', 'Challan'], ['challanDate', 'Challan Date', 'Challan'], ['saleType', 'Cash / Finance', 'Challan'], ['executive', 'Sales Executive', 'Challan'],
    ['customerName', 'Customer Name', 'Customer'], ['fatherName', 'Father Name', 'Customer'], ['mobile', 'Mobile No', 'Customer'], ['altMobile', 'Alternate Mobile', 'Customer'],
    ['address', 'Address', 'Customer'], ['city', 'City / Village', 'Customer'], ['aadhaar', 'Aadhaar No', 'Customer'], ['pan', 'PAN', 'Customer'], ['dob', 'Date of Birth', 'Customer'],
    ['model', 'Model', 'Vehicle'], ['variant', 'Variant', 'Vehicle'], ['colour', 'Colour', 'Vehicle'], ['engineNo', 'Engine No', 'Vehicle'], ['chassisNo', 'Chassis No', 'Vehicle'],
    ['keyNo', 'Key No', 'Vehicle'], ['batteryNo', 'Battery No', 'Vehicle'],
    ['invoiceNo', 'Invoice No', 'Invoice'], ['invoiceDate', 'Invoice / Billing Date', 'Invoice'], ['invoiceAmount', 'Invoice Amount', 'Invoice'],
    ['financer', 'Finance Company', 'Finance'], ['loanAppNo', 'Loan Application No', 'Finance'], ['loanAmount', 'Loan Amount', 'Finance'], ['tenure', 'Tenure (months)', 'Finance'],
    ['emi', 'EMI', 'Finance'], ['roi', 'Rate of Interest', 'Finance'], ['emiStart', 'EMI Start Date', 'Finance'], ['downPayment', 'Down Payment (agreed)', 'Finance'],
    ['insCompany', 'Insurance Company', 'Insurance'], ['policyNo', 'Policy No', 'Insurance'], ['insFrom', 'Policy From', 'Insurance'],
    ['insTo', 'Policy To', 'Insurance'], ['odTo', 'OD Cover Expiry', 'Insurance'], ['tpTo', 'Third Party Expiry', 'Insurance'],
    ['regNo', 'Registration No', 'RTO'], ['regDate', 'Registration Date', 'RTO'], ['rtoStatus', 'RTO Status', 'RTO'],
    ['deliveryDate', 'Delivery Date', 'Vehicle'], ['paymentDueDate', 'Payment Due Date', 'Challan'],
    ['exOldModel', 'Exchange: Old Vehicle', 'Exchange'], ['exRegNo', 'Exchange: Reg No', 'Exchange'], ['exValue', 'Exchange: Value', 'Exchange']
  ];

  Ch.defaultSettings = () => ({
    prefix: 'DC/', padding: 4,
    models: [], colours: ['Black', 'Red', 'Blue', 'Grey', 'White', 'Silver'],
    financers: ['Hero FinCorp', 'Bajaj Finance', 'TVS Credit', 'L&T Finance', 'IDFC First', 'HDFC Bank', 'Shriram Finance', 'Cholamandalam'],
    insurers: ['ICICI Lombard', 'Bajaj Allianz', 'HDFC Ergo', 'Tata AIG', 'New India Assurance', 'United India', 'Digit'],
    schemes: ['Cash Bonus', 'Exchange Bonus', 'Corporate Offer', 'Loyalty Bonus', 'Festival Offer'],
    docTypes: ['Customer Photo', 'Delivery Photo', 'Manual Challan Photo', 'Aadhaar Card', 'PAN Card', 'Invoice', 'Insurance Policy', 'RC / Form 20', 'Loan Agreement', 'DO Letter', 'Exchange RC', 'Other'],
    priceItems: Ch.DEFAULT_PRICE_ITEMS,
    required: { challanDate: true, customerName: true, mobile: true, model: true, chassisNo: true },
    showroomAddress: '', showroomPhone: '', gstin: '',
    challanTerms: '1. Vehicle delivered in good condition.\n2. Registration & insurance as per documents attached.\n3. Balance amount, if any, payable as agreed.',
    tallySalesLedger: 'Vehicle Sales', tallyCashLedger: 'Cash', tallyBankLedger: 'Bank Account',
    villages: [], modelPrices: {}, requiredDocs: [], upperCase: true, backDateDays: 3, creditDays: 0, renewalDays: 30
  });

  Ch.PLATE_SHOWROOM = ['Not Received', 'Received'];
  Ch.GIVEN = ['Not Given', 'Given'];
  // ----- date differences: delivery -> invoice / insurance / registration -----
  Ch.baseDate = (c) => c.deliveryDate || c.challanDate;
  Ch.diffs = (c) => {
    const b = Ch.baseDate(c), d = (x) => (x && b ? Ch.daysBetween(b, x) : null);
    return { inv: d(c.invoiceDate), ins: d(c.odFrom || c.insFrom), reg: d(c.regDate) };
  };
  Ch.diffTxt = (x) => (x == null ? '-' : x === 0 ? 'Same day' : (x > 0 ? '+' : '') + x + ' din');
  // ----- DPD (days past due) -----
  Ch.dueDate = (c) => {
    if (c.paymentDueDate) return c.paymentDueDate;
    const d = new Date((c.challanDate || U.dateKey()) + 'T00:00:00'); d.setDate(d.getDate() + (Number((S.cs || {}).creditDays) || 0)); return U.dateKey(d);
  };
  Ch.dpd = (c) => (U.num(c.due) > 0.5 && !c.cancelled ? Math.max(0, Ch.daysBetween(Ch.dueDate(c)) || 0) : 0);
  Ch.DPD_BUCKETS = ['Current (0)', 'DPD 1-30', 'DPD 31-60', 'DPD 61-90', 'DPD 90+'];
  Ch.dpdBucket = (d) => (d <= 0 ? Ch.DPD_BUCKETS[0] : d <= 30 ? Ch.DPD_BUCKETS[1] : d <= 60 ? Ch.DPD_BUCKETS[2] : d <= 90 ? Ch.DPD_BUCKETS[3] : Ch.DPD_BUCKETS[4]);
  // ----- delivered-vehicle flags -----
  Ch.flags = (c) => ({
    Invoice: c.invoiceNo ? 'OK' : 'Pending',
    Insurance: c.policyNo ? 'OK' : 'Pending',
    RTO: (c.rtoStatus === 'Done' || c.regNo) ? 'Done' : 'Pending',
    'Plate @Showroom': c.plateShowroom === 'Received' ? 'Received' : 'Pending',
    'Plate to Customer': c.plateGiven === 'Given' ? 'Given' : 'Pending',
    'RC to Customer': c.rcGiven === 'Given' ? 'Given' : 'Pending',
    Payment: U.num(c.due) > 0.5 ? 'Due' : 'Clear'
  });
  Ch.flagOk = (v) => ['OK', 'Done', 'Received', 'Given', 'Clear'].includes(v);
  // back date allowed?
  Ch.minDate = () => {
    if (Ch.can('backDate')) return '';
    const d = new Date(); d.setDate(d.getDate() - (Number((S.cs || {}).backDateDays) || 0)); return U.dateKey(d);
  };

  // ---------- Rights helpers ----------
  Ch.can = (r) => S.isAdmin || !!(S.cr && S.cr.access && S.cr[r]);
  Ch.seesAll = () => S.isAdmin || Ch.can('viewAll');
  Ch.ownWhere = () => (Ch.seesAll() ? [] : [['ownerId', '==', S.empId]]);
  Ch.me = () => (S.isCustomer ? { id: 'customer', name: 'Customer: ' + (S.user.name || '') } : { id: S.isAdmin ? 'admin' : S.empId, name: S.isAdmin ? (S.user.name || 'Admin') : ((S.emp && S.emp.name) || '') });

  // ---------- Data access (cached per session, refreshed after writes) ----------
  const cache = {};
  Ch.dirty = (k) => { if (k) delete cache[k]; else Object.keys(cache).forEach((x) => delete cache[x]); };
  const cached = async (k, fn) => { if (!cache[k]) cache[k] = fn().catch((e) => { delete cache[k]; throw e; }); return cache[k]; };

  Ch.challans = () => cached('challans', async () => (await DB.query('challans', Ch.ownWhere()))
    .sort((a, b) => String(b.challanDate || '').localeCompare(String(a.challanDate || '')) || (b.seq || 0) - (a.seq || 0)));
  Ch.allPayments = () => cached('pays', () => DB.query('cpay', Ch.ownWhere()));
  Ch.allCalls = () => cached('calls', () => DB.query('ccalls', Ch.ownWhere()));
  Ch.payments = async (id) => (await DB.query('cpay', [['challanId', '==', id]].concat(Ch.ownWhere()))).sort((a, b) => String(a.date).localeCompare(String(b.date)));
  Ch.calls = async (id) => (await DB.query('ccalls', [['challanId', '==', id]].concat(Ch.ownWhere()))).sort((a, b) => (U.toDate(b.at) || 0) - (U.toDate(a.at) || 0));
  Ch.files = async (id) => (await DB.query('cfilemeta', [['challanId', '==', id]].concat(Ch.ownWhere()))).sort((a, b) => (U.toDate(a.at) || 0) - (U.toDate(b.at) || 0));
  Ch.allFileMeta = () => cached('files', () => DB.query('cfilemeta', Ch.ownWhere()));

  // ---------- Calculations ----------
  const n = U.num;
  Ch.priceItems = () => (S.cs && S.cs.priceItems && S.cs.priceItems.length ? S.cs.priceItems : Ch.DEFAULT_PRICE_ITEMS);
  Ch.itemsTotal = (c) => U.round2(Ch.priceItems().reduce((s, it) => s + n((c.price || {})[it.k]), 0));
  // on-road total: manual total (if filled) else sum of breakup
  Ch.gross = (c) => (n(c.onRoadManual) > 0 ? U.round2(n(c.onRoadManual)) : Ch.itemsTotal(c));
  // masters: admin settings list + lists added from the app (cmasters/lists)
  Ch.list = (k) => Array.from(new Set([].concat((S.cs || {})[k] || [], ((S.cm || {})[k]) || []).filter(Boolean))).sort((a, b) => String(a).localeCompare(String(b)));
  Ch.addMaster = async (k, v) => {
    v = String(v || '').trim(); if (S.cs && S.cs.upperCase) v = v.toUpperCase();
    if (!v || Ch.list(k).some((x) => String(x).toLowerCase() === v.toLowerCase())) return false;
    await DB.set('cmasters', 'lists', { [k]: DB.union(v) }, true);
    S.cm = S.cm || {}; S.cm[k] = (S.cm[k] || []).concat([v]);
    return true;
  };
  Ch.modelPrice = (model) => { const P = S.mp || {}; const k = Object.keys(P).find((m) => m.toLowerCase() === String(model || '').toLowerCase()); return k ? P[k] : null; };
  // stock
  Ch.stockId = (ch) => String(ch || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  Ch.stockInHand = () => cached('stock', () => DB.query('cstock', [['status', '==', 'In Stock']]));
  Ch.daysBetween = (a, b) => {
    const d1 = a ? new Date(String(a).slice(0, 10) + 'T00:00:00') : null, d2 = b ? new Date(String(b).slice(0, 10) + 'T00:00:00') : new Date(U.dateKey() + 'T00:00:00');
    if (!d1 || isNaN(d1) || isNaN(d2)) return null;
    return Math.round((d2 - d1) / 86400000);
  };

  // c = challan, pays = its payments (optional — falls back to stored summary)
  Ch.calc = function (c, pays) {
    const gross = Ch.gross(c);
    const schemes = c.hasScheme ? (c.schemes || []) : [];
    const custScheme = U.round2(schemes.filter((s) => s.toCustomer).reduce((s, x) => s + n(x.amount), 0));
    const claimScheme = U.round2(schemes.filter((s) => s.claim).reduce((s, x) => s + n(x.amount), 0));
    const claimPending = U.round2(schemes.filter((s) => s.claim && !s.claimReceived).reduce((s, x) => s + n(x.amount), 0));
    const discount = n(c.discount);
    const payable = U.round2(gross - discount - custScheme);
    const exValue = c.isExchange ? n(c.exValue) : 0;
    let custPaid, disbursed, lastPayDate = c.lastPayDate || '', disbDate = c.disbDate || '', cashIn = 0, bankIn = 0;
    if (pays) {
      custPaid = 0; disbursed = 0; lastPayDate = ''; disbDate = '';
      pays.forEach((p) => {
        const amt = n(p.amount) * (p.kind === 'Refund' ? -1 : 1);
        if (p.kind === 'Disbursement') { disbursed += amt; if (!disbDate || p.date > disbDate) disbDate = p.date; }
        else { custPaid += amt; if (p.mode === 'Cash') cashIn += amt; else bankIn += amt; }
        if (p.date > lastPayDate) lastPayDate = p.date;
      });
      custPaid = U.round2(custPaid); disbursed = U.round2(disbursed);
    } else { custPaid = n(c.sumPaid); disbursed = n(c.sumDisbursed); cashIn = n(c.sumCash); bankIn = n(c.sumBank); }
    const isFin = c.saleType === 'Finance';
    const finAmt = isFin ? n(c.disburseExpected || c.loanAmount) : 0;
    const received = U.round2(custPaid + disbursed + exValue);
    const due = U.round2(payable - received);
    const finDue = isFin ? Math.max(0, U.round2(finAmt - disbursed)) : 0;
    const dpExpected = U.round2(payable - finAmt - exValue);
    const dpDue = Math.max(0, U.round2(dpExpected - custPaid));
    // income: margin entered manually OR auto = sum(charged - cost) where cost is filled + company claims - customer discounts
    let autoIncome = 0;
    Ch.priceItems().forEach((it) => { const cost = (c.cost || {})[it.k]; if (cost !== undefined && cost !== '' && cost !== null) autoIncome += n((c.price || {})[it.k]) - n(cost); });
    autoIncome = U.round2(autoIncome + n(c.dealerMargin) + claimScheme - discount - custScheme + n(c.otherIncome));
    const income = c.incomeManual !== undefined && c.incomeManual !== '' && c.incomeManual !== null ? n(c.incomeManual) : autoIncome;
    return {
      gross, discount, custScheme, claimScheme, claimPending, payable, exValue, custPaid, disbursed, cashIn: U.round2(cashIn), bankIn: U.round2(bankIn),
      received, due, finAmt, finDue, dpExpected, dpDue, income, autoIncome, lastPayDate, disbDate,
      dueDays: due > 0.5 ? Ch.daysBetween(c.challanDate) : 0,
      billDays: c.invoiceDate ? Ch.daysBetween(c.challanDate, c.invoiceDate) : null,
      finDays: disbDate ? Ch.daysBetween(c.challanDate, disbDate) : null,
      payDays: lastPayDate ? Ch.daysBetween(c.challanDate, lastPayDate) : null
    };
  };

  // summary fields stored on the challan so lists/dashboards stay fast
  Ch.summaryFields = (c, k) => ({
    gross: k.gross, payable: k.payable, sumPaid: k.custPaid, sumDisbursed: k.disbursed, sumCash: k.cashIn, sumBank: k.bankIn,
    received: k.received, due: k.due, dpDue: k.dpDue, finDue: k.finDue, income: k.income, lastPayDate: k.lastPayDate || '', disbDate: k.disbDate || ''
  });
  Ch.recompute = async function (id) {
    const c = await DB.get('challans', id); if (!c) return null;
    const pays = await Ch.payments(id);
    const k = Ch.calc(c, pays);
    const upd = Ch.summaryFields(c, k);
    if (c.saleType === 'Finance' && k.disbursed > 0 && k.finDue <= 0.5 && c.loanStatus !== 'Disbursed') upd.loanStatus = 'Disbursed';
    await DB.update('challans', id, upd);
    Ch.dirty();
    if (c.custUid && window.Cust) { try { await Cust.publish(id); } catch (e) { console.warn('publish', e); } }
    return Object.assign(c, upd);
  };

  Ch.fmtNo = (num) => (S.cs.prefix || '') + String(num).padStart(Number(S.cs.padding) || 1, '0');
  Ch.statusOf = function (c) {
    if (c.cancelled) return ['Cancelled', 'bad'];
    if (n(c.due) > 0.5) return ['Due ' + U.money(c.due), 'warn'];
    if (n(c.due) < -0.5) return ['Excess ' + U.money(-c.due), 'info'];
    return ['Clear', 'ok'];
  };
  Ch.loanBadge = (s) => '<span class="badge ' + ({ Disbursed: 'ok', Rejected: 'bad', Approved: 'info', 'DO Received': 'info' }[s] || 'warn') + '">' + U.esc(s || 'Pending') + '</span>';
  Ch.ageBucket = (d) => (d == null ? '-' : d <= 7 ? '0-7 days' : d <= 15 ? '8-15 days' : d <= 30 ? '16-30 days' : d <= 60 ? '31-60 days' : '60+ days');
  Ch.AGE_BUCKETS = ['0-7 days', '8-15 days', '16-30 days', '31-60 days', '60+ days'];

  // EMI schedule
  Ch.emiSchedule = function (c) {
    const t = parseInt(c.tenure) || 0, emi = n(c.emi);
    if (!t || !emi || !c.emiStart) return [];
    const out = []; const s = new Date(c.emiStart + 'T00:00:00'); const today = U.dateKey();
    for (let i = 0; i < t; i++) {
      const d = new Date(s.getFullYear(), s.getMonth() + i, Math.min(s.getDate(), 28));
      const dk = U.dateKey(d);
      out.push({ no: i + 1, date: dk, emi, status: dk <= today ? 'Due/Paid' : 'Upcoming' });
    }
    return out;
  };

  // filter by date range on challanDate
  Ch.inRange = (d, from, to) => (!from || String(d || '') >= from) && (!to || String(d || '') <= to);
})();
