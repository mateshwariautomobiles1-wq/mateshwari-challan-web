// ---------- OCR: Invoice / Insurance PDF or photo -> auto-fill fields ----------
// PDF with text  -> pdf.js text read (fast, exact)
// Scanned PDF / photo -> Tesseract OCR (works offline inside the app)
(function () {
  const OCR = window.OCR = {};
  const abs = (p) => new URL(p, location.href).href;
  let worker = null;

  async function getWorker(progress) {
    if (worker) return worker;
    worker = await Tesseract.createWorker('eng', 1, {
      workerPath: abs('lib/ocr/worker.min.js'), corePath: abs('lib/ocr/'), langPath: abs('lib/ocr/lang'), gzip: true,
      logger: (m) => { if (progress && m.status === 'recognizing text') progress(Math.round(m.progress * 100)); }
    });
    return worker;
  }
  async function ocrImage(src, progress) {
    const w = await getWorker(progress);
    const r = await w.recognize(src);
    return (r && r.data && r.data.text) || '';
  }

  function pdfjs() {
    const lib = window.pdfjsLib;
    if (lib && !lib.GlobalWorkerOptions.workerSrc) lib.GlobalWorkerOptions.workerSrc = abs('lib/pdf.worker.min.js');
    return lib;
  }
  const b64ToBytes = (b64) => { const s = atob(b64); const a = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a; };

  // Returns plain text from a PDF (text layer) — rebuilds lines by Y position
  async function pdfText(pdf, maxPages) {
    let out = '';
    for (let p = 1; p <= Math.min(pdf.numPages, maxPages || 3); p++) {
      const page = await pdf.getPage(p);
      const tc = await page.getTextContent();
      const rows = {};
      tc.items.forEach((it) => { const y = Math.round(it.transform[5] / 3); (rows[y] = rows[y] || []).push(it); });
      Object.keys(rows).map(Number).sort((a, b) => b - a).forEach((y) => {
        out += rows[y].sort((a, b) => a.transform[4] - b.transform[4]).map((i) => i.str).join(' ').replace(/\s+/g, ' ') + '\n';
      });
    }
    return out;
  }
  async function pdfToImages(pdf, maxPages) {
    const imgs = [];
    for (let p = 1; p <= Math.min(pdf.numPages, maxPages || 2); p++) {
      const page = await pdf.getPage(p);
      const vp = page.getViewport({ scale: 2.2 });
      const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height;
      await page.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
      imgs.push(c.toDataURL('image/png'));
    }
    return imgs;
  }

  // dataUrl: data:...;base64,... -> text
  OCR.extract = async function (dataUrl, progress) {
    const m = /^data:([^;]+);base64,(.*)$/.exec(dataUrl || '');
    if (!m) throw new Error('File read nahi hui');
    if (/pdf/i.test(m[1])) {
      const pdf = await pdfjs().getDocument({ data: b64ToBytes(m[2]) }).promise;
      const txt = await pdfText(pdf, 3);
      if (txt.replace(/\s/g, '').length > 60) return { text: txt, method: 'PDF text' };
      let all = '';
      for (const img of await pdfToImages(pdf, 2)) all += (await ocrImage(img, progress)) + '\n';
      return { text: all, method: 'OCR (scanned PDF)' };
    }
    return { text: await ocrImage(dataUrl, progress), method: 'OCR (photo)' };
  };

  // ---------- parsing helpers ----------
  const MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
  const DATE_RE = /(\d{1,2})[\/\-\.\s](\d{1,2}|[A-Za-z]{3,9})[\/\-\.\s,]+(\d{4}|\d{2})\b|(\d{4})-(\d{2})-(\d{2})/g;
  function toISO(m) {
    if (m[4]) return m[4] + '-' + m[5] + '-' + m[6];
    let d = +m[1], mo = /\d/.test(m[2]) ? +m[2] : MON[m[2].slice(0, 3).toLowerCase()], y = +m[3];
    if (!mo || mo > 12 || d > 31 || d < 1) return null;
    if (y < 100) y += 2000;
    if (y < 2000 || y > 2100) return null;
    return y + '-' + U.pad(mo) + '-' + U.pad(d);
  }
  OCR.dates = (s) => { const out = []; let m; DATE_RE.lastIndex = 0; while ((m = DATE_RE.exec(s))) { const d = toISO(m); if (d) out.push(d); } return out; };
  const amt = (s) => { const v = parseFloat(String(s).replace(/[,\s]/g, '').replace(/^[^\d]+/, '')); return isNaN(v) ? null : v; };
  const AMT_RE = /(?:rs\.?|inr|₹)?\s*([0-9]{1,3}(?:,[0-9]{2,3})+(?:\.[0-9]{1,2})?|[0-9]{3,8}(?:\.[0-9]{1,2})?)/gi;
  const lines = (t) => t.split(/\n/).map((l) => l.trim()).filter(Boolean);

  // value written after a label on the same line (or next line)
  function after(text, labelRe, valRe) {
    const L = lines(text);
    for (let i = 0; i < L.length; i++) {
      const m = labelRe.exec(L[i]);
      if (!m) continue;
      const rest = L[i].slice(m.index + m[0].length).replace(/^[\s:.\-#|=]+/, '');
      const v = valRe.exec(rest) || (L[i + 1] ? valRe.exec(L[i + 1]) : null);
      if (v) return (v[1] || v[0]).trim();
    }
    return '';
  }
  function amountNear(text, labelRe) {
    let best = null;
    lines(text).forEach((l, i, L) => {
      if (!labelRe.test(l)) return;
      const seg = l + ' ' + (L[i + 1] && !/[a-z]{4,}/i.test(L[i + 1]) ? L[i + 1] : '');
      let m; AMT_RE.lastIndex = 0; const vals = [];
      while ((m = AMT_RE.exec(seg))) { const v = amt(m[1]); if (v && v >= 100) vals.push(v); }
      if (vals.length) { const v = vals[vals.length - 1]; if (best == null || v > best) best = v; }
    });
    return best;
  }
  const VIN = /\b(M[A-Z0-9]{16})\b/;
  function chassis(text) {
    const t = text.toUpperCase().replace(/[^A-Z0-9\n: ]/g, ' ');
    const lab = after(t, /(CHASSIS|CHASIS|FRAME|VIN)\s*(NO|NUMBER|#)?/, /([A-Z0-9]{10,20})/);
    if (lab && lab.length >= 11) return lab;
    const v = VIN.exec(t.replace(/O(?=[0-9]{3})/g, '0')); return v ? v[1] : lab;
  }
  const engine = (text) => after(text.toUpperCase(), /(ENGINE|ENG\.?|MOTOR)\s*(NO|NUMBER|#)?\.?/, /([A-Z0-9]{6,20})/);
  const pickFrom = (text, list) => { const T = text.toLowerCase(); return (list || []).find((x) => x && T.includes(String(x).toLowerCase())) || ''; };

  OCR.parseInvoice = function (text) {
    const r = {};
    r.invoiceNo = after(text, /(tax\s*)?(invoice|inv|bill)\.?\s*(no|number|#)\.?/i, /([A-Z0-9][A-Z0-9\/\-]{2,24})/i);
    const dl = after(text, /(invoice|inv|bill)?\s*date/i, /(\d{1,2}[\/\-\.\s](?:\d{1,2}|[A-Za-z]{3,9})[\/\-\.\s,]+\d{2,4}|\d{4}-\d{2}-\d{2})/);
    r.invoiceDate = (dl && OCR.dates(dl)[0]) || OCR.dates(text)[0] || '';
    r.invoiceAmount = amountNear(text, /(grand\s*total|invoice\s*(value|total|amount)|total\s*(invoice|amount|value)|net\s*(amount|payable|total)|amount\s*payable)/i) || '';
    r.chassisNo = chassis(text);
    r.engineNo = engine(text);
    r.model = pickFrom(text, S.cs && S.cs.models) || after(text, /\bmodel\b(\s*(name|no))?/i, /([A-Za-z0-9][A-Za-z0-9 \-\+\.]{2,30})/);
    r.colour = pickFrom(text, S.cs && S.cs.colours) || after(text, /\b(colou?r)\b/i, /([A-Za-z][A-Za-z \-]{2,25})/);
    r.customerName = after(text, /(customer|buyer|billed\s*to|name\s*of\s*(the\s*)?(customer|buyer))\s*(name)?/i, /([A-Za-z][A-Za-z\. ]{2,40})/)
      .replace(/\s+(mobile|mob|ph|phone|contact|address|addr|s\/o|d\/o|w\/o|father|gstin|date)\b.*$/i, '').trim();
    const mob = /(?:\+91[\s\-]?)?\b([6-9]\d{9})\b/.exec(text); r.mobile = mob ? mob[1] : '';
    return r;
  };

  OCR.parseInsurance = function (text) {
    const r = {};
    r.policyNo = after(text, /(policy|certificate)\s*(no|number|#)\.?/i, /([A-Z0-9][A-Z0-9\/\-]{5,30})/i);
    r.insCompany = pickFrom(text, S.cs && S.cs.insurers) ||
      ((/(ICICI Lombard|Bajaj Allianz|HDFC ERGO|Tata AIG|New India Assurance|United India|National Insurance|Oriental Insurance|Go Digit|Digit|Reliance General|SBI General|Royal Sundaram|Cholamandalam MS|IFFCO[\s\-]Tokio|Future Generali|Kotak|Liberty|Shriram General|Universal Sompo|Magma HDI|Zuno|Acko)/i.exec(text) || [])[1] || '');
    const seg = after(text, /(period\s*of\s*(insurance|cover)|policy\s*period|valid|from)/i, /(.{8,90})/);
    let ds = OCR.dates(seg);
    if (ds.length < 2) { const all = OCR.dates(text).sort(); ds = all.length >= 2 ? [all[0], all[all.length - 1]] : all; }
    r.insFrom = ds[0] || ''; r.insTo = ds[1] || '';
    r.insPremium = amountNear(text, /(total\s*premium|gross\s*premium|premium\s*(payable|amount|paid)|final\s*premium|total\s*payable)/i) || '';
    r.idv = amountNear(text, /(\bidv\b|insured\s*declared\s*value)/i) || '';
    r.chassisNo = chassis(text); r.engineNo = engine(text);
    return r;
  };
})();
