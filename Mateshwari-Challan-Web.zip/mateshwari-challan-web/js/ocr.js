// ---------- OCR: Invoice / Insurance PDF or photo -> auto-fill fields ----------
// PDF with text  -> pdf.js text read (fast, exact)
// Scanned PDF / photo -> Tesseract OCR (works offline inside the app)
(function () {
  const OCR = window.OCR = {};
  const abs = (p) => new URL(p, location.href).href;
  let worker = null;

  async function getWorker(progress) {
    if (worker) return worker;
    worker = await Tesseract.createWorker('eng', 1, {
      workerPath: abs('lib/ocr/worker.min.js'), corePath: abs('lib/ocr/'), langPath: abs('lib/ocr/lang'), gzip: true,
      logger: (m) => { if (progress && m.status === 'recognizing text') progress(Math.round(m.progress * 100)); }
    });
    return worker;
  }
  async function ocrImage(src, progress) {
    const w = await getWorker(progress);
    const r = await w.recognize(src);
    return (r && r.data && r.data.text) || '';
  }

  function pdfjs() {
    const lib = window.pdfjsLib;
    if (lib && !lib.GlobalWorkerOptions.workerSrc) lib.GlobalWorkerOptions.workerSrc = abs('lib/pdf.worker.min.js');
    return lib;
  }
  const b64ToBytes = (b64) => { const s = atob(b64); const a = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a; };

  // Returns plain text from a PDF (text layer) — rebuilds lines by Y position
  async function pdfText(pdf, maxPages) {
    let out = '';
    for (let p = 1; p <= Math.min(pdf.numPages, maxPages || 3); p++) {
      const page = await pdf.getPage(p);
      const tc = await page.getTextContent();
      const rows = {};
      tc.items.forEach((it) => { const y = Math.round(it.transform[5] / 3); (rows[y] = rows[y] || []).push(it); });
      Object.keys(rows).map(Number).sort((a, b) => b - a).forEach((y) => {
        out += rows[y].sort((a, b) => a.transform[4] - b.transform[4]).map((i) => i.str).join(' ').replace(/\s+/g, ' ') + '\n';
      });
    }
    return out;
  }
  async function pdfToImages(pdf, maxPages) {
    const imgs = [];
    for (let p = 1; p <= Math.min(pdf.numPages, maxPages || 2); p++) {
      const page = await pdf.getPage(p);
      const vp = page.getViewport({ scale: 2.2 });
      const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height;
      await page.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
      imgs.push(c.toDataURL('image/png'));
    }
    return imgs;
  }

  // dataUrl: data:...;base64,... -> text
  OCR.extract = async function (dataUrl, progress) {
    const m = /^data:([^;]+);base64,(.*)$/.exec(dataUrl || '');
    if (!m) throw new Error('File read nahi hui');
    if (/pdf/i.test(m[1])) {
      const pdf = await pdfjs().getDocument({ data: b64ToBytes(m[2]) }).promise;
      const txt = await pdfText(pdf, 3);
      if (txt.replace(/\s/g, '').length > 60) return { text: txt, method: 'PDF text' };
      let all = '';
      for (const img of await pdfToImages(pdf, 2)) all += (await ocrImage(img, progress)) + '\n';
      return { text: all, method: 'OCR (scanned PDF)' };
    }
    return { text: await ocrImage(dataUrl, progress), method: 'OCR (photo)' };
  };

  // ---------- parsing helpers ----------
  const MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
  const DATE_RE = /(\d{1,2})[\/\-\.\s](\d{1,2}|[A-Za-z]{3,9})[\/\-\.\s,]+(\d{4}|\d{2})\b|(\d{4})-(\d{2})-(\d{2})/g;
  function toISO(m) {
    if (m[4]) return m[4] + '-' + m[5] + '-' + m[6];
    let d = +m[1], mo = /\d/.test(m[2]) ? +m[2] : MON[m[2].slice(0, 3).toLowerCase()], y = +m[3];
    if (!mo || mo > 12 || d > 31 || d < 1) return null;
    if (y < 100) y += 2000;
    if (y < 2000 || y > 2100) return null;
    return y + '-' + U.pad(mo) + '-' + U.pad(d);
  }
  OCR.dates = (s) => { const out = []; let m; DATE_RE.lastIndex = 0; while ((m = DATE_RE.exec(s))) { const d = toISO(m); if (d) out.push(d); } return out; };
  const amt = (s) => { const v = parseFloat(String(s).replace(/[,\s]/g, '').replace(/^[^\d]+/, '')); return isNaN(v) ? null : v; };
  const AMT_RE = /(?:rs\.?|inr|₹)?\s*([0-9]{1,3}(?:,[0-9]{2,3})+(?:\.[0-9]{1,2})?|[0-9]{3,8}(?:\.[0-9]{1,2})?)/gi;
  const lines = (t) => t.split(/\n/).map((l) => l.trim()).filter(Boolean);

  // value written after a label on the same line (or next line)
  function after(text, labelRe, valRe) {
    const L = lines(text);
    for (let i = 0; i < L.length; i++) {
      const m = labelRe.exec(L[i]);
      if (!m) continue;
      const rest = L[i].slice(m.index + m[0].length).replace(/^[\s:.\-#|=]+/, '');
      const v = valRe.exec(rest) || (L[i + 1] ? valRe.exec(L[i + 1]) : null);
      if (v) return (v[1] || v[0]).trim();
    }
    return '';
  }
  function amountNear(text, labelRe) {
    let best = null;
    lines(text).forEach((l, i, L) => {
      if (!labelRe.test(l)) return;
      const seg = l + ' ' + (L[i + 1] && !/[a-z]{4,}/i.test(L[i + 1]) ? L[i + 1] : '');
      let m; AMT_RE.lastIndex = 0; const vals = [];
      while ((m = AMT_RE.exec(seg))) { const v = amt(m[1]); if (v && v >= 100) vals.push(v); }
      if (vals.length) { const v = vals[vals.length - 1]; if (best == null || v > best) best = v; }
    });
    return best;
  }
  const VIN = /\b(M[A-Z0-9]{16})\b/;
  function chassis(text) {
    const t = text.toUpperCase().replace(/[^A-Z0-9\n: ]/g, ' ');
    const lab = after(t, /(CHASSIS|CHASIS|FRAME|VIN)\s*(NO|NUMBER|#)?/, /([A-Z0-9]{10,20})/);
    if (lab && lab.length >= 11) return lab;
    const v = VIN.exec(t.replace(/O(?=[0-9]{3})/g, '0')); return v ? v[1] : lab;
  }
  const engine = (text) => after(text.toUpperCase(), /(ENGINE|ENG\.?|MOTOR)\s*(NO|NUMBER|#)?\.?/, /([A-Z0-9]{6,20})/);
  const pickFrom = (text, list) => { const T = text.toLowerCase(); return (list || []).find((x) => x && T.includes(String(x).toLowerCase())) || ''; };

  const cleanName = (v) => String(v || '').replace(/\s+(mobile|mob|ph|phone|contact|address|addr|s\/o|d\/o|w\/o|son|father|gstin|date|age|reg)\b.*$/i, '').replace(/[^A-Za-z\. ]/g, '').trim();
  const REGNO = /\b([A-Z]{2}[\s\-]?\d{1,2}[\s\-]?[A-Z]{0,3}[\s\-]?\d{3,4})\b/;
  const regNo = (text) => {
    const lab = after(text.toUpperCase(), /(REGN?\.?|REGISTRATION|VEHICLE)\s*(NO|NUMBER|#)\.?/, /([A-Z]{2}[\s\-]?\d{1,2}[\s\-]?[A-Z]{0,3}[\s\-]?\d{3,4})/);
    const v = lab || ((REGNO.exec(text.toUpperCase()) || [])[1] || '');
    return v.replace(/[\s\-]/g, '');
  };
  // finance company / hypothecation written on invoice, insurance or RC
  const FIN_RE = /(hypothecat\w*|hp\s*(with|to)|financ\w*\s*(by|er|ier)?|lien\s*(with|in favour of)?|hire\s*purchase)/i;
  function financer(text) {
    const known = pickFrom(text, S.cs && S.cs.financers);
    if (known) return known;
    const v = after(text, FIN_RE, /([A-Za-z][A-Za-z&\.\- ]{3,40})/);
    return v ? v.replace(/^(to|with|by|in favour of)\s+/i, '').replace(/\s+(ltd|limited)\b.*$/i, ' $1').trim() : '';
  }
  // two dates from a line that matches label (OD / TP periods)
  function periodNear(text, labelRe) {
    const L = lines(text);
    for (let i = 0; i < L.length; i++) {
      if (!labelRe.test(L[i])) continue;
      const ds = OCR.dates(L[i] + ' ' + (L[i + 1] || ''));
      if (ds.length >= 2) return [ds[0], ds[1]];
      if (ds.length === 1) return [ds[0], ''];
    }
    return ['', ''];
  }
  const afterDate = (text, re) => { const v = after(text, re, /(\d{1,2}[\/\-\.\s](?:\d{1,2}|[A-Za-z]{3,9})[\/\-\.\s,]+\d{2,4}|\d{4}-\d{2}-\d{2})/); return (v && OCR.dates(v)[0]) || ''; };

  OCR.parseInvoice = function (text) {
    const r = {};
    r.invoiceNo = after(text, /(tax\s*)?(invoice|inv|bill)\.?\s*(no|number|#)\.?/i, /([A-Z0-9][A-Z0-9\/\-]{2,24})/i);
    r.invoiceDate = afterDate(text, /(invoice|inv|bill)?\s*date/i) || OCR.dates(text)[0] || '';
    r.invoiceAmount = amountNear(text, /(grand\s*total|invoice\s*(value|total|amount)|total\s*(invoice|amount|value)|net\s*(amount|payable|total)|amount\s*payable)/i) || '';
    r.chassisNo = chassis(text);
    r.engineNo = engine(text);
    r.model = pickFrom(text, S.cs && S.cs.models) || after(text, /\b(model|vehicle\s*description|description)\b(\s*(name|no))?/i, /([A-Za-z0-9][A-Za-z0-9 \-\+\.]{2,30})/);
    r.variant = after(text, /\bvariant\b/i, /([A-Za-z0-9][A-Za-z0-9 \-\+\.]{1,25})/);
    r.colour = pickFrom(text, S.cs && S.cs.colours) || after(text, /\b(colou?r)\b/i, /([A-Za-z][A-Za-z \-]{2,25})/);
    r.keyNo = after(text.toUpperCase(), /KEY\s*(NO|NUMBER)\.?/, /([A-Z0-9]{3,12})/);
    r.batteryNo = after(text.toUpperCase(), /BATTERY\s*(NO|NUMBER|SR\.?\s*NO)\.?/, /([A-Z0-9\-]{4,25})/);
    r.customerName = cleanName(after(text, /(customer|buyer|billed\s*to|name\s*of\s*(the\s*)?(customer|buyer))\s*(name)?/i, /([A-Za-z][A-Za-z\. ]{2,40})/));
    r.fatherName = cleanName(after(text, /(s\/o|d\/o|w\/o|son\s*of|father'?s?\s*name)/i, /([A-Za-z][A-Za-z\. ]{2,40})/));
    r.address = after(text, /\baddress\b/i, /(.{6,90})/).replace(/\s+(mobile|ph|gstin)\b.*$/i, '').trim();
    const mob = /(?:\+91[\s\-]?)?\b([6-9]\d{9})\b/.exec(text); r.mobile = mob ? mob[1] : '';
    r.financer = financer(text);
    r.exShowroom = amountNear(text, /(ex[\s\-]*showroom|taxable\s*value|assessable\s*value)/i) || '';
    return r;
  };

  OCR.parseInsurance = function (text) {
    const r = {};
    r.policyNo = after(text, /(policy|certificate)\s*(no|number|#)\.?/i, /([A-Z0-9][A-Z0-9\/\-]{5,30})/i);
    r.insCompany = pickFrom(text, S.cs && S.cs.insurers) ||
      ((/(ICICI Lombard|Bajaj Allianz|HDFC ERGO|Tata AIG|New India Assurance|United India|National Insurance|Oriental Insurance|Go Digit|Digit|Reliance General|SBI General|Royal Sundaram|Cholamandalam MS|IFFCO[\s\-]Tokio|Future Generali|Kotak|Liberty|Shriram General|Universal Sompo|Magma HDI|Zuno|Acko)/i.exec(text) || [])[1] || '');
    const seg = after(text, /(period\s*of\s*(insurance|cover)|policy\s*period|valid|from)/i, /(.{8,90})/);
    let ds = OCR.dates(seg);
    if (ds.length < 2) { const all = OCR.dates(text).sort(); ds = all.length >= 2 ? [all[0], all[all.length - 1]] : all; }
    r.insFrom = ds[0] || ''; r.insTo = ds[1] || '';
    // separate Own Damage (OD) and Third Party (TP / liability) periods — common in 1+5 bundled policies
    const od = periodNear(text, /(own\s*damage|\bod\b\s*(cover|period|policy)?)/i);
    const tp = periodNear(text, /(third\s*party|\btp\b|liability)/i);
    r.odFrom = od[0] || r.insFrom; r.odTo = od[1] || r.insTo;
    r.tpFrom = tp[0] || r.insFrom; r.tpTo = tp[1] || r.insTo;
    r.insPremium = amountNear(text, /(total\s*premium|gross\s*premium|premium\s*(payable|amount|paid)|final\s*premium|total\s*payable)/i) || '';
    r.idv = amountNear(text, /(\bidv\b|insured\s*declared\s*value)/i) || '';
    r.chassisNo = chassis(text); r.engineNo = engine(text);
    r.regNo = /new|NEW/.test(after(text, /(regn?\.?|registration)\s*(no|number)\.?/i, /(\S+)/)) ? '' : regNo(text);
    r.insuredName = cleanName(after(text, /(insured('?s)?\s*name|name\s*of\s*(the\s*)?insured|proposer)/i, /([A-Za-z][A-Za-z\. ]{2,40})/));
    r.financer = financer(text);
    r.model = pickFrom(text, S.cs && S.cs.models);
    return r;
  };

  OCR.parseRC = function (text) {
    const r = {};
    r.regNo = regNo(text);
    r.regDate = afterDate(text, /(date\s*of\s*reg(istration|n)?|reg(istration|n)?\.?\s*date|regd\.?\s*date)/i);
    r.regValidTo = afterDate(text, /(reg(istration|n)?\.?\s*valid\w*|valid\s*up\s*to|validity|fitness\s*valid\w*)/i);
    r.ownerName = cleanName(after(text, /(owner('?s)?\s*name|name\s*of\s*(the\s*)?owner|registered\s*owner|\bname\b)/i, /([A-Za-z][A-Za-z\. ]{2,40})/));
    r.fatherName = cleanName(after(text, /(s\/o|d\/o|w\/o|son\s*of|daughter\s*of|wife\s*of|s\/w\/d\s*of|relation)/i, /([A-Za-z][A-Za-z\. ]{2,40})/));
    r.address = after(text, /\b(present\s*)?address\b/i, /(.{6,90})/).trim();
    r.chassisNo = chassis(text); r.engineNo = engine(text);
    r.model = pickFrom(text, S.cs && S.cs.models) || after(text, /(model|maker'?s?\s*(name|class)|vehicle\s*class)/i, /([A-Za-z0-9][A-Za-z0-9 \-\+\.]{2,30})/);
    r.colour = pickFrom(text, S.cs && S.cs.colours) || after(text, /\b(colou?r)\b/i, /([A-Za-z][A-Za-z \-]{2,25})/);
    r.mfgDate = after(text, /(mfg|manufactur\w*)\s*(date|month|yr|year)?/i, /(\d{1,2}[\/\-]\d{4}|\d{4})/);
    r.financer = financer(text);
    return r;
  };

  // compare chassis / engine from a document with what is on the challan
  const norm = (v) => String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '').replace(/O/g, '0').replace(/I/g, '1');
  OCR.same = function (a, b) {
    a = norm(a); b = norm(b);
    if (!a || !b) return null;
    if (a === b) return true;
    // OCR may drop/misread a char: accept if last 6 match and lengths are close
    return a.length >= 6 && b.length >= 6 && a.slice(-6) === b.slice(-6) && Math.abs(a.length - b.length) <= 1;
  };
  OCR.matchReport = function (doc, form) {
    const out = [];
    [['chassisNo', 'Chassis'], ['engineNo', 'Engine']].forEach(([k, l]) => {
      const m = OCR.same(doc[k], form[k]);
      if (m === null) return;
      out.push({ k, l, ok: m, doc: doc[k], form: form[k] });
    });
    if (doc.financer && form.financer) out.push({ k: 'financer', l: 'Finance', ok: norm(doc.financer).slice(0, 5) === norm(form.financer).slice(0, 5), doc: doc.financer, form: form.financer });
    return out;
  };
  OCR.matchHtml = (rep) => rep.map((m) => '<span class="match ' + (m.ok ? 'ok' : 'bad') + '">' + (m.ok ? '✅ ' : '❌ ') + U.esc(m.l) + (m.ok ? ' match' : ' MISMATCH: document me ' + U.esc(m.doc) + ', challan me ' + U.esc(m.form)) + '</span>').join(' ');
})();
