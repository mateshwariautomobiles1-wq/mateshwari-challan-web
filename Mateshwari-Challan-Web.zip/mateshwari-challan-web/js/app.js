// ---------- App shell, login, router ----------
(function () {
  const S = window.S = { user: null, emp: null, empId: null, cr: null, cs: null, isAdmin: false, view: null, params: null };
  const V = window.Views = {};
  const App = window.App = {};
  const esc = U.esc;
  const root = () => document.getElementById('app');

  App.start = async function () {
    if (!DB.configured()) { root().innerHTML = '<div class="center-card card"><h3>Firebase config missing</h3></div>'; return; }
    DB.init();
    U.loading(true);
    DB.auth.onAuthStateChanged(async (fbUser) => {
      Ch.dirty();
      if (!fbUser) { U.loading(false); return renderLogin(); }
      try {
        const u = await DB.get('users', fbUser.uid);
        if (!u || u.active === false) { U.loading(false); await DB.signOut(); U.toast(T('accountInactive'), 'err'); return; }
        S.user = u; S.isAdmin = u.role === 'admin'; S.isCustomer = u.role === 'customer';
        S.cs = Object.assign(Ch.defaultSettings(), (await DB.get('settings', 'challan')) || {});
        try { S.company = (await DB.get('settings', 'company')) || {}; } catch (e) { S.company = {}; }
        if (S.isCustomer) { U.loading(false); return renderCustomerShell(); }
        if (!S.isAdmin) {
          S.empId = u.empId;
          S.emp = await DB.get('employees', u.empId);
          S.cr = await DB.get('crights', u.empId);
          if (!S.emp || S.emp.active === false || !S.cr || !S.cr.access) {
            U.loading(false);
            root().innerHTML = '<div class="login-page"><div class="login-card card center"><img src="img/logo.png" class="login-logo" alt=""><h3>' + esc((S.emp && S.emp.name) || '') +
              '</h3><p>' + T('noAccess') + '</p><button class="btn block" onclick="DB.signOut()">' + T('logout') + '</button></div></div>';
            return;
          }
        } else { S.empId = 'admin'; }
        U.loading(false);
        renderShell();
        App.go(Ch.can('dashboard') ? 'dash' : 'list');
      } catch (e) {
        console.error(e); U.loading(false);
        root().innerHTML = '<div class="center-card card"><h3>' + T('error') + '</h3><p>' + esc(e.message) + '</p><button class="btn" onclick="DB.signOut()">' + T('logout') + '</button></div>';
      }
    });
  };

  // ---------- Login (same ID/password as Staff App) ----------
  function renderLogin() {
    S.user = null; S.emp = null; S.cr = null;
    U.$$('.modal-wrap').forEach((m) => m.remove());
    root().innerHTML = '<div class="login-page"><div class="login-card card">' +
      '<img src="img/logo.png" class="login-logo" alt=""><h2>' + esc(APP_INFO.showroom) + '</h2><p class="muted">Delivery Challan Management</p>' +
      '<form id="loginForm" class="form">' + U.field('id', 'Mobile No / Email / Customer ID', '', { required: true, placeholder: '98xxxxxxxx  ya  C98xxxxxxxx' }) +
      U.field('password', 'Password', '', { type: 'password', required: true }) +
      '<button class="btn block" type="submit">Login</button><p class="muted small center">Staff: Staff App wala login · Customer: C + mobile number</p></form>' +
      '</div><p class="muted small center">v' + APP_INFO.version + '</p></div>';
    U.$('#loginForm').onsubmit = async (e) => {
      e.preventDefault(); const d = U.formData(e.target);
      U.loading(true, 'Login ho raha hai...');
      try { await DB.signIn(d.id, d.password); } catch (err) { U.loading(false); U.toast(App.authErr(err), 'err'); }
    };
  }
  App.authErr = function (err) {
    const c = (err && err.code) || '';
    if (/wrong-password|invalid-credential|invalid-login|user-not-found/.test(c)) return T('wrongLogin');
    if (/too-many-requests/.test(c)) return T('tooMany');
    if (/network/.test(c)) return T('noInternet');
    return (err && err.message) || String(err);
  };

  // ---------- Shell ----------
  function menu() {
    const m = [];
    if (Ch.can('dashboard')) m.push(['dash', '📊', 'Dashboard']);
    m.push(['list', '📋', 'All Challans']);
    if (Ch.can('create')) m.push(['form', '➕', 'New Challan']);
    m.push(['due', '⏰', 'Due Payment List'], ['dpdue', '💵', 'Down Payment Due'], ['findue', '🏦', 'Finance Disbursement Pending'], ['loans', '📂', 'Loan File Status'],
      ['claims', '🎁', 'Scheme / Claim Pending'], ['pendency', '📌', 'Pendency List']);
    if (Ch.can('calling')) m.push(['calling', '📞', 'Calling']);
    m.push(['customers', '👤', 'Customer Ledger / Search']);
    if (Ch.can('reports')) m.push(['reports', '📑', 'Reports']);
    if (Ch.can('import')) m.push(['importx', '⬆️', 'Import (Excel)']);
    if (S.isAdmin) m.push(['staff', '🔐', 'Staff & Rights'], ['settings', '⚙️', 'Settings & Masters']);
    m.push(['changePassword', '🔑', 'Change Password']);
    return m;
  }
  function renderShell() {
    const name = S.isAdmin ? (S.user.name || 'Admin') : S.emp.name;
    const nav = [['list', '📋', 'Challans']];
    if (Ch.can('dashboard')) nav.unshift(['dash', '📊', 'Dashboard']);
    if (Ch.can('create')) nav.push(['form', '➕', 'New']);
    nav.push(['due', '⏰', 'Due']); if (Ch.can('calling')) nav.push(['calling', '📞', 'Calling']);
    nav.push(['_menu', '☰', 'Menu']);
    root().innerHTML =
      '<header class="topbar"><div class="brand" data-go="' + nav[0][0] + '"><img src="' + esc((S.company && S.company.logo) || 'img/logo.png') + '" alt=""><div><b>' +
      esc((S.company && S.company.name) || APP_INFO.showroom) + '</b><small>Delivery Challan · ' + esc(S.isAdmin ? 'Admin' : name) + '</small></div></div>' +
      '<div class="top-actions"><button class="icon-btn" data-go="customers" title="Search">🔍</button></div></header>' +
      '<aside id="drawer" class="drawer"><div class="drawer-head"><b>' + esc(name) + '</b><small>' + esc(S.isAdmin ? (S.user.email || 'Admin') : (S.emp.designation || S.empId)) + '</small></div>' +
      menu().map((m) => '<a data-go="' + m[0] + '"><span>' + m[1] + '</span>' + m[2] + '</a>').join('') +
      '<a onclick="App.logout()"><span>🚪</span>Logout</a></aside><div id="drawerBg" class="drawer-bg"></div>' +
      '<main id="view" class="view"></main>' +
      '<nav class="bottomnav">' + nav.map((n) => '<a data-go="' + n[0] + '"><span>' + n[1] + '</span><small>' + n[2] + '</small></a>').join('') + '</nav>';
    U.$$('[data-go]').forEach((a) => a.onclick = () => {
      if (a.dataset.go === '_menu') return drawer(true);
      drawer(false); App.go(a.dataset.go);
    });
    U.$('#drawerBg').onclick = () => drawer(false);
  }
  function renderCustomerShell() {
    root().innerHTML = '<header class="topbar"><div class="brand"><img src="' + esc((S.company && S.company.logo) || 'img/logo.png') + '" alt=""><div><b>' +
      esc((S.company && S.company.name) || APP_INFO.showroom) + '</b><small>Customer · ' + esc(S.user.name || '') + '</small></div></div>' +
      '<div class="top-actions"><button class="icon-btn" onclick="App.go(\'portal\')">🏠</button><button class="icon-btn" onclick="App.go(\'changePassword\')">🔑</button><button class="icon-btn" onclick="App.logout()">🚪</button></div></header>' +
      '<main id="view" class="view"></main>';
    App.go('portal');
  }
  function drawer(on) { U.$('#drawer').classList.toggle('open', on); U.$('#drawerBg').classList.toggle('open', on); }

  App.go = async function (view, params) {
    S.view = view; S.params = params || null;
    U.$$('.modal-wrap').forEach((m) => m.remove());
    const el = U.$('#view'); if (!el) return;
    U.$$('.bottomnav a, .drawer a').forEach((a) => a.classList.toggle('on', a.dataset.go === view));
    const fn = V[view];
    if (!fn) { el.innerHTML = U.empty('Not found: ' + view); return; }
    el.innerHTML = '<div class="skeleton"></div><div class="skeleton"></div>';
    window.scrollTo(0, 0);
    try { await fn(el, params || {}); }
    catch (e) {
      console.error(e);
      el.innerHTML = '<div class="card"><h3>Error</h3><p>' + esc(e.message || e) + '</p>' +
        (/permission/i.test(e.message || '') ? '<p class="muted small">Firestore rules update nahi hue ya aapko ye right nahi mila hai.</p>' : '') +
        '<button class="btn" onclick="App.refresh()">Retry</button></div>';
    }
  };
  App.refresh = () => App.go(S.view, S.params);
  App.logout = async () => { if (await U.confirm(T('logoutConfirm'), T('logout'))) await DB.signOut(); };

  V.changePassword = async function (el) {
    el.innerHTML = '<h2 class="page-title">Change Password</h2><form id="cpf" class="card form">' +
      U.field('old', 'Old Password', '', { type: 'password', required: true }) + U.field('n1', 'New Password', '', { type: 'password', required: true }) +
      U.field('n2', 'Confirm Password', '', { type: 'password', required: true }) + '<button class="btn block">Save</button>' +
      '<p class="muted small">Ye password Staff App me bhi badal jayega.</p></form>';
    U.$('#cpf').onsubmit = async (e) => {
      e.preventDefault(); const d = U.formData(e.target);
      if (d.n1.length < 6) return U.toast(T('pwdShort'), 'err');
      if (d.n1 !== d.n2) return U.toast(T('pwdMismatch'), 'err');
      U.loading(true);
      try { await DB.changePassword(d.old, d.n1); U.toast(T('saved'), 'ok'); App.go(S.isCustomer ? 'portal' : 'list'); }
      catch (err) { U.toast(App.authErr(err), 'err'); } finally { U.loading(false); }
    };
  };

  document.addEventListener('DOMContentLoaded', App.start);
  document.addEventListener('backbutton', () => { const m = U.$$('.modal-wrap'); if (m.length) m[m.length - 1].remove(); });
})();
